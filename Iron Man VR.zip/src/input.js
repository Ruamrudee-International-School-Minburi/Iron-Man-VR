import * as THREE from 'three';

const BTN = ['trigger', 'squeeze', 'stick', 'a', 'b'];

class Hand {
  constructor(side) {
    this.side = side;
    this.connected = false;
    this.grip = null; // Object3D in grip space
    this.ray = null;  // Object3D in target-ray space
    this.trigger = 0; this.squeeze = 0;
    this.stick = new THREE.Vector2();
    this.btn = { trigger: false, squeeze: false, stick: false, a: false, b: false };
    this.prev = { ...this.btn };
    this.gamepad = null;
  }
  pressed(n) { return this.btn[n] && !this.prev[n]; }
  released(n) { return !this.btn[n] && this.prev[n]; }
  pulse(intensity = 0.5, ms = 40) {
    const h = this.gamepad && this.gamepad.hapticActuators && this.gamepad.hapticActuators[0];
    if (h && h.pulse) h.pulse(intensity, ms).catch(() => {});
    else if (this.gamepad && this.gamepad.vibrationActuator) this.gamepad.vibrationActuator.playEffect?.('dual-rumble', { duration: ms, strongMagnitude: intensity }).catch?.(() => {});
  }
}

export class Input {
  constructor(renderer, camera, rig, dom) {
    this.renderer = renderer; this.camera = camera; this.rig = rig; this.dom = dom;
    this.hands = { left: new Hand('left'), right: new Hand('right') };
    this.keys = new Set(); this.keysPrev = new Set();
    this.mouse = { dx: 0, dy: 0, left: false, right: false, leftPrev: false, rightPrev: false, x: 0, y: 0, locked: false };
    this.xr = false;

    // ---- XR controllers
    for (let i = 0; i < 2; i++) {
      const ray = renderer.xr.getController(i);
      const grip = renderer.xr.getControllerGrip(i);
      rig.add(ray); rig.add(grip);
      const onConnect = (e) => {
        const side = e.data.handedness === 'left' ? 'left' : 'right';
        const h = this.hands[side];
        h.connected = true; h.grip = grip; h.ray = ray; h.source = e.data;
        grip.userData.side = side; ray.userData.side = side;
        this.onHandConnected && this.onHandConnected(side, grip, ray);
      };
      const onDisconnect = () => {
        const side = grip.userData.side;
        if (side) this.hands[side].connected = false;
      };
      ray.addEventListener('connected', onConnect);
      ray.addEventListener('disconnected', onDisconnect);
    }

    // ---- desktop fake hands (attached to the camera)
    this.deskHands = {
      left: new THREE.Object3D(), right: new THREE.Object3D(),
    };
    this.deskHands.left.position.set(-0.34, -0.36, -0.62);
    this.deskHands.right.position.set(0.34, -0.36, -0.62);
    this.deskHands.left.rotation.x = this.deskHands.right.rotation.x = 0.35;
    camera.add(this.deskHands.left, this.deskHands.right);

    // ---- keyboard & mouse
    addEventListener('keydown', (e) => {
      if (['Tab', 'Space', 'ArrowUp', 'ArrowDown'].includes(e.code)) e.preventDefault();
      this.keys.add(e.code);
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => this.keys.clear());
    dom.addEventListener('mousedown', (e) => {
      if (e.button === 0) this.mouse.left = true;
      if (e.button === 2) this.mouse.right = true;
      if (!this.mouse.locked && !this.uiOpen && !this.xr) dom.requestPointerLock?.();
    });
    addEventListener('mouseup', (e) => { if (e.button === 0) this.mouse.left = false; if (e.button === 2) this.mouse.right = false; });
    dom.addEventListener('contextmenu', (e) => e.preventDefault());
    addEventListener('mousemove', (e) => {
      if (this.mouse.locked) { this.mouse.dx += e.movementX; this.mouse.dy += e.movementY; }
      const r = dom.getBoundingClientRect();
      this.mouse.x = ((e.clientX - r.left) / r.width) * 2 - 1;
      this.mouse.y = -((e.clientY - r.top) / r.height) * 2 + 1;
    });
    document.addEventListener('pointerlockchange', () => { this.mouse.locked = document.pointerLockElement === dom; });
    this.uiOpen = false;
  }

  key(c) { return this.keys.has(c); }
  keyPressed(c) { return this.keys.has(c) && !this.keysPrev.has(c); }
  mousePressed(b = 'left') { return this.mouse[b] && !this.mouse[b + 'Prev']; }

  // call once per frame BEFORE game logic
  update() {
    this.xr = this.renderer.xr.isPresenting;
    const session = this.renderer.xr.getSession();
    for (const h of Object.values(this.hands)) { Object.assign(h.prev, h.btn); h.gamepad = null; }
    if (session) {
      for (const src of session.inputSources) {
        if (!src.gamepad || (src.handedness !== 'left' && src.handedness !== 'right')) continue;
        const h = this.hands[src.handedness];
        const gp = src.gamepad; h.gamepad = gp;
        const b = (i) => (gp.buttons[i] ? gp.buttons[i] : { value: 0, pressed: false });
        h.trigger = b(0).value; h.squeeze = b(1).value;
        h.btn.trigger = h.trigger > 0.55; h.btn.squeeze = h.squeeze > 0.55 || b(1).pressed;
        h.btn.stick = b(3).pressed; h.btn.a = b(4).pressed; h.btn.b = b(5).pressed;
        let sx = gp.axes[2] || 0, sy = gp.axes[3] || 0;
        if (Math.abs(gp.axes[0] || 0) + Math.abs(gp.axes[1] || 0) > Math.abs(sx) + Math.abs(sy)) { sx = gp.axes[0] || 0; sy = gp.axes[1] || 0; }
        h.stick.set(Math.abs(sx) > 0.15 ? sx : 0, Math.abs(sy) > 0.15 ? sy : 0);
      }
    }
  }
  // call once per frame AFTER game logic
  endFrame() {
    this.keysPrev = new Set(this.keys);
    this.mouse.leftPrev = this.mouse.left; this.mouse.rightPrev = this.mouse.right;
    this.mouse.dx = 0; this.mouse.dy = 0;
  }
}
