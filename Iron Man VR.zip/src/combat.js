import * as THREE from 'three';
import { segmentHit } from './world/colliders.js';
import { rand } from './util.js';

const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _d = new THREE.Vector3(), _tmp = new THREE.Vector3();
const Z = new THREE.Vector3(0, 0, 1);

const TYPES = {
  repulsor: { speed: 420, life: 1.6, color: 0xcfeeff, len: 3.2, rad: 0.14, friendly: true },
  bullet: { speed: 650, life: 1.0, color: 0xffd27a, len: 4, rad: 0.05, friendly: true },
  bolt: { speed: 150, life: 4, color: 0xff3b2b, len: 2.2, rad: 0.16, friendly: false },
  shell: { speed: 130, life: 5, color: 0xffa040, len: 1.2, rad: 0.22, friendly: false, grav: 4 },
  cannon: { speed: 170, life: 4, color: 0xffe08a, len: 1.6, rad: 0.3, friendly: false },
};

export class Combat {
  constructor(scene, fx, audio) {
    this.scene = scene; this.fx = fx; this.audio = audio;
    this.enemies = [];      // filled by Enemies
    this.player = null;     // set by main
    this.projectiles = [];
    this.missiles = [];
    this.pool = {};
    this.stats = { shots: 0, hits: 0, kills: 0 };
    this.onKill = null;
    const geo = new THREE.SphereGeometry(1, 10, 8);
    for (const k in TYPES) {
      const T = TYPES[k];
      const mat = new THREE.MeshBasicMaterial({ color: new THREE.Color(T.color).multiplyScalar(2.2), transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
      this.pool[k] = { geo, mat, free: [] };
    }
    this.missileGeo = new THREE.CylinderGeometry(0.06, 0.08, 0.7, 8).rotateX(Math.PI / 2);
    this.missileMat = new THREE.MeshStandardMaterial({ color: 0xdedede, metalness: 0.8, roughness: 0.3 });
  }

  _mesh(type) {
    const P = this.pool[type];
    let m = P.free.pop();
    if (!m) {
      m = new THREE.Mesh(P.geo, P.mat);
      const T = TYPES[type];
      m.scale.set(T.rad, T.rad, T.len / 2);
      m.frustumCulled = false;
      m.renderOrder = 6;
    }
    this.scene.add(m);
    return m;
  }

  // find best target near a direction (aim assist / missile lock)
  findTarget(origin, dir, coneDeg = 8, maxDist = 900, exclude = null) {
    const cosMax = Math.cos(THREE.MathUtils.degToRad(coneDeg));
    let best = null, bestScore = -Infinity;
    for (const e of this.enemies) {
      if (!e.alive || e === exclude || e.friendly) continue;
      _d.copy(e.pos).sub(origin);
      const dist = _d.length();
      if (dist > maxDist || dist < 1) continue;
      const c = _d.dot(dir) / dist;
      if (c < cosMax) continue;
      const score = c * 2 - dist / maxDist;
      if (score > bestScore) { bestScore = score; best = e; }
    }
    return best;
  }
  findTargets(origin, dir, coneDeg, maxDist, n) {
    const cosMax = Math.cos(THREE.MathUtils.degToRad(coneDeg));
    return this.enemies
      .filter((e) => e.alive && !e.friendly)
      .map((e) => { _d.copy(e.pos).sub(origin); const dist = _d.length(); return { e, dist, c: _d.dot(dir) / Math.max(dist, 1) }; })
      .filter((o) => o.c > cosMax && o.dist < maxDist)
      .sort((a, b) => b.c - a.c)
      .slice(0, n)
      .map((o) => o.e);
  }

  fire(type, origin, dir, dmg, { assist = 0, owner = null, spread = 0 } = {}) {
    const T = TYPES[type];
    const d = dir.clone();
    if (spread) d.add(_tmp.set(rand(-spread, spread), rand(-spread, spread), rand(-spread, spread))).normalize();
    let homing = null;
    if (assist > 0 && T.friendly) {
      const tgt = this.findTarget(origin, d, assist, 1200);
      if (tgt) { // lead the target
        const dist = tgt.pos.distanceTo(origin);
        const lead = tgt.vel ? _tmp.copy(tgt.vel).multiplyScalar(dist / T.speed) : _tmp.set(0, 0, 0);
        d.copy(tgt.pos).add(lead).sub(origin).normalize();
        homing = tgt;
      }
    }
    const m = this._mesh(type);
    m.position.copy(origin);
    m.quaternion.setFromUnitVectors(Z, d);
    this.projectiles.push({ type, T, m, pos: origin.clone(), vel: d.multiplyScalar(T.speed), life: T.life, dmg, owner, homing });
    if (T.friendly) this.stats.shots++;
  }

  fireMissile(origin, dir, target, dmg = 60) {
    const m = new THREE.Mesh(this.missileGeo, this.missileMat);
    m.position.copy(origin);
    this.scene.add(m);
    const v = dir.clone().multiplyScalar(40).add(_tmp.set(rand(-8, 8), rand(2, 10), rand(-8, 8)));
    this.missiles.push({ m, pos: origin.clone(), vel: v, target, life: 7, dmg, age: 0, friendly: true });
  }
  fireEnemyMissile(origin, dir, dmg = 18) {
    const m = new THREE.Mesh(this.missileGeo, new THREE.MeshStandardMaterial({ color: 0x555555, metalness: 0.6 }));
    m.position.copy(origin); this.scene.add(m);
    this.missiles.push({ m, pos: origin.clone(), vel: dir.clone().multiplyScalar(60), target: 'player', life: 8, dmg, age: 0, friendly: false });
  }

  // continuous beam (unibeam / boss laser). Returns hit point.
  beam(origin, dir, dps, dt, maxDist = 700) {
    _b.copy(dir).multiplyScalar(maxDist).add(origin);
    const wh = segmentHit(origin, _b);
    let dist = wh ? wh.dist : maxDist;
    let hitE = null;
    for (const e of this.enemies) {
      if (!e.alive || e.friendly) continue;
      _d.copy(e.pos).sub(origin);
      const t = _d.dot(dir);
      if (t < 0 || t > dist) continue;
      const perp = _d.addScaledVector(dir, -t).length();
      if (perp < e.radius + 1.0) { dist = t; hitE = e; }
    }
    const hp = origin.clone().addScaledVector(dir, dist);
    if (hitE) this.damageEnemy(hitE, dps * dt, hp);
    return { point: hp, dist, enemy: hitE, world: !!wh && !hitE };
  }

  flamer(origin, dir, dps, dt, range = 16) {
    for (const e of this.enemies) {
      if (!e.alive || e.friendly) continue;
      _d.copy(e.pos).sub(origin);
      const dist = _d.length();
      if (dist > range + e.radius) continue;
      if (_d.dot(dir) / dist > 0.82) this.damageEnemy(e, dps * dt, e.pos);
    }
  }

  splash(pos, radius, dmg, friendly = true) {
    if (friendly) for (const e of this.enemies) {
      if (!e.alive || e.friendly) continue;
      const d = e.pos.distanceTo(pos) - e.radius;
      if (d < radius) this.damageEnemy(e, dmg * (1 - Math.max(0, d) / radius), pos);
    }
    if (!friendly && this.player) {
      const d = this.player.bodyPos.distanceTo(pos);
      if (d < radius) this.player.damage(dmg * (1 - d / radius), pos);
    }
  }

  damageEnemy(e, amt, at) {
    if (!e.alive) return;
    e.damage(amt, at);
    if (!e.alive) {
      this.stats.kills++;
      if (this.onKill) this.onKill(e);
    }
  }

  update(dt) {
    const P = this.player;
    // projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      _a.copy(p.pos);
      if (p.homing && p.homing.alive && p.T.friendly) { // gentle homing for aim-assisted shots
        _d.copy(p.homing.pos).sub(p.pos).normalize().multiplyScalar(p.T.speed);
        p.vel.lerp(_d, Math.min(1, dt * 6));
      }
      if (p.T.grav) p.vel.y -= p.T.grav * dt;
      p.pos.addScaledVector(p.vel, dt);
      let hit = false;
      if (p.T.friendly) {
        for (const e of this.enemies) {
          if (!e.alive || e.friendly) continue;
          if (segSphere(_a, p.pos, e.pos, e.radius + p.T.rad)) {
            this.damageEnemy(e, p.dmg, p.pos);
            this.stats.hits++;
            this.fx.repulsorImpact(p.pos);
            if (this.audio) this.audio.hit();
            hit = true; break;
          }
        }
      } else if (P && P.alive) {
        if (segSphere(_a, p.pos, P.bodyPos, P.radius + 0.3)) {
          P.damage(p.dmg, p.pos);
          if (p.type === 'shell' || p.type === 'cannon') { this.fx.explosion(p.pos, 0.7, P.bodyPos); this.splash(p.pos, 6, p.dmg * 0.4, false); }
          else this.fx.sparks(p.pos, 10, [1, 0.4, 0.3]);
          hit = true;
        }
      }
      if (!hit) {
        const w = segmentHit(_a, p.pos);
        if (w) {
          if (p.type === 'shell' || p.type === 'cannon') { this.fx.explosion(w.point, 0.8, P && P.bodyPos); this.splash(w.point, 8, p.dmg * 0.5, false); }
          else if (p.T.friendly) { this.fx.repulsorImpact(w.point); this.splash(w.point, 2.5, p.dmg * 0.3, true); }
          else this.fx.sparks(w.point, 6, [1, 0.5, 0.3]);
          hit = true;
        }
      }
      p.m.position.copy(p.pos);
      if (hit || p.life <= 0) {
        this.scene.remove(p.m); this.pool[p.type].free.push(p.m);
        this.projectiles.splice(i, 1);
      }
    }
    // missiles
    for (let i = this.missiles.length - 1; i >= 0; i--) {
      const m = this.missiles[i];
      m.life -= dt; m.age += dt;
      _a.copy(m.pos);
      let tgtPos = null;
      if (m.target === 'player') tgtPos = P && P.alive ? P.bodyPos : null;
      else if (m.target && m.target.alive) tgtPos = m.target.pos;
      const speed = m.friendly ? Math.min(190, 60 + m.age * 220) : 95;
      if (tgtPos && m.age > (m.friendly ? 0.25 : 0.1)) {
        _d.copy(tgtPos).sub(m.pos).normalize().multiplyScalar(speed);
        m.vel.lerp(_d, Math.min(1, dt * (m.friendly ? 5 : 1.6)));
      }
      m.vel.setLength(speed);
      m.pos.addScaledVector(m.vel, dt);
      m.m.position.copy(m.pos);
      m.m.quaternion.setFromUnitVectors(Z, _d.copy(m.vel).normalize());
      this.fx.missileTrail(m.pos);
      let boom = m.life <= 0;
      if (tgtPos && m.pos.distanceTo(tgtPos) < (m.friendly ? 3 : 2.2)) boom = true;
      if (!boom && segmentHit(_a, m.pos)) boom = true;
      if (boom) {
        this.fx.explosion(m.pos, m.friendly ? 1.0 : 0.8, P && P.bodyPos);
        if (m.friendly) this.splash(m.pos, 9, m.dmg, true);
        else this.splash(m.pos, 6, m.dmg, false);
        this.scene.remove(m.m);
        this.missiles.splice(i, 1);
      }
    }
  }

  clearHostile() {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      if (!p.T.friendly) { this.scene.remove(p.m); this.pool[p.type].free.push(p.m); this.projectiles.splice(i, 1); }
    }
    for (let i = this.missiles.length - 1; i >= 0; i--) if (!this.missiles[i].friendly) { this.scene.remove(this.missiles[i].m); this.missiles.splice(i, 1); }
  }
}

function segSphere(a, b, c, r) {
  _d.copy(b).sub(a);
  const len2 = _d.lengthSq();
  let t = len2 > 0 ? _tmp.copy(c).sub(a).dot(_d) / len2 : 0;
  t = Math.max(0, Math.min(1, t));
  const px = a.x + _d.x * t - c.x, py = a.y + _d.y * t - c.y, pz = a.z + _d.z * t - c.z;
  return px * px + py * py + pz * pz < r * r;
}
