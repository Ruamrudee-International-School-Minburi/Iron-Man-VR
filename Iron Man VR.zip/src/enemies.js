import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { heightAt } from './world/terrain.js';
import { resolveSphere } from './world/colliders.js';
import { rand, clamp } from './util.js';

const _v = new THREE.Vector3(), _w = new THREE.Vector3(), _q = new THREE.Quaternion();
const UP = new THREE.Vector3(0, 1, 0);

// ---------------------------------------------------------------- models
const M = {
  drone: new THREE.MeshStandardMaterial({ color: 0x6c7076, metalness: 0.85, roughness: 0.35 }),
  droneDark: new THREE.MeshStandardMaterial({ color: 0x2a2c30, metalness: 0.7, roughness: 0.5 }),
  red: new THREE.MeshBasicMaterial({ color: new THREE.Color(0xff2a1a).multiplyScalar(2.5), toneMapped: false }),
  olive: new THREE.MeshStandardMaterial({ color: 0x5b5a3c, roughness: 0.8, metalness: 0.2 }),
  sand: new THREE.MeshStandardMaterial({ color: 0x9a8a62, roughness: 0.85, metalness: 0.1 }),
  jet: new THREE.MeshStandardMaterial({ color: 0x80878f, roughness: 0.5, metalness: 0.5 }),
  monger: new THREE.MeshStandardMaterial({ color: 0x5d6168, metalness: 0.9, roughness: 0.4 }),
  mongerDark: new THREE.MeshStandardMaterial({ color: 0x2b2d31, metalness: 0.8, roughness: 0.5 }),
  whip: new THREE.MeshBasicMaterial({ color: new THREE.Color(0x7fd6ff).multiplyScalar(2.5), toneMapped: false }),
  blueGlow: new THREE.MeshBasicMaterial({ color: new THREE.Color(0xaee6ff).multiplyScalar(2.5), toneMapped: false }),
};
const rb = (w, h, d, r = 0.05) => new RoundedBoxGeometry(w, h, d, 2, r);
function mk(parent, geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.set(rx, ry, rz); m.castShadow = true; parent.add(m); return m;
}

function droneModel() {
  const g = new THREE.Group();
  mk(g, new THREE.SphereGeometry(0.8, 16, 12), M.drone).scale.set(1, 0.8, 1.3);
  mk(g, new THREE.CylinderGeometry(0.25, 0.25, 0.1, 12), M.red, 0, 0.1, 0.98, Math.PI / 2);
  mk(g, rb(3.2, 0.12, 0.7), M.droneDark, 0, 0, -0.2);
  for (const s of [-1, 1]) {
    mk(g, new THREE.CylinderGeometry(0.28, 0.2, 0.9, 10), M.drone, s * 1.5, 0, -0.1, Math.PI / 2);
    mk(g, new THREE.CylinderGeometry(0.06, 0.06, 1.4, 6), M.droneDark, s * 0.6, -0.5, 0.6, Math.PI / 2);
  }
  mk(g, rb(0.6, 0.5, 0.8), M.droneDark, 0, -0.5, -0.4);
  return g;
}
function turretModel() {
  const g = new THREE.Group();
  mk(g, new THREE.CylinderGeometry(1.6, 2, 1.2, 12), M.sand, 0, 0.6, 0);
  const head = new THREE.Group(); head.position.y = 1.6; g.add(head);
  mk(head, rb(1.8, 1, 1.8, 0.2), M.olive);
  mk(head, new THREE.CylinderGeometry(0.15, 0.15, 3, 8), M.droneDark, 0.3, 0.1, 1.6, Math.PI / 2);
  mk(head, new THREE.CylinderGeometry(0.15, 0.15, 3, 8), M.droneDark, -0.3, 0.1, 1.6, Math.PI / 2);
  g.userData.head = head;
  return g;
}
function tankModel() {
  const g = new THREE.Group();
  mk(g, rb(4, 1.3, 7, 0.25), M.olive, 0, 1.1, 0);
  for (const s of [-1, 1]) mk(g, rb(1, 1.1, 7.4, 0.4), M.droneDark, s * 2.2, 0.6, 0);
  const tur = new THREE.Group(); tur.position.y = 2.1; g.add(tur);
  mk(tur, rb(2.8, 1, 3.2, 0.3), M.olive);
  mk(tur, new THREE.CylinderGeometry(0.18, 0.2, 4.5, 10), M.droneDark, 0, 0.1, 3.3, Math.PI / 2);
  g.userData.head = tur;
  return g;
}
function jetModel() {
  const g = new THREE.Group();
  mk(g, rb(2.2, 1.4, 17, 0.6), M.jet);
  mk(g, new THREE.ConeGeometry(0.7, 3, 10), M.jet, 0, 0, 9.8, Math.PI / 2);
  const wing = new THREE.Shape(); wing.moveTo(0, 3); wing.lineTo(7, -2); wing.lineTo(7, -4.5); wing.lineTo(0, -4); wing.lineTo(-7, -4.5); wing.lineTo(-7, -2); wing.lineTo(0, 3);
  const wg = new THREE.ExtrudeGeometry(wing, { depth: 0.2, bevelEnabled: false }); wg.rotateX(Math.PI / 2);
  mk(g, wg, M.jet, 0, 0, 0);
  for (const s of [-1, 1]) mk(g, rb(0.15, 2.6, 2.6, 0.05), M.jet, s * 1.3, 1.4, -6.2, 0, 0, s * 0.45);
  mk(g, new THREE.SphereGeometry(0.6, 12, 8), new THREE.MeshPhysicalMaterial({ color: 0xa08030, metalness: 1, roughness: 0.1 }), 0, 0.75, 4.5).scale.set(1, 0.7, 2.6);
  for (const s of [-1, 1]) mk(g, new THREE.CylinderGeometry(0.5, 0.5, 0.2, 10), M.blueGlow, s * 0.55, 0, -8.6, Math.PI / 2).material = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xff9a40).multiplyScalar(2), toneMapped: false });
  return g;
}
function mechModel(scale = 1, whip = false) {
  // Iron Monger / Whiplash — big humanoid armor, origin at feet
  const g = new THREE.Group();
  const mat = whip ? M.droneDark : M.monger;
  mk(g, rb(1.6, 1.3, 1.1, 0.3), mat, 0, 2.6, 0);
  mk(g, rb(1.1, 0.7, 0.9, 0.2), M.mongerDark, 0, 1.85, 0);
  mk(g, new THREE.SphereGeometry(0.42, 16, 12), mat, 0, 3.55, 0.05);
  mk(g, rb(0.5, 0.1, 0.1, 0.03), M.red, 0, 3.6, 0.42).material = whip ? M.whip : M.red;
  mk(g, new THREE.CylinderGeometry(0.22, 0.22, 0.08, 20), whip ? M.whip : M.blueGlow, 0, 2.75, 0.56, Math.PI / 2);
  for (const s of [-1, 1]) {
    mk(g, new THREE.SphereGeometry(0.5, 12, 10), mat, s * 1.05, 3.05, 0);
    mk(g, rb(0.45, 1.3, 0.45, 0.15), mat, s * 1.2, 2.2, 0);
    mk(g, rb(0.5, 1.1, 0.55, 0.15), M.mongerDark, s * 1.25, 1.2, 0.1);
    mk(g, rb(0.55, 1.4, 0.6, 0.15), mat, s * 0.45, 0.95, 0);
    mk(g, rb(0.6, 0.5, 0.9, 0.15), M.mongerDark, s * 0.45, 0.25, 0.1);
    if (!whip) mk(g, new THREE.CylinderGeometry(0.12, 0.12, 1.2, 8), M.mongerDark, s * 1.25, 0.9, 0.6, Math.PI / 2);
  }
  if (whip) {
    g.userData.whips = [];
    for (const s of [-1, 1]) {
      const pts = []; for (let i = 0; i < 12; i++) pts.push(new THREE.Vector3(s * 1.3, 0.6 - i * 0.05, i * 0.6));
      const curve = new THREE.CatmullRomCurve3(pts);
      const w = new THREE.Mesh(new THREE.TubeGeometry(curve, 24, 0.07, 6), M.whip);
      g.add(w); g.userData.whips.push(w);
    }
  }
  g.scale.setScalar(scale);
  return g;
}

// ---------------------------------------------------------------- enemy
class Enemy {
  constructor(mgr, type, pos, opts) {
    this.mgr = mgr; this.type = type; this.opts = opts;
    this.pos = pos.clone(); this.vel = new THREE.Vector3();
    this.alive = true; this.tag = opts.tag || null;
    this.cool = rand(1, 3); this.t = rand(0, 10);
    this.friendly = !!opts.friendly;
    const D = {
      drone: { hp: 45, r: 1.6, model: droneModel },
      turret: { hp: 80, r: 2.2, model: turretModel },
      tank: { hp: 150, r: 3.8, model: tankModel },
      jet: { hp: 120, r: 7, model: jetModel },
      whiplash: { hp: 1500, r: 2.6, model: () => mechModel(1.0, true) },
      monger: { hp: 2800, r: 3.4, model: () => mechModel(1.35, false) },
    }[type];
    this.hp = this.maxHp = (opts.hp || D.hp) * (opts.hpMult || 1);
    this.radius = D.r;
    this.mesh = D.model();
    this.mesh.position.copy(this.pos);
    mgr.scene.add(this.mesh);
    this.boss = type === 'whiplash' || type === 'monger';
    this.name = opts.name || { drone: 'Hammer Drone', turret: 'Turret', tank: 'Tank', jet: 'F-22 Raptor', whiplash: 'WHIPLASH', monger: 'IRON MONGER' }[type];
    this.ground = type === 'turret' || type === 'tank';
    if (this.ground) { this.pos.y = heightAt(this.pos.x, this.pos.z); }
    if (type === 'jet') this.vel.set(rand(-1, 1), 0, rand(-1, 1)).normalize().multiplyScalar(120);
    this.phase = 0; this.iced = 0; this.burning = 0;
    // marker
    const mk = new THREE.Sprite(mgr.markerMat(this.friendly ? 'friendly' : this.boss ? 'boss' : 'enemy'));
    mk.scale.set(0.035, 0.035, 1);
    mk.material.sizeAttenuation = false;
    mk.renderOrder = 20;
    this.marker = mk; mgr.scene.add(mk);
  }
  damage(amt, at) {
    if (!this.alive || this.friendly) return;
    this.hp -= amt;
    this.flash = 0.08;
    if (this.boss && this.mgr.onBossHit) this.mgr.onBossHit(this);
    if (this.hp <= 0) this.die();
  }
  die() {
    this.alive = false;
    const fx = this.mgr.fx;
    fx.explosion(this.pos.clone().add(_v.set(0, this.ground ? 1.5 : 0, 0)), this.boss ? 3.5 : this.type === 'drone' ? 1.0 : 1.8, this.mgr.player.bodyPos);
    if (this.ground || this.boss) {
      this.burning = this.boss ? 30 : 14;
      this.mesh.traverse((o) => { if (o.isMesh) { o.material = o.material.clone(); if (o.material.color) o.material.color.multiplyScalar(0.25); } });
      this.mgr.wrecks.push(this);
    } else {
      this.falling = true;
      this.mgr.wrecks.push(this);
    }
    this.marker.visible = false;
  }
  remove() {
    this.mgr.scene.remove(this.mesh); this.mgr.scene.remove(this.marker);
  }

  update(dt) {
    const P = this.mgr.player;
    const C = this.mgr.combat;
    const pp = P.bodyPos;
    this.t += dt;
    this.cool -= dt;
    const toP = _v.copy(pp).sub(this.pos);
    const dist = toP.length();
    const stealth = P.suit && P.suit.stats.stealth;
    const detect = (stealth ? 260 : 700) * (this.opts.aggro || 1);
    const sees = P.alive && P.suited && dist < detect && !this.mgr.ceasefire;
    const spread = (stealth ? 0.07 : 0.03) + (P.speed > 60 ? 0.02 : 0);
    const muzzle = (y = 0) => this.pos.clone().add(_w.set(0, y, 0));

    switch (this.type) {
      case 'drone': {
        // orbit the player at standoff distance, bob, strafe
        const want = _w.copy(pp);
        if (sees) {
          const a = this.t * 0.4 + this.opts.seed * 6.28;
          want.x += Math.cos(a) * 55; want.z += Math.sin(a) * 55; want.y += 12 + Math.sin(this.t * 0.7) * 10;
        } else if (this.opts.home) want.copy(this.opts.home).add(_w.set(Math.cos(this.t * 0.3) * 30, Math.sin(this.t) * 4, Math.sin(this.t * 0.3) * 30));
        const acc = want.sub(this.pos).clampLength(0, 40).multiplyScalar(0.8);
        this.vel.addScaledVector(acc, dt).multiplyScalar(Math.exp(-0.6 * dt)).clampLength(0, 55);
        this.pos.addScaledVector(this.vel, dt);
        const gh = heightAt(this.pos.x, this.pos.z) + 6;
        if (this.pos.y < gh) { this.pos.y = gh; this.vel.y = Math.abs(this.vel.y); }
        resolveSphere(this.pos, this.radius);
        this.mesh.position.copy(this.pos);
        this.mesh.lookAt(pp);
        if (sees && this.cool <= 0 && dist < 400) {
          this.cool = rand(1.2, 2.4) / (this.opts.fireMult || 1);
          C.fire('bolt', muzzle(), toP.clone().normalize(), 6 * (this.opts.dmgMult || 1), { spread });
          this.mgr.audio.enemyShot(dist);
        }
        break;
      }
      case 'turret': {
        const head = this.mesh.userData.head;
        if (sees) {
          const yaw = Math.atan2(toP.x, toP.z);
          head.rotation.y = yaw;
          if (this.cool <= 0 && dist < 500) {
            this.cool = rand(0.9, 1.6);
            C.fire('bolt', muzzle(2), toP.clone().normalize(), 7 * (this.opts.dmgMult || 1), { spread });
            this.mgr.audio.enemyShot(dist);
          }
        }
        this.mesh.position.copy(this.pos);
        break;
      }
      case 'tank': {
        const head = this.mesh.userData.head;
        if (sees) {
          if (dist > 120) {
            const dir = _w.set(toP.x, 0, toP.z).normalize();
            this.pos.addScaledVector(dir, 4 * dt);
            this.mesh.rotation.y = THREE.MathUtils.lerp(this.mesh.rotation.y, Math.atan2(dir.x, dir.z), dt);
          }
          head.rotation.y = Math.atan2(toP.x, toP.z) - this.mesh.rotation.y;
          if (this.cool <= 0 && dist < 600) {
            this.cool = rand(3, 4.5);
            // lob a shell with lead
            const aim = toP.clone().addScaledVector(P.vel, dist / 130).normalize();
            aim.y += dist * 0.00012;
            C.fire('shell', muzzle(2.4), aim.normalize(), 16 * (this.opts.dmgMult || 1), { spread: spread * 0.5 });
            this.mgr.fx.muzzle(muzzle(2.4), [1, 0.7, 0.3]);
            this.mgr.audio.enemyShot(dist * 0.5);
          }
        }
        this.pos.y = heightAt(this.pos.x, this.pos.z);
        this.mesh.position.copy(this.pos);
        break;
      }
      case 'jet': {
        // pursuit: aim at a point near the player, limited turn rate
        const target = _w.copy(pp).addScaledVector(P.vel, 1.2);
        if (dist < 150) target.add(this.vel.clone().multiplyScalar(4)); // overshoot then come around
        const desired = target.sub(this.pos).normalize().multiplyScalar(150);
        const f = this.vel.clone().normalize();
        this.vel.lerp(desired, Math.min(1, dt * 0.7)).setLength(150);
        const gh = heightAt(this.pos.x, this.pos.z) + 60;
        if (this.pos.y < gh) this.vel.y += 40 * dt;
        this.pos.addScaledVector(this.vel, dt);
        this.mesh.position.copy(this.pos);
        _q.setFromUnitVectors(new THREE.Vector3(0, 0, 1), this.vel.clone().normalize());
        this.mesh.quaternion.slerp(_q, Math.min(1, dt * 4));
        const bank = clamp(f.cross(this.vel.clone().normalize()).y * 30, -1.2, 1.2);
        this.mesh.rotateZ(-bank);
        if (P.alive && this.cool <= 0 && dist < 700 && toP.dot(this.vel) > 0.7 * dist * 150) {
          this.cool = this.opts.missileCool || rand(5, 8);
          C.fireEnemyMissile(this.pos.clone(), this.vel.clone().normalize(), this.opts.missileDmg || 12);
          this.mgr.audio.missile();
          if (this.mgr.onEnemyMissile) this.mgr.onEnemyMissile();
        }
        break;
      }
      case 'whiplash': {
        const flat = _w.set(toP.x, 0, toP.z);
        const fd = flat.length();
        this.phase -= dt;
        if (this.phase <= 0) this.phase = 3 + rand(0, 2);
        const dashing = this.phase < 1.2 && fd > 8;
        const sp = dashing ? 32 : 7;
        if (fd > 6) this.pos.addScaledVector(flat.normalize(), sp * dt);
        this.pos.y = Math.max(heightAt(this.pos.x, this.pos.z), this.pos.y - 15 * dt);
        resolveSphere(this.pos.add(_w.set(0, 2, 0)), 1.6); this.pos.y -= 2;
        this.mesh.position.copy(this.pos);
        this.mesh.rotation.y = Math.atan2(toP.x, toP.z);
        const whips = this.mesh.userData.whips;
        whips.forEach((w, i) => { w.rotation.x = Math.sin(this.t * 6 + i) * 0.6 - 0.2; w.rotation.y = Math.sin(this.t * 4 + i * 2) * 0.5; });
        if (dist < 13 && this.cool <= 0) { this.cool = 1.1; P.damage(14, this.pos); this.mgr.fx.sparks(pp.clone(), 25, [0.6, 0.9, 1]); this.mgr.audio.hit(); }
        if (sees && dist > 20 && this.cool <= 0) { this.cool = 0.6; C.fire('bolt', muzzle(2.7), toP.clone().normalize(), 8, { spread }); this.mgr.audio.enemyShot(dist); }
        break;
      }
      case 'monger': {
        // phases: ground assault -> airborne chase. Icing above 3000 m.
        const air = this.hp < this.maxHp * 0.6 || pp.y - heightAt(pp.x, pp.z) > 60;
        if (this.iced > 0) {
          this.iced -= dt;
          this.vel.y -= 9.8 * dt; this.pos.addScaledVector(this.vel, dt);
          const gh = heightAt(this.pos.x, this.pos.z);
          if (this.pos.y <= gh) { this.pos.y = gh; this.vel.set(0, 0, 0); this.iced = 0; this.mgr.fx.explosion(this.pos.clone(), 2, pp); }
        } else if (air) {
          const want = _w.copy(pp).add(_v.set(Math.cos(this.t) * 18, -4, Math.sin(this.t) * 18));
          const acc = want.sub(this.pos).clampLength(0, 60);
          this.vel.addScaledVector(acc, dt * 0.9).multiplyScalar(Math.exp(-0.5 * dt)).clampLength(0, 75);
          this.pos.addScaledVector(this.vel, dt);
          const gh = heightAt(this.pos.x, this.pos.z);
          if (this.pos.y < gh) this.pos.y = gh;
          if (this.pos.y > 3000 && this.iced <= 0) {
            this.iced = 6; this.vel.set(0, -5, 0); this.damage(this.maxHp * 0.35, this.pos);
            if (this.mgr.onBossIced) this.mgr.onBossIced(this);
          }
          resolveSphere(this.pos, 3);
        } else {
          const flat = _w.set(toP.x, 0, toP.z);
          if (flat.length() > 25) this.pos.addScaledVector(flat.normalize(), 6 * dt);
          // walk on whatever surface is below (terrain or rooftops)
          const g = this.mgr.groundAt(this.pos.x, this.pos.z, this.pos.y + 1.5);
          this.pos.y = Math.max(g, this.pos.y - 20 * dt);
        }
        this.mesh.position.copy(this.pos);
        this.mesh.rotation.y = Math.atan2(toP.x, toP.z);
        toP.copy(pp).sub(this.pos);
        if (sees && this.iced <= 0) {
          if (this.cool <= 0) {
            if (Math.random() < 0.3) {
              this.cool = 2.2;
              for (let k = 0; k < 3; k++) C.fireEnemyMissile(muzzle(4.5).add(_w.set(rand(-1, 1), 0, rand(-1, 1))), toP.clone().normalize().add(_w.set(rand(-0.3, 0.3), 0.4, rand(-0.3, 0.3))).normalize(), 14);
              this.mgr.audio.missile();
            } else {
              this.cool = 0.09; this.burst = (this.burst || 0) + 1;
              if (this.burst > 22) { this.burst = 0; this.cool = 2.0; }
              C.fire('cannon', muzzle(1.5), toP.clone().normalize(), 4, { spread: spread * 1.5 });
              this.mgr.audio.minigun();
            }
          }
        }
        break;
      }
    }
    if (this.flash > 0) this.flash -= dt;
    this.marker.position.copy(this.pos).add(_w.set(0, this.radius + (this.ground ? 3 : 1.5), 0));
    this.marker.visible = this.alive && dist < (this.boss ? 5000 : 1600);
  }
}

// ---------------------------------------------------------------- manager
export class Enemies {
  constructor(scene, combat, fx, audio, player) {
    this.scene = scene; this.combat = combat; this.fx = fx; this.audio = audio; this.player = player;
    this.list = []; this.wrecks = [];
    combat.enemies = this.list;
    this._markerMats = {};
    this.ceasefire = false;
  }
  markerMat(kind) {
    if (!this._markerMats[kind]) {
      const c = document.createElement('canvas'); c.width = c.height = 64;
      const g = c.getContext('2d');
      const col = kind === 'friendly' ? '#5ad1ff' : kind === 'boss' ? '#ff9a2a' : '#ff3b3b';
      g.strokeStyle = col; g.lineWidth = 6;
      g.beginPath(); g.moveTo(32, 6); g.lineTo(58, 32); g.lineTo(32, 58); g.lineTo(6, 32); g.closePath(); g.stroke();
      g.fillStyle = col; g.beginPath(); g.arc(32, 32, 5, 0, 7); g.fill();
      const t = new THREE.CanvasTexture(c);
      this._markerMats[kind] = new THREE.SpriteMaterial({ map: t, depthTest: false, depthWrite: false, transparent: true, fog: false, toneMapped: false });
    }
    return this._markerMats[kind].clone();
  }
  spawn(type, pos, opts = {}) {
    opts.seed = opts.seed ?? Math.random();
    const e = new Enemy(this, type, pos, opts);
    this.list.push(e);
    return e;
  }
  aliveCount(tag) { return this.list.filter((e) => e.alive && !e.friendly && (!tag || e.tag === tag)).length; }
  clear(tag = null) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const e = this.list[i];
      if (!tag || e.tag === tag) { e.remove(); this.list.splice(i, 1); }
    }
    this.wrecks = this.wrecks.filter((w) => this.list.includes(w));
  }
  update(dt) {
    for (const e of this.list) if (e.alive) e.update(dt);
    for (let i = this.wrecks.length - 1; i >= 0; i--) {
      const w = this.wrecks[i];
      if (w.falling) {
        w.vel.y -= 9.8 * dt; w.pos.addScaledVector(w.vel, dt);
        w.mesh.position.copy(w.pos); w.mesh.rotation.x += dt * 2; w.mesh.rotation.z += dt * 3;
        if (Math.random() < 0.6) w.mgr.fx.smokeColumn(w.pos);
        if (w.pos.y < heightAt(w.pos.x, w.pos.z)) { this.fx.explosion(w.pos.clone(), 0.8, this.player.bodyPos); w.falling = false; w.burning = 4; w.mesh.visible = false; }
      } else if (w.burning > 0) {
        w.burning -= dt;
        if (Math.random() < 0.5) this.fx.smokeColumn(w.pos.clone().add(_v.set(0, 2, 0)));
      } else {
        this.wrecks.splice(i, 1);
        const idx = this.list.indexOf(w);
        if (idx >= 0 && !w.alive) { w.remove(); this.list.splice(idx, 1); }
      }
    }
  }
}
