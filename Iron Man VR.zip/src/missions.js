import * as THREE from 'three';
import { heightAt, roadPoints } from './world/terrain.js';
import { groundAt } from './world/colliders.js';
import { CITY, TOWER, EXPO, HQ, GULMIRA, MANSION, coastX } from './world/layout.js';
import { cityRoads, REACTOR } from './world/city.js';
import { fmtTime, rand, mulberry32 } from './util.js';

const _v = new THREE.Vector3();
const V = (x, y, z) => new THREE.Vector3(x, y, z);
const above = (x, z, h) => V(x, heightAt(x, z) + h, z);

// ---------------------------------------------------------------- ring courses
function coastCourse() {
  const r = [];
  for (let i = 0; i < 16; i++) {
    const z = 260 + i * 240;
    const x = coastX(z) - 30 + Math.sin(i * 1.3) * 25;
    r.push(V(x, Math.max(14, heightAt(x, z) + 14) + 12 * Math.sin(i * 0.9) + 10, z));
  }
  // swing inland and back to the mansion
  r.push(above(coastX(4300) + 300, 4300, 60), above(600, 3000, 70), above(400, 1500, 50), V(-40, 95, 200), V(-30, 110, 0));
  return r;
}
function cityCourse() {
  const r = [];
  const sx = cityRoads.x[5], ez = cityRoads.z[14];
  for (let i = 0; i < 8; i++) r.push(V(sx + (i % 2 ? 8 : -8), CITY.y + 22 + (i % 3) * 14, cityRoads.z[3] + i * 150));
  for (let i = 1; i < 8; i++) r.push(V(sx + i * 150, CITY.y + 26 + (i % 2) * 22, ez + (i % 2 ? 8 : -8)));
  r.push(V(TOWER.x - 34, CITY.y + 236, TOWER.z)); // finish over the Stark Tower pad
  return r;
}
function canyonCourse() {
  const rnd = mulberry32(5);
  const r = [];
  let x = 1300, z = -900;
  for (let i = 0; i < 18; i++) {
    x += 120 + rnd() * 160; z -= 200 + rnd() * 80;
    const y = heightAt(x, z) + 25 + rnd() * 30;
    r.push(V(x, y, z));
  }
  return r;
}

// ---------------------------------------------------------------- caches
export const CACHES = [
  [-95, 12, 60, 'Below the mansion cliffs'], [TOWER.x, 30 + 330, TOWER.z, 'Top of the Stark Tower spire'], [EXPO.x, 30 + 72, EXPO.z, 'Inside the Unisphere'],
  [REACTOR.x, REACTOR.top + 4, REACTOR.z, 'On the arc reactor'], [GULMIRA.x, null, GULMIRA.z + 40, 'Gulmira village square'], [-900, 6, 1800, 'Offshore, west of Malibu'],
  [700, null, -2600, 'Hills north of the mansion'], [2600, null, -4300, 'High in the mountains'], [4800, null, -3600, 'A mountain valley'],
  [1200, null, 2400, 'Inland hills, south-east'], [CITY.x + 1200, 30 + 4, CITY.z - 1100, 'City outskirts (NE)'], [CITY.x - 1300, 30 + 4, CITY.z + 1300, 'City outskirts (SW)'],
  [HQ.x - 110, HQ.y + 40, HQ.z, 'Stark Industries rooftop'], [3600, null, -7600, 'Desert canyon'], [1600, null, -9600, 'Deep desert'],
  [-400, 6, -2400, 'Off the northern coast'], [-250, 6, 3600, 'Off the southern coast'], [6800, null, 400, 'Far east hills'],
  [5200, null, -1900, 'Ridge above the city'], [2000, null, 900, 'Along the coastal highway'],
].map(([x, y, z, hint], i) => ({ id: i, pos: V(x, y ?? heightAt(x, z) + 3, z), hint }));

// ---------------------------------------------------------------- definitions
function defs(game) {
  const spawnDrones = (center, n, tag, spread = 150, opts = {}) => {
    for (let i = 0; i < n; i++) {
      const p = center.clone().add(V(rand(-spread, spread), rand(20, 70), rand(-spread, spread)));
      p.y = Math.max(p.y, heightAt(p.x, p.z) + 25);
      game.enemies.spawn('drone', p, { tag, home: center.clone().setY(p.y), ...opts });
    }
  };
  const tower = V(TOWER.x, CITY.y + 120, TOWER.z);
  const gul = V(GULMIRA.x, GULMIRA.y, GULMIRA.z);
  return [
    { id: 'm1', main: true, title: '1 · Flight Test', where: 'Malibu — Stark Mansion', reward: 'Mark XLVI armor', unlock: 'm1',
      desc: "Your first real test flight. Calibrate the flight stabilizers, run a lap of the Malibu coast, and then push it — let's see how high this thing can go. (Tip: wear the Mark II for the full movie experience.)",
      start: V(-30, 110, 0),
      steps: [
        { type: 'hover', text: 'Hover 3–20 m above the ground', say: "Let's start nice and easy. Hold both palms down and squeeze the triggers gently. Hover for me, sir.", hold: 3 },
        { type: 'rings', rings: () => coastCourse().slice(0, 12), text: 'Fly through the rings', say: 'Stabilizers calibrated. Now follow the course along the coast.' },
        { type: 'altitude', alt: 3500, text: 'Climb to 3,500 m', say: "Let's push the envelope. Take us up to three thousand five hundred meters. The SR-71 record is out of reach — for now." },
        { type: 'land', pos: V(0, 75.2, 0), radius: 60, text: 'Land back at the mansion', say: "Impressive. Now bring it home, and try not to land on the piano." },
      ] },
    { id: 'm2', main: true, title: '2 · Gulmira', where: 'Gulmira — desert', reward: 'Mark V "Suitcase"', unlock: 'm2', after: 'm1',
      desc: 'The Ten Rings have taken Gulmira using weapons with the Stark Industries logo on them. Fly to the village, destroy their armor and turrets — then deal with the Air Force, who think you are a UFO.',
      start: V(GULMIRA.x, GULMIRA.y + 300, GULMIRA.z + 2400),
      steps: [
        { type: 'goto', pos: () => gul.clone().add(V(0, 120, 0)), radius: 650, text: 'Fly to Gulmira', say: 'Gulmira is about nine kilometers north-east. The Ten Rings are there with our weapons.' },
        { type: 'kill', text: 'Destroy the Ten Rings forces', say: 'Multiple hostiles. Tanks and anti-air turrets. Mind the civilians.', checkpoint: () => gul.clone().add(V(0, 180, 900)),
          spawn: (tag) => {
            for (let i = 0; i < 5; i++) { const a = i / 5 * 6.28; game.enemies.spawn('tank', V(GULMIRA.x + Math.cos(a) * 220, 0, GULMIRA.z + Math.sin(a) * 220), { tag }); }
            for (let i = 0; i < 6; i++) { const a = i / 6 * 6.28 + 0.5; game.enemies.spawn('turret', V(GULMIRA.x + Math.cos(a) * 340, 0, GULMIRA.z + Math.sin(a) * 340), { tag }); }
          } },
        { type: 'survive', time: 40, text: 'Evade the F-22 Raptors — DO NOT shoot them', say: "Sir, two F-22 Raptors are on an intercept course. They're ours — don't shoot them. Evade until Colonel Rhodes calls them off.",
          spawn: (tag) => {
            for (let i = 0; i < 2; i++) game.enemies.spawn('jet', game.player.bodyPos.clone().add(V(-1500 + i * 300, 200, 1500)), { tag, friendly: true, missileCool: 7, missileDmg: 10 });
          }, onEnd: () => game.audio.say('Colonel Rhodes called off the Raptors. Nicely flown, sir.') },
      ] },
    { id: 'm3', main: true, title: '3 · Drone Swarm', where: 'Downtown — Stark Tower', reward: 'Mark VI armor', unlock: 'm3', after: 'm2',
      desc: "Justin Hammer's drones have been hacked and are swarming downtown. Clear three waves around Stark Tower, then land on the tower's pad.",
      start: tower,
      steps: [
        { type: 'goto', pos: () => tower, radius: 700, text: 'Fly to Stark Tower', say: 'Hammer drones are attacking downtown. Stark Tower is the target.' },
        { type: 'kill', text: 'Wave 1 — destroy the drones', say: 'First wave inbound.', checkpoint: () => tower.clone().add(V(-400, 60, 0)), spawn: (tag) => spawnDrones(tower, 8, tag, 220) },
        { type: 'kill', text: 'Wave 2 — destroy the drones', say: 'Second wave. They are adapting to your flight patterns.', checkpoint: () => tower.clone().add(V(-400, 60, 0)), spawn: (tag) => spawnDrones(tower, 12, tag, 260, { fireMult: 1.2 }) },
        { type: 'kill', text: 'Wave 3 — destroy the drones', say: 'Final wave. Give them everything.', checkpoint: () => tower.clone().add(V(-400, 60, 0)), spawn: (tag) => spawnDrones(tower, 16, tag, 300, { fireMult: 1.3 }) },
        { type: 'land', pos: V(TOWER.x - 34, CITY.y + 232.6, TOWER.z), radius: 20, text: 'Land on the Stark Tower pad', say: 'Downtown is clear. Touch down on the tower pad, sir.' },
      ] },
    { id: 'm4', main: true, title: '4 · Expo Showdown', where: 'Stark Expo', reward: 'War Machine armor', unlock: 'm4', after: 'm3',
      desc: "Ivan Vanko has crashed the Stark Expo in his Whiplash armor, backed by Hammer drones. Clear the drones, then take Whiplash down — keep your distance from those whips.",
      start: V(EXPO.x, CITY.y + 150, EXPO.z),
      steps: [
        { type: 'goto', pos: () => V(EXPO.x, CITY.y + 90, EXPO.z), radius: 600, text: 'Fly to the Stark Expo', say: 'Trouble at the Expo, sir. Multiple drones and one very angry Russian.' },
        { type: 'kill', text: 'Destroy the Hammer drones', checkpoint: () => V(EXPO.x - 400, CITY.y + 100, EXPO.z), spawn: (tag) => spawnDrones(V(EXPO.x, CITY.y + 60, EXPO.z), 12, tag, 250) },
        { type: 'kill', boss: true, text: 'Defeat Whiplash', say: "Whiplash is on the ground. His whips cut through anything — stay out of reach and use the unibeam.", checkpoint: () => V(EXPO.x - 300, CITY.y + 80, EXPO.z),
          spawn: (tag) => { game.enemies.spawn('whiplash', V(EXPO.x + 60, CITY.y, EXPO.z + 80), { tag }); spawnDrones(V(EXPO.x, CITY.y + 60, EXPO.z), 4, tag + '_x', 200); } },
      ] },
    { id: 'm5', main: true, title: '5 · Iron Monger', where: 'Stark Industries HQ', reward: 'Mark VII + Hulkbuster', unlock: 'm5', after: 'm4',
      desc: "Obadiah Stane has built his own armor — bigger, stronger, and armed to the teeth. Stop him at Stark Industries. Remember how the Mark II nearly froze? His suit has the same icing problem.",
      start: V(HQ.x, HQ.y + 200, HQ.z),
      steps: [
        { type: 'goto', pos: () => V(HQ.x, HQ.y + 80, HQ.z), radius: 600, text: 'Fly to Stark Industries', say: "Obadiah is at Stark Industries. Sir — Ms. Potts is inside." },
        { type: 'kill', text: 'Destroy the security drones', checkpoint: () => V(HQ.x - 500, HQ.y + 120, HQ.z), spawn: (tag) => spawnDrones(V(HQ.x, HQ.y + 40, HQ.z), 8, tag, 200) },
        { type: 'kill', boss: true, text: 'Defeat the Iron Monger', say: "Here he comes. He's too strong head on — try luring him above three thousand meters. How did he solve the icing problem? He didn't.", checkpoint: () => V(HQ.x - 400, HQ.y + 150, HQ.z),
          spawn: (tag) => game.enemies.spawn('monger', V(REACTOR.x, REACTOR.top + 1, REACTOR.z), { tag }) },
      ], finale: true },

    // ---------------- side quests
    { id: 'race_coast', title: 'Race · Malibu Coast Run', where: 'Malibu coast', race: [95, 120, 150], course: coastCourse,
      desc: 'Thread the rings along the Malibu cliffs and back to the mansion. Beat the gold time!', start: coastCourse()[0] },
    { id: 'race_city', title: 'Race · Downtown Slalom', where: 'Downtown', race: [55, 72, 95], course: cityCourse,
      desc: 'Weave through the street canyons and finish over the Stark Tower landing pad.', start: cityCourse()[0] },
    { id: 'race_canyon', title: 'Race · Canyon Dash', where: 'Northern mountains', race: [70, 90, 120], course: canyonCourse,
      desc: 'Low and fast through the northern mountains. Clip a ridge and it is over.', start: canyonCourse()[0] },
    { id: 'hunt_coast', title: 'Drone Hunt · Coast', where: 'Malibu coast', hunt: V(-200, 80, 1500), desc: 'Rogue drones are buzzing the beaches. Destroy two waves.', start: V(-200, 120, 1500) },
    { id: 'hunt_city', title: 'Drone Hunt · Downtown', where: 'Downtown (east)', hunt: V(CITY.x + 900, CITY.y + 90, CITY.z - 700), desc: 'A drone swarm is circling the eastern towers. Two waves.', start: V(CITY.x + 900, CITY.y + 150, CITY.z - 700) },
    { id: 'hunt_mtn', title: 'Drone Hunt · Mountains', where: 'Northern mountains', hunt: V(2600, 700, -3800), desc: 'Hammer is testing drones in the mountains. Two waves, high altitude.', start: V(2600, 800, -3800) },
    { id: 'rescue', title: 'Rescue · Tower Fire', where: 'Downtown (west)', unlock: 'side_rescue', desc: 'A fire is spreading across downtown rooftops. Carry four civilians, one at a time, to the paramedics in the plaza by Stark Tower.', start: V(CITY.x - 600, CITY.y + 160, CITY.z + 500) },
    { id: 'caches', title: 'Stark Tech Caches', where: 'Everywhere', desc: 'Twenty prototype caches are hidden around the map. Fly through one to collect it. 10 caches unlock the Mark XVI, all 20 unlock the Mark LXXXV. Setting this as a waypoint points you to the nearest one.', start: null },
  ];
}

// ---------------------------------------------------------------- runtime
export class Missions {
  constructor(game) {
    this.g = game;
    this.defs = defs(game);
    this.active = null;
    this.manualWaypoint = null;
    this.ringMeshes = [];
    this.civs = [];
    const scene = game.scene;
    // waypoint beacon
    this.beacon = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 1200, 16, 1, true), new THREE.MeshBasicMaterial({ color: 0xffd34a, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    this.beacon.visible = false; this.beacon.frustumCulled = false;
    scene.add(this.beacon);
    // ring resources
    this.ringGeo = new THREE.TorusGeometry(9, 0.6, 10, 48);
    this.ringMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xffc93a).multiplyScalar(1.8), transparent: true, opacity: 0.95, toneMapped: false });
    this.ringMatNext = new THREE.MeshBasicMaterial({ color: new THREE.Color(0x7fd8ff).multiplyScalar(1.4), transparent: true, opacity: 0.5, toneMapped: false });
    // caches
    this.cacheGroup = new THREE.Group(); scene.add(this.cacheGroup);
    const cacheGeo = new THREE.BoxGeometry(1.4, 1.4, 1.4);
    const cacheMat = new THREE.MeshStandardMaterial({ color: 0x2b2d31, metalness: 0.9, roughness: 0.3, emissive: 0x2fa8ff, emissiveIntensity: 0.6 });
    const glowMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0x7fd8ff).multiplyScalar(2), toneMapped: false, transparent: true, opacity: 0.9 });
    this.cacheMeshes = CACHES.map((c) => {
      const g = new THREE.Group();
      g.add(new THREE.Mesh(cacheGeo, cacheMat));
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1.6, 0.06, 6, 32), glowMat); g.add(ring);
      const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 40, 6, 1, true), new THREE.MeshBasicMaterial({ color: 0x7fd8ff, transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending, depthWrite: false }));
      beam.position.y = 20; g.add(beam);
      g.position.copy(c.pos);
      this.cacheGroup.add(g);
      return g;
    });
    // ambulance zone for the rescue quest
    this.dropZone = V(TOWER.x - 70, CITY.y, TOWER.z + 30);
    this.lastPos = new THREE.Vector3();
    this.refreshCaches();
  }

  list() { return this.defs; }
  def(id) { return this.defs.find((d) => d.id === id); }
  status(id) {
    const d = this.def(id), s = this.g.save.data;
    if (s.done.includes(id)) return 'done';
    if (d.after && !s.done.includes(d.after)) return 'locked';
    return 'open';
  }
  bestText(id) {
    const d = this.def(id), s = this.g.save.data;
    if (d.race && s.races[id]) {
      const t = s.races[id];
      const medal = t <= d.race[0] ? '🥇 GOLD' : t <= d.race[1] ? '🥈 SILVER' : t <= d.race[2] ? '🥉 BRONZE' : '';
      return `Best ${fmtTime(t)} ${medal}`;
    }
    if (d.race) return `Gold ${fmtTime(d.race[0])}`;
    if (id === 'caches') return `${s.caches.length}/20`;
    return '';
  }

  refreshCaches() {
    const got = this.g.save.data.caches;
    this.cacheMeshes.forEach((m, i) => (m.visible = !got.includes(i)));
  }

  setWaypoint(id) {
    const d = this.def(id);
    if (id === 'caches') {
      const got = this.g.save.data.caches;
      const p = this.g.player.headPos;
      const rest = CACHES.filter((c) => !got.includes(c.id)).sort((a, b) => a.pos.distanceTo(p) - b.pos.distanceTo(p));
      if (rest.length) { this.manualWaypoint = rest[0].pos.clone(); this.g.hud.toast('Nearest cache: ' + rest[0].hint, '#7fd8ff', 5); }
      return;
    }
    this.manualWaypoint = d.start ? d.start.clone() : null;
    this.g.hud.toast('Waypoint set: ' + d.title, '#ffd34a');
  }

  start(id) {
    const d = this.def(id);
    if (id === 'caches') { this.setWaypoint('caches'); return; }
    if (this.status(id) === 'locked') return;
    this.abort(true);
    if (!this.g.player.suited) this.g.deploySuit(this.g.save.data.suit || 'mk3');
    this.manualWaypoint = null;
    const steps = d.steps ? d.steps.slice() : this.sideSteps(d);
    this.active = { def: d, steps, i: -1, t: 0, failed: false };
    this.g.hud.banner(d.title.replace(/^\d · /, ''), d.where, '#ffd34a', 4);
    this.next();
  }

  sideSteps(d) {
    if (d.race) {
      const course = d.course();
      return [
        { type: 'goto', pos: () => course[0], radius: 40, text: 'Fly to the start ring', say: `${d.title.replace('Race · ', '')}. Fly to the start ring when ready.` },
        { type: 'rings', rings: () => course.slice(1), text: 'Race! Fly through every ring', race: true, say: 'Go!' },
      ];
    }
    if (d.hunt) {
      const c = d.hunt;
      const sp = (tag, n) => { for (let i = 0; i < n; i++) { const p = c.clone().add(V(rand(-200, 200), rand(0, 60), rand(-200, 200))); p.y = Math.max(p.y, heightAt(p.x, p.z) + 30); this.g.enemies.spawn('drone', p, { tag, home: c.clone() }); } };
      return [
        { type: 'goto', pos: () => c, radius: 500, text: 'Fly to the drone sighting' },
        { type: 'kill', text: 'Wave 1 — destroy the drones', spawn: (tag) => sp(tag, 7), checkpoint: () => c.clone().add(V(-350, 50, 0)) },
        { type: 'kill', text: 'Wave 2 — destroy the drones', spawn: (tag) => sp(tag, 11), checkpoint: () => c.clone().add(V(-350, 50, 0)), say: 'More of them. Second wave.' },
      ];
    }
    if (d.id === 'rescue') {
      return [
        { type: 'goto', pos: () => d.start, radius: 500, text: 'Fly to the fire', say: 'Four civilians are trapped on burning rooftops downtown.' },
        { type: 'rescue', text: 'Rescue civilians', say: 'Fly close to a civilian to grab them, then bring them to the paramedics by Stark Tower.' },
      ];
    }
    return [];
  }

  abort(silent = false) {
    if (!this.active) return;
    this.cleanupStep();
    this.g.enemies.clear();
    this.g.combat.clearHostile();
    this.active = null;
    if (!silent) this.g.hud.toast('Mission aborted', '#ff7a6a');
  }

  cleanupStep() {
    for (const r of this.ringMeshes) this.g.scene.remove(r);
    this.ringMeshes = [];
    for (const c of this.civs) this.g.scene.remove(c.mesh);
    this.civs = [];
    if (this.fireTimer) this.fireTimer = null;
  }

  next() {
    const A = this.active;
    this.cleanupStep();
    A.i++;
    A.t = 0;
    if (A.i >= A.steps.length) return this.complete();
    const st = (A.step = A.steps[A.i]);
    st.tag = A.def.id + '_' + A.i;
    st.progress = 0; st.holdT = 0;
    if (st.say) this.g.audio.say(st.say);
    if (st.type === 'rings') this.setupRings(st);
    if (st.type === 'kill' || st.type === 'survive') { st.spawn && st.spawn(st.tag); st.total = this.g.enemies.aliveCount(st.tag); }
    if (st.type === 'rescue') this.setupRescue(st);
    if (st.type === 'survive') { this.g.enemies.list.forEach((e) => { if (e.tag === st.tag) e.friendly = true; }); }
  }

  complete() {
    const A = this.active, d = A.def, s = this.g.save.data;
    this.active = null;
    let msg = '';
    if (d.race) {
      const t = A.raceTime;
      const prev = s.races[d.id];
      if (!prev || t < prev) s.races[d.id] = t;
      const medal = t <= d.race[0] ? 'GOLD' : t <= d.race[1] ? 'SILVER' : t <= d.race[2] ? 'BRONZE' : 'FINISHED';
      msg = `${fmtTime(t)} — ${medal}${!prev || t < prev ? ' (new best!)' : ''}`;
      this.g.audio.say(`Course complete. ${medal === 'GOLD' ? 'Gold time, sir. Showing off?' : 'Not bad. You could shave a few seconds off that.'}`);
    }
    if (!s.done.includes(d.id)) s.done.push(d.id);
    const before = this.g.unlockedCount();
    if (d.unlock && !s.unlocks.includes(d.unlock)) s.unlocks.push(d.unlock);
    // side-quest unlock rules
    const hunts = ['hunt_coast', 'hunt_city', 'hunt_mtn'].filter((h) => s.done.includes(h)).length;
    if (hunts >= 2 && !s.unlocks.includes('side_drones')) s.unlocks.push('side_drones');
    if (['race_coast', 'race_city', 'race_canyon'].every((r) => s.done.includes(r)) && !s.unlocks.includes('side_races')) s.unlocks.push('side_races');
    this.g.save.write();
    this.g.refreshPods();
    this.g.audio.ui('success');
    if (d.finale) {
      this.g.hud.banner('I AM IRON MAN', 'Main story complete — Mark VII and the Hulkbuster are now in the Hall of Armor', '#ffd34a', 9);
      this.g.audio.say('Sir, the press conference is in an hour. I have prepared a statement. Perhaps you should stick to the cards this time.');
    } else this.g.hud.banner('MISSION COMPLETE', msg || (d.reward ? 'Unlocked: ' + d.reward : d.title), '#8fffa8', 6);
    if (this.g.unlockedCount() > before) setTimeout(() => this.g.hud.toast('New armor in the Hall of Armor!', '#ffd34a', 5), 2500);
    this.g.combat.clearHostile();
  }

  fail(reason) {
    if (!this.active) return;
    this.g.hud.banner('MISSION FAILED', reason, '#ff6a5a', 5);
    this.g.audio.say('Mission failed. ' + reason);
    this.abort(true);
  }

  // on player death mid-mission: restart the current step from its checkpoint
  checkpointFor() {
    const A = this.active;
    if (!A || !A.step) return null;
    const st = A.step;
    if (st.checkpoint) return st.checkpoint();
    return null;
  }
  restartStep() {
    const A = this.active;
    if (!A) return;
    this.g.enemies.clear();
    this.g.combat.clearHostile();
    A.i--;
    this.next();
  }

  setupRings(st) {
    st.ringList = (typeof st.rings === 'function' ? st.rings() : st.rings).map((p) => p.clone());
    st.idx = 0;
    for (let i = 0; i < st.ringList.length; i++) {
      const m = new THREE.Mesh(this.ringGeo, i === 0 ? this.ringMat : this.ringMatNext);
      m.position.copy(st.ringList[i]);
      const nxt = st.ringList[Math.min(i + 1, st.ringList.length - 1)], prv = st.ringList[Math.max(i - 1, 0)];
      _v.copy(nxt).sub(prv); if (_v.lengthSq() < 1) _v.set(0, 0, 1);
      m.lookAt(m.position.clone().add(_v));
      m.visible = i < 3;
      this.g.scene.add(m);
      this.ringMeshes.push(m);
    }
    if (st.race) this.active.raceStart = performance.now();
  }

  setupRescue(st) {
    const g = this.g;
    const center = V(CITY.x - 600, 0, CITY.z + 500);
    const cands = g.city.buildings.filter((b) => b.h > 60 && b.h < 140 && Math.hypot(b.x - center.x, b.z - center.z) < 450).slice(0, 40);
    const picks = [];
    for (let i = 0; i < cands.length && picks.length < 4; i += Math.max(1, Math.floor(cands.length / 4))) picks.push(cands[i]);
    const skin = new THREE.MeshStandardMaterial({ color: 0xd1a07c });
    const cloth = [0x2a5db0, 0xb03a2e, 0x2e8b57, 0x8e44ad].map((c) => new THREE.MeshStandardMaterial({ color: c }));
    picks.forEach((b, i) => {
      const mesh = new THREE.Group();
      const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.8, 4, 8), cloth[i]); body.position.y = 0.75;
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), skin); head.position.y = 1.5;
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.55, 4, 6), cloth[i]); arm.position.set(0.3, 1.45, 0); arm.rotation.z = -2.6;
      mesh.add(body, head, arm);
      mesh.userData.arm = arm;
      mesh.position.set(b.x, groundAt(b.x, b.z, b.h + 50), b.z);
      g.scene.add(mesh);
      this.civs.push({ mesh, state: 'waiting', fire: new THREE.Vector3(b.x + 4, mesh.position.y, b.z + 3) });
    });
    st.total = this.civs.length; st.progress = 0;
    st.carrying = null;
  }

  waypoint() {
    const A = this.active;
    if (A && A.step) {
      const st = A.step;
      if (st.type === 'goto') return typeof st.pos === 'function' ? st.pos() : st.pos;
      if (st.type === 'land') return st.pos;
      if (st.type === 'rings') return st.ringList[st.idx];
      if (st.type === 'rescue') {
        if (st.carrying) return this.dropZone;
        const c = this.civs.find((c) => c.state === 'waiting');
        return c ? c.mesh.position : null;
      }
      if (st.type === 'kill') {
        const e = this.g.enemies.list.find((e) => e.alive && e.tag === st.tag);
        return e ? e.pos : null;
      }
    }
    return this.manualWaypoint;
  }

  hudInfo() {
    const A = this.active;
    if (!A || !A.step) return null;
    const st = A.step, d = A.def;
    const lines = [st.text];
    let timer = null;
    if (st.type === 'rings') lines.push(`Ring ${st.idx + 1} / ${st.ringList.length}`);
    if (st.type === 'kill') lines.push(`${st.total - this.g.enemies.aliveCount(st.tag)} / ${st.total} destroyed`);
    if (st.type === 'survive') timer = st.time - A.t;
    if (st.type === 'altitude') lines.push(`Altitude ${Math.round(this.g.player.altitude)} / ${st.alt} m`);
    if (st.type === 'hover') lines.push(`Hold steady ${Math.max(0, st.hold - st.holdT).toFixed(1)} s`);
    if (st.type === 'rescue') lines.push(`${st.progress} / ${st.total} rescued${st.carrying ? ' — carrying 1' : ''}`);
    if (st.race && A.raceStart) timer = (performance.now() - A.raceStart) / 1000;
    return { title: d.title.toUpperCase(), lines, timer };
  }

  update(dt) {
    const g = this.g, P = g.player;
    const pos = P.bodyPos;
    // caches (always active)
    const got = g.save.data.caches;
    this.cacheMeshes.forEach((m, i) => {
      if (!m.visible) return;
      m.rotation.y += dt; m.children[1].rotation.x += dt * 2;
      if (P.suited && m.position.distanceTo(pos) < 7) {
        m.visible = false; got.push(i);
        g.audio.ui('pickup');
        g.hud.toast(`STARK TECH CACHE ${got.length} / 20`, '#7fd8ff', 4);
        if (got.length === 10) { g.save.data.unlocks.push('side_caches10'); g.hud.toast('Mark XVI unlocked!', '#ffd34a', 5); }
        if (got.length === 20) { g.save.data.unlocks.push('side_caches20'); g.hud.toast('Mark LXXXV unlocked!', '#ffd34a', 5); }
        g.save.write(); g.refreshPods();
        if (this.manualWaypoint && this.manualWaypoint.distanceTo(m.position) < 1) this.manualWaypoint = null;
      }
    });
    if (this.manualWaypoint && this.manualWaypoint.distanceTo(pos) < 40) { this.manualWaypoint = null; g.hud.toast('Waypoint reached'); }

    // beacon
    const wp = this.waypoint();
    if (wp && P.suited) {
      const dist = Math.hypot(wp.x - pos.x, wp.z - pos.z);
      const ringStep = this.active && this.active.step && this.active.step.type === 'rings';
      this.beacon.visible = dist > (ringStep ? 700 : 150);
      this.beacon.material.opacity = 0.25 * Math.min(1, (dist - 150) / 500);
      this.beacon.position.set(wp.x, heightAt(wp.x, wp.z) + 600, wp.z);
      this.beacon.scale.set(1 + dist / 500, 1, 1 + dist / 500);
    } else this.beacon.visible = false;

    const A = this.active;
    if (!A || !A.step || !P.alive) { this.lastPos.copy(pos); return; }
    const st = A.step;
    A.t += dt;
    switch (st.type) {
      case 'goto': {
        const p = typeof st.pos === 'function' ? st.pos() : st.pos;
        if (pos.distanceTo(p) < st.radius) this.next();
        break;
      }
      case 'hover': {
        const agl = P.altitude - groundAt(P.headPos.x, P.headPos.z, P.altitude + 1);
        if (P.flying && agl > 3 && agl < 20 && P.speed < 7) st.holdT += dt; else st.holdT = Math.max(0, st.holdT - dt * 0.5);
        if (st.holdT >= st.hold) { g.audio.ui('success'); this.next(); }
        break;
      }
      case 'altitude':
        if (P.altitude >= st.alt) { g.audio.ui('success'); g.audio.say(P.suit.stats.icing ? "Three thousand five hundred meters. Sir, I'd recommend descending before we become a very expensive icicle." : 'Altitude reached. Records are made to be broken, sir.'); this.next(); }
        break;
      case 'land':
        if (P.grounded && pos.distanceTo(st.pos) < st.radius) { this.next(); }
        break;
      case 'rings': {
        const target = st.ringList[st.idx];
        if (segPointDist(this.lastPos, pos, target) < 9.5) {
          this.ringMeshes[st.idx].visible = false;
          st.idx++;
          g.audio.ui('ring');
          if (st.idx >= st.ringList.length) {
            if (st.race) A.raceTime = (performance.now() - A.raceStart) / 1000;
            this.next(); break;
          }
          this.ringMeshes.forEach((m, i) => { m.visible = i >= st.idx && i < st.idx + 3; m.material = i === st.idx ? this.ringMat : this.ringMatNext; });
        }
        this.ringMeshes.forEach((m, i) => { if (i === st.idx) m.scale.setScalar(1 + Math.sin(A.t * 6) * 0.04); });
        break;
      }
      case 'kill':
        if (g.enemies.aliveCount(st.tag) === 0) {
          g.enemies.clear(st.tag + '_x');
          g.audio.ui('success');
          if (!st.boss) g.audio.say(A.i + 1 < A.steps.length ? 'Area clear.' : 'All hostiles neutralized.');
          this.next();
        }
        break;
      case 'survive':
        if (A.t >= st.time) { g.enemies.clear(st.tag); g.combat.clearHostile(); st.onEnd && st.onEnd(); this.next(); }
        break;
      case 'rescue': this.updateRescue(st, dt); break;
    }
    this.lastPos.copy(pos);
  }

  updateRescue(st, dt) {
    const g = this.g, P = g.player, pos = P.bodyPos;
    for (const c of this.civs) {
      if (c.state === 'waiting') {
        c.mesh.userData.arm.rotation.z = -2.6 + Math.sin(performance.now() * 0.01) * 0.4;
        c.mesh.lookAt(pos.x, c.mesh.position.y, pos.z);
        if (Math.random() < 0.7) g.fx.smokeColumn(c.fire);
        if (!st.carrying && c.mesh.position.distanceTo(pos) < 5) {
          c.state = 'carried'; st.carrying = c;
          g.audio.ui('pickup'); g.audio.say("Got one. Hold on tight.");
          g.hud.toast('Civilian secured — fly to the paramedics', '#8fffa8');
        }
      } else if (c.state === 'carried') {
        // dangle below the player
        c.mesh.position.lerp(_v.copy(pos).add(V(0, -2.3, 0)), Math.min(1, dt * 10));
        c.mesh.rotation.set(0, P.yaw(), 0);
        const dz = this.dropZone;
        if (Math.hypot(pos.x - dz.x, pos.z - dz.z) < 22 && P.altitude - CITY.y < 25) {
          c.state = 'saved'; st.carrying = null; st.progress++;
          c.mesh.position.set(dz.x + rand(-6, 6), CITY.y, dz.z + rand(-6, 6));
          g.audio.ui('success');
          g.hud.toast(`Civilian rescued ${st.progress} / ${st.total}`, '#8fffa8');
          if (st.progress >= st.total) { g.audio.say('Everyone is safe. The fire department will take it from here.'); this.next(); return; }
        }
      }
    }
  }
}

function segPointDist(a, b, p) {
  const abx = b.x - a.x, aby = b.y - a.y, abz = b.z - a.z;
  const l2 = abx * abx + aby * aby + abz * abz;
  let t = l2 > 0 ? ((p.x - a.x) * abx + (p.y - a.y) * aby + (p.z - a.z) * abz) / l2 : 0;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(a.x + abx * t - p.x, a.y + aby * t - p.y, a.z + abz * t - p.z);
}
