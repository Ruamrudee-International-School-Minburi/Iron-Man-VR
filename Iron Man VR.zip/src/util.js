import * as THREE from 'three';

// ---------- math ----------
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const smoothstep = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
export const rand = (a = 0, b = 1) => a + Math.random() * (b - a);
export const randInt = (a, b) => Math.floor(rand(a, b + 1));
export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const damp = (a, b, lambda, dt) => lerp(a, b, 1 - Math.exp(-lambda * dt));

// Deterministic PRNG so the world is identical every launch.
export function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- 2D simplex noise ----------
const grad3 = [[1,1],[-1,1],[1,-1],[-1,-1],[1,0],[-1,0],[0,1],[0,-1]];
const perm = new Uint8Array(512);
(() => {
  const r = mulberry32(1337);
  const p = Array.from({ length: 256 }, (_, i) => i);
  for (let i = 255; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [p[i], p[j]] = [p[j], p[i]]; }
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
})();
const F2 = 0.5 * (Math.sqrt(3) - 1), G2 = (3 - Math.sqrt(3)) / 6;
export function noise2(x, y) {
  const s = (x + y) * F2;
  const i = Math.floor(x + s), j = Math.floor(y + s);
  const t = (i + j) * G2;
  const x0 = x - (i - t), y0 = y - (j - t);
  const i1 = x0 > y0 ? 1 : 0, j1 = x0 > y0 ? 0 : 1;
  const x1 = x0 - i1 + G2, y1 = y0 - j1 + G2;
  const x2 = x0 - 1 + 2 * G2, y2 = y0 - 1 + 2 * G2;
  const ii = i & 255, jj = j & 255;
  let n = 0;
  let t0 = 0.5 - x0 * x0 - y0 * y0;
  if (t0 > 0) { const g = grad3[perm[ii + perm[jj]] & 7]; t0 *= t0; n += t0 * t0 * (g[0] * x0 + g[1] * y0); }
  let t1 = 0.5 - x1 * x1 - y1 * y1;
  if (t1 > 0) { const g = grad3[perm[ii + i1 + perm[jj + j1]] & 7]; t1 *= t1; n += t1 * t1 * (g[0] * x1 + g[1] * y1); }
  let t2 = 0.5 - x2 * x2 - y2 * y2;
  if (t2 > 0) { const g = grad3[perm[ii + 1 + perm[jj + 1]] & 7]; t2 *= t2; n += t2 * t2 * (g[0] * x2 + g[1] * y2); }
  return 70 * n; // ~[-1,1]
}
export function fbm(x, y, oct = 5) {
  let a = 1, f = 1, s = 0, n = 0;
  for (let i = 0; i < oct; i++) { s += a * noise2(x * f, y * f); n += a; a *= 0.5; f *= 2.03; }
  return s / n;
}
export function ridged(x, y, oct = 5) {
  let a = 1, f = 1, s = 0, n = 0;
  for (let i = 0; i < oct; i++) { s += a * (1 - Math.abs(noise2(x * f, y * f))); n += a; a *= 0.5; f *= 2.1; }
  return s / n;
}

// ---------- canvas textures ----------
export function canvasTexture(w, h, draw, { repeat = false, srgb = true, aniso = 8 } = {}) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d');
  draw(g, w, h);
  const tex = new THREE.CanvasTexture(c);
  if (srgb) tex.colorSpace = THREE.SRGBColorSpace;
  if (repeat) tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = aniso;
  return tex;
}

export function noiseTexture(size = 256, { base = 128, amp = 60, scale = 8, color = null } = {}) {
  // seamless: blend 4 shifted copies of the noise field
  const f = scale / size;
  const n = (x, y) => 0.65 * noise2(x * f, y * f) + 0.35 * noise2(x * f * 3.1 + 7.3, y * f * 3.1 - 2.1);
  return canvasTexture(size, size, (g, w, h) => {
    const img = g.createImageData(w, h);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const v0 = (n(x, y) * (w - x) * (h - y) + n(x - w, y) * x * (h - y) + n(x, y - h) * (w - x) * y + n(x - w, y - h) * x * y) / (w * h);
      const v = base + amp * v0 * 1.6;
      const i = (y * w + x) * 4;
      if (color) { img.data[i] = color[0] * v / 255; img.data[i + 1] = color[1] * v / 255; img.data[i + 2] = color[2] * v / 255; }
      else img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
      img.data[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
  }, { repeat: true });
}

// Tileable normal map from noise — used for ocean and metal micro detail.
export function normalMapTexture(size = 256, scale = 6, strength = 2.0) {
  const hgt = new Float32Array(size * size);
  const f = scale / size;
  const n = (x, y) => { let v = 0, a = 1, k = 1; for (let o = 0; o < 4; o++) { v += a * noise2(x * f * k + o * 17.3, y * f * k - o * 9.1); a *= 0.5; k *= 2; } return v; };
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const w = size, h = size;
    hgt[y * size + x] = (n(x, y) * (w - x) * (h - y) + n(x - w, y) * x * (h - y) + n(x, y - h) * (w - x) * y + n(x - w, y - h) * x * y) / (w * h);
  }
  const tex = canvasTexture(size, size, (g, w, h) => {
    const img = g.createImageData(w, h);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const l = hgt[y * w + ((x - 1 + w) % w)], r = hgt[y * w + ((x + 1) % w)];
      const u = hgt[((y - 1 + h) % h) * w + x], d = hgt[((y + 1) % h) * w + x];
      const k = strength * size / (scale * 3);
      let nx = (l - r) * k, ny = (u - d) * k, nz = 1;
      const len = Math.hypot(nx, ny, nz); nx /= len; ny /= len; nz /= len;
      const i = (y * w + x) * 4;
      img.data[i] = (nx * 0.5 + 0.5) * 255; img.data[i + 1] = (ny * 0.5 + 0.5) * 255; img.data[i + 2] = (nz * 0.5 + 0.5) * 255; img.data[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
  }, { repeat: true, srgb: false });
  return tex;
}

// Text label as a sprite / plane texture
export function textTexture(text, { font = 'bold 64px Arial', color = '#fff', bg = null, w = 512, h = 128, glow = null, align = 'center' } = {}) {
  return canvasTexture(w, h, (g) => {
    if (bg) { g.fillStyle = bg; g.fillRect(0, 0, w, h); }
    g.font = font; g.textAlign = align; g.textBaseline = 'middle';
    if (glow) { g.shadowColor = glow; g.shadowBlur = 18; }
    g.fillStyle = color;
    g.fillText(text, align === 'center' ? w / 2 : 10, h / 2);
  });
}

export function makeLabel(text, opts = {}) {
  const tex = textTexture(text, opts);
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false, ...(opts.matOpts || {}) });
  const s = new THREE.Sprite(mat);
  const h = opts.height || 1;
  s.scale.set(h * (opts.w || 512) / (opts.h || 128), h, 1);
  return s;
}

// ---------- misc ----------
const _v = new THREE.Vector3();
export function yawOf(obj) {
  obj.getWorldDirection(_v);
  return Math.atan2(_v.x, _v.z);
}
export function fmtTime(s) {
  const m = Math.floor(s / 60), r = s - m * 60;
  return `${m}:${r < 10 ? '0' : ''}${r.toFixed(2)}`;
}
