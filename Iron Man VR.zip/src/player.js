import * as THREE from 'three';
import { groundAt, resolveSphere } from './world/colliders.js';
import { heightAt } from './world/terrain.js';
import { buildGauntlet, buildSuitModel, suitById } from './suits.js';
import { clamp, rand, damp } from './util.js';

const G = 9.81;
const _v = new THREE.Vector3(), _w = new THREE.Vector3(), _q = new THREE.Quaternion(), _head = new THREE.Vector3();
const UP = new THREE.Vector3(0, 1, 0);

export class Player {
  constructor(game) {
    this.g = game;
    const { scene, camera } = game;
    this.rig = new THREE.Group();
    this.rig.name = 'rig';
    this.rig.add(camera);
    scene.add(this.rig);
    this.camera = camera;
    this.vel = new THREE.Vector3();
    this.bodyPos = new THREE.Vector3();
    this.headPos = new THREE.Vector3();
    this.headDir = new THREE.Vector3(0, 0, -1);
    this.radius = 0.45;
    this.suit = null; this.suited = false;
    this.mode = 'tony'; // tony | suit | car | suitup
    this.flying = false; this.grounded = true;
    this.hp = 100; this.energy = 100; this.missiles = 0;
    this.alive = true;
    this.lastHit = 0; this.lastUse = 0; this.time = 0;
    this.cool = { left: 0, right: 0, missile: 0, minigun: 0, flamer: 0 };
    this.missileRegen = 0;
    this.ice = 0; this.icedOut = false;
    this.speed = 0; this.altitude = 0; this.maxAlt = 0;
    this.boosting = false; this.beamOn = false; this.beamPoint = null;
    this.thrustLevels = { left: 0, right: 0 };
    this.padTimer = 0;
    this.pitch = 0; // desktop
    this.deskFlight = false;
    this.hands = { left: null, right: null }; // gauntlet objects
    this.handParent = { left: null, right: null };
    this.locks = [];
    this.damageFlash = 0;
    this.shake = 0;

    // unibeam visual
    const beamGeo = new THREE.CylinderGeometry(0.5, 0.09, 1, 16, 1, true).rotateX(Math.PI / 2).translate(0, 0, 0.5);
    this.beamMesh = new THREE.Mesh(beamGeo, new THREE.MeshBasicMaterial({ color: new THREE.Color(0x6fcfff), transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
    const beamCore = new THREE.Mesh(beamGeo, new THREE.MeshBasicMaterial({ color: 0xe8f8ff, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
    beamCore.scale.set(0.35, 0.35, 1);
    this.beamMesh.add(beamCore);
    this.beamMesh.visible = false; this.beamMesh.frustumCulled = false;
    scene.add(this.beamMesh);

    // boot thrusters (visible when you look down while flying)
    this.boots = new THREE.Group();
    const bootGeo = new THREE.ConeGeometry(0.07, 0.9, 12, 1, true).rotateX(Math.PI).translate(0, -0.45, 0);
    const bootMat = new THREE.MeshBasicMaterial({ color: 0xbfe6ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
    for (const s of [-1, 1]) { const b = new THREE.Mesh(bootGeo, bootMat); b.position.set(s * 0.12, 0, 0); this.boots.add(b); }
    this.boots.userData.mat = bootMat;
    scene.add(this.boots);
  }

  // ------------------------------------------------------------ gauntlets
  attachHands() {
    const inp = this.g.input;
    for (const side of ['left', 'right']) {
      if (this.hands[side]) this.hands[side].removeFromParent();
      const gl = buildGauntlet(this.suited ? this.suit : null, side);
      const xrHand = inp.hands[side];
      const parent = inp.xr && xrHand.grip ? xrHand.grip : inp.deskHands[side];
      parent.add(gl);
      this.hands[side] = gl; this.handParent[side] = parent;
    }
  }
  setSuit(id) {
    this.suit = suitById(id);
    const S = this.suit.stats;
    this.hp = S.armor; this.energy = S.energy; this.missiles = S.missiles;
    this.ice = 0; this.icedOut = false;
  }

  // ------------------------------------------------------------ suit-up animation
  suitUp(id, onDone) {
    this.setSuit(id);
    this.mode = 'suitup';
    this.vel.set(0, 0, 0);
    const model = buildSuitModel(this.suit, { merged: false, shadows: false });
    const parts = model.userData.parts;
    // place model so the helmet sits on the player's head
    this.camera.getWorldPosition(_head);
    const yaw = this.yaw();
    const sc = this.suit.scale || 1;
    model.position.set(_head.x, this.rig.position.y + (_head.y - this.rig.position.y - 1.68 * sc) + 0.0, _head.z);
    model.rotation.y = yaw + Math.PI;
    this.g.scene.add(model);
    const order = ['bootL', 'bootR', 'shinL', 'shinR', 'thighL', 'thighR', 'pelvis', 'abs', 'chest', 'neck', 'shoulderL', 'shoulderR', 'upperarmL', 'upperarmR', 'forearmL', 'forearmR', 'handL', 'handR', 'helmet'];
    const anims = order.map((name, i) => {
      const p = parts[name];
      const off = new THREE.Vector3(rand(-3, 3), rand(-1, 3), rand(-3, 3));
      if (name === 'helmet') off.set(0, 0.6, 1.2);
      p.position.copy(off);
      p.rotation.set(rand(-2, 2), rand(-2, 2), rand(-2, 2));
      return { p, off, start: i * 0.14, dur: 0.45 };
    });
    this.g.audio.suitUp();
    this.g.hud.flashBoot = 0;
    this.g.audio.say(`${this.suit.name} online. Welcome back, sir.`);
    let t = 0;
    this.suitAnim = (dt) => {
      t += dt;
      for (const a of anims) {
        const k = clamp((t - a.start) / a.dur, 0, 1);
        const e = 1 - Math.pow(1 - k, 3);
        a.p.position.copy(a.off).multiplyScalar(1 - e);
        a.p.rotation.set(a.p.rotation.x * (1 - e), a.p.rotation.y * (1 - e), a.p.rotation.z * (1 - e));
        if (k > 0 && k < 1 && !a.clank && k > 0.9) { a.clank = true; }
      }
      // keep the model on the player's head while they move
      this.camera.getWorldPosition(_head);
      model.position.x = _head.x; model.position.z = _head.z;
      if (t > anims[anims.length - 1].start + 0.5) {
        this.g.scene.remove(model);
        this.suitAnim = null;
        this.suited = true;
        this.mode = 'suit';
        this.attachHands();
        this.g.hud.boot();
        onDone && onDone();
      }
    };
  }
  suitDown() {
    this.suited = false; this.mode = 'tony'; this.flying = false;
    this.attachHands();
  }

  yaw() { this.camera.getWorldDirection(_v); return Math.atan2(_v.x, _v.z) + Math.PI; }

  teleport(x, y, z, yaw = null) {
    // move the rig so the HEAD ends up at x,z (room-scale offset aware)
    this.rig.updateMatrixWorld(true);
    this.camera.getWorldPosition(_head);
    const ox = _head.x - this.rig.position.x, oz = _head.z - this.rig.position.z;
    this.rig.position.set(x - ox, y, z - oz);
    if (yaw !== null) this.setYaw(yaw);
    this.rig.updateMatrixWorld(true);
    this.camera.getWorldPosition(this.headPos);
    this.vel.set(0, 0, 0);
  }
  setYaw(yaw) {
    // rotate the rig around the head so the view faces `yaw`
    const cur = this.yaw();
    this.rotateRig(yaw - cur);
  }
  rotateRig(delta) {
    this.rig.updateMatrixWorld(true);
    this.camera.getWorldPosition(_head);
    const p = this.rig.position;
    const dx = p.x - _head.x, dz = p.z - _head.z;
    const c = Math.cos(delta), s = Math.sin(delta);
    p.x = _head.x + dx * c + dz * s; p.z = _head.z - dx * s + dz * c;
    this.rig.rotation.y += delta;
  }

  damage(amt, from) {
    if (!this.alive || this.mode === 'suitup' || this.g.settings.godMode) return;
    const S = this.suit && this.suited ? this.suit.stats : null;
    this.hp -= amt * (S ? 1 : 3);
    this.lastHit = this.time;
    this.damageFlash = Math.min(1, this.damageFlash + amt / 25);
    for (const h of Object.values(this.g.input.hands)) h.pulse(0.8, 60);
    if (this.hp <= 0) this.die();
    else if (S && this.hp < S.armor * 0.25 && !this._lowWarned) { this._lowWarned = true; this.g.audio.say('Sir, armor integrity is critical.', { priority: true }); this.g.audio.alarm(); }
  }
  die() {
    this.alive = false; this.hp = 0;
    this.g.audio.explosion(0, true);
    this.g.fx.explosion(this.bodyPos.clone(), 1.5, this.bodyPos);
    this.g.onPlayerDeath && this.g.onPlayerDeath();
  }
  respawn(at) {
    this.alive = true;
    const S = this.suit.stats;
    this.hp = S.armor; this.energy = S.energy; this.missiles = S.missiles; this.ice = 0; this.icedOut = false; this._lowWarned = false;
    this.teleport(at.x, at.y, at.z, at.yaw ?? null);
    this.flying = false;
  }

  // ------------------------------------------------------------ per frame
  update(dt) {
    const g = this.g, inp = g.input, set = g.settings;
    this.time += dt;
    const xr = inp.xr;
    const L = inp.hands.left, R = inp.hands.right;

    // desktop look
    if (!xr) {
      if (inp.mouse.locked) {
        this.rig.rotation.y -= inp.mouse.dx * 0.0022 * set.mouseSens;
        this.pitch = clamp(this.pitch - inp.mouse.dy * 0.0022 * set.mouseSens, -1.5, 1.5);
      }
      if (inp.key('ArrowLeft')) this.rig.rotation.y += dt * 2;
      if (inp.key('ArrowRight')) this.rig.rotation.y -= dt * 2;
      this.camera.rotation.set(this.pitch, 0, 0);
      this.camera.position.set(0, this.suited ? 1.8 * Math.min(this.suit.scale || 1, 1.3) : 1.7, 0);
    } else {
      // snap / smooth turn on the right stick
      const sx = R.stick.x;
      if (set.smoothTurn) { if (Math.abs(sx) > 0.2) this.rotateRig(-sx * dt * 2.2); }
      else {
        if (Math.abs(sx) > 0.7 && !this._snapped) { this.rotateRig(-Math.sign(sx) * Math.PI / 6); this._snapped = true; }
        if (Math.abs(sx) < 0.3) this._snapped = false;
      }
    }

    this.camera.getWorldPosition(this.headPos);
    this.camera.getWorldDirection(this.headDir);
    if (this.suitAnim) { this.suitAnim(dt); this._updateBody(); return; }
    if (this.mode === 'car') { this._updateBody(); return; }
    if (!this.alive) { this.vel.multiplyScalar(0.9); this._updateBody(); return; }

    const suited = this.suited;
    const S = suited ? this.suit.stats : null;
    const menuOpen = g.ui.isOpen();

    // ---------- thrust
    const acc = new THREE.Vector3(0, -G, 0);
    let thrustSum = 0;
    this.boosting = false;
    const canThrust = suited && !this.icedOut && !(S.primary === 'flamer' && this.energy <= 0);
    if (xr) {
      const boostBtn = (L.btn.stick || R.btn.stick) && this.energy > 0;
      for (const side of ['left', 'right']) {
        const h = inp.hands[side];
        let tv = canThrust && h.connected && !menuOpen ? h.trigger : 0;
        if (tv < 0.05) tv = 0;
        this.thrustLevels[side] = tv;
        if (!tv || !this.hands[side]) continue;
        const nozzle = this.nozzleDir(side, _v);
        const power = S.thrust * tv * (boostBtn ? 2.3 : 1) * this.altitudeFactor();
        acc.addScaledVector(nozzle, -power);
        thrustSum += tv;
        if (boostBtn) this.boosting = true;
      }
      // left stick fine strafing while flying / walking when grounded
    } else if (suited && canThrust) {
      // desktop: WASD flight relative to the view
      const wish = new THREE.Vector3();
      const fwd = _v.copy(this.headDir); const right = _w.crossVectors(fwd, UP).normalize();
      if (inp.key('KeyW')) wish.add(fwd);
      if (inp.key('KeyS')) wish.sub(fwd);
      if (inp.key('KeyD')) wish.add(right);
      if (inp.key('KeyA')) wish.sub(right);
      if (inp.key('Space')) wish.y += 1;
      if (inp.key('KeyC') || inp.key('ControlLeft')) wish.y -= 1;
      if (inp.keyPressed('Space') && this.grounded) { this.deskFlight = true; this.vel.y = 6; }
      if (this.deskFlight && !menuOpen) {
        const boost = inp.key('ShiftLeft') && this.energy > 0;
        if (wish.lengthSq() > 0) wish.normalize();
        const power = S.thrust * 2 * (boost ? 2.3 : 1) * this.altitudeFactor();
        acc.addScaledVector(wish, power);
        acc.y += G; // auto-hover
        // stabilizer: bleed velocity that isn't in the wish direction
        const keep = wish.lengthSq() > 0 ? 0.6 : 2.2;
        acc.addScaledVector(this.vel, -keep * (wish.lengthSq() > 0 ? 0.25 : 1));
        thrustSum = wish.lengthSq() > 0 ? (boost ? 2 : 1.4) : 0.6;
        this.boosting = boost && wish.lengthSq() > 0;
        this.thrustLevels.left = this.thrustLevels.right = thrustSum / 2;
        // animate desktop hands: palms back when moving forward, down when hovering
        const fw = wish.dot(this.headDir);
        for (const side of ['left', 'right']) {
          const dh = inp.deskHands[side];
          const tz = side === 'left' ? -Math.PI / 2 : Math.PI / 2;
          dh.rotation.z = damp(dh.rotation.z, tz, 8, dt);
          dh.rotation.x = damp(dh.rotation.x, fw > 0.3 ? -0.45 : 0.1, 6, dt);
          dh.position.y = damp(dh.position.y, fw > 0.3 ? -0.46 : -0.34, 6, dt);
        }
      } else {
        this.thrustLevels.left = this.thrustLevels.right = 0;
        for (const side of ['left', 'right']) {
          const dh = inp.deskHands[side];
          dh.rotation.z = damp(dh.rotation.z, 0, 8, dt); dh.rotation.x = damp(dh.rotation.x, 0.35, 8, dt); dh.position.y = damp(dh.position.y, -0.34, 8, dt);
        }
      }
    }
    if (thrustSum > 0 && !this.grounded) {
      // flight assist: partially cancel gravity + damp sink rate so hovering is easy
      if (xr && set.flightAssist) { acc.y += G * 0.55; acc.y -= this.vel.y * 0.5; }
    }
    // drag (quadratic) — sets top speed
    const sp = this.vel.length();
    acc.addScaledVector(this.vel, -(0.04 + 0.0034 * sp));

    // energy use
    if (this.boosting) { this.energy -= 14 * dt; this.lastUse = this.time; }
    if (S && S.primary === 'flamer' && thrustSum > 0) { this.energy -= 7 * thrustSum * dt; this.lastUse = this.time; }

    // ---------- walking (grounded and not thrusting)
    const walkSpeed = suited ? 5.5 : 3.2;
    let walk = new THREE.Vector2();
    if (xr) walk.set(L.stick.x, -L.stick.y);
    else if (!(suited && this.deskFlight)) {
      walk.set((inp.key('KeyD') ? 1 : 0) - (inp.key('KeyA') ? 1 : 0), (inp.key('KeyW') ? 1 : 0) - (inp.key('KeyS') ? 1 : 0));
      if (inp.key('ShiftLeft')) walk.multiplyScalar(1.8);
    }
    if (menuOpen) walk.set(0, 0);
    if (this.grounded && thrustSum === 0) {
      const yaw = this.yaw();
      const f = _v.set(Math.sin(yaw), 0, Math.cos(yaw)).multiplyScalar(-1); // forward
      const r = _w.set(-f.z, 0, f.x);
      const tx = (r.x * walk.x + f.x * walk.y) * walkSpeed, tz = (r.z * walk.x + f.z * walk.y) * walkSpeed;
      this.vel.x = damp(this.vel.x, tx, 10, dt); this.vel.z = damp(this.vel.z, tz, 10, dt);
      acc.x = 0; acc.z = 0;
    } else if (xr && !this.grounded && suited && walk.lengthSq() > 0) {
      // airborne: left stick gives gentle strafing thrust
      const yaw = this.yaw();
      const f = _v.set(-Math.sin(yaw), 0, -Math.cos(yaw)); const r = _w.set(-f.z, 0, f.x);
      acc.addScaledVector(f, walk.y * 6).addScaledVector(r, walk.x * 6);
    }

    // ---------- integrate
    this.vel.addScaledVector(acc, dt);
    this.rig.position.addScaledVector(this.vel, dt);
    this.camera.getWorldPosition(this.headPos);

    // ---------- collisions
    const feetY = this.rig.position.y;
    const gnd = groundAt(this.headPos.x, this.headPos.z, feetY + 0.2);
    if (feetY <= gnd + 0.02) {
      const impact = -this.vel.y;
      if (!this.grounded && impact > 16) this.landing(impact);
      this.rig.position.y = gnd;
      if (this.vel.y < 0) this.vel.y = 0;
      this.grounded = true;
      if (!xr && thrustSum <= 0.6 && !inp.key('Space')) this.deskFlight = false;
    } else {
      // stick to ground when walking down slopes/stairs
      if (this.grounded && thrustSum === 0 && feetY - gnd < 0.45 && this.vel.y <= 0.5) { this.rig.position.y = gnd; this.vel.y = 0; }
      else this.grounded = false;
    }
    const center = _v.set(this.headPos.x, this.rig.position.y + 1.0, this.headPos.z);
    const before = center.clone();
    const n = resolveSphere(center, suited ? 0.5 * Math.min(this.suit.scale || 1, 1.3) : 0.3);
    if (n) {
      const dv = this.vel.dot(n);
      if (dv < 0) {
        if (-dv > 45 && suited) { this.damage((-dv - 45) * 0.8, center); g.fx.sparks(center.clone().addScaledVector(n, -0.5), 30); g.audio.hit(); }
        this.vel.addScaledVector(n, -dv * 1.2);
      }
      this.rig.position.x += center.x - before.x; this.rig.position.y += center.y - before.y; this.rig.position.z += center.z - before.z;
    }
    // world ceiling
    if (this.rig.position.y > 9000) { this.rig.position.y = 9000; this.vel.y = Math.min(0, this.vel.y); }

    this.flying = !this.grounded;
    this.speed = this.vel.length();
    this.camera.getWorldPosition(this.headPos);
    this.altitude = this.rig.position.y;
    this.maxAlt = Math.max(this.maxAlt, this.altitude);

    if (suited) this._weapons(dt, S, xr, menuOpen);
    else { this.beamOn = false; this.beamMesh.visible = false; }
    this._vitals(dt, S);
    this._pads(dt);
    this._updateBody();
    this._visuals(dt, xr);
  }

  altitudeFactor() { return clamp(1 - (this.rig.position.y - 6000) / 4000, 0.3, 1); }

  nozzleDir(side, out) {
    const gl = this.hands[side];
    if (this.g.settings.thrustMode === 'point') {
      gl.getWorldQuaternion(_q);
      return out.set(0, 0, -1).applyQuaternion(_q);
    }
    gl.getWorldQuaternion(_q);
    return out.copy(gl.userData.palmDir).applyQuaternion(_q);
  }
  handPos(side, out) {
    return this.hands[side].getWorldPosition(out);
  }
  aimDir(side, out) {
    if (!this.g.input.xr) return out.copy(this.headDir);
    this.hands[side].getWorldQuaternion(_q);
    return out.set(0, 0, -1).applyQuaternion(_q);
  }

  landing(impact) {
    const g = this.g;
    if (this.suited) {
      const dmg = impact > 48 ? (impact - 48) * 1.5 : 0;
      if (dmg > 0) this.damage(dmg, this.bodyPos);
      g.fx.shock(this.rig.position.clone().add(_v.set(0, 0.2, 0)), 6 + impact * 0.1);
      for (let i = 0; i < 25; i++) g.fx.smoke.spawn(this.rig.position, _v.randomDirection().setY(0.3).multiplyScalar(rand(4, 9)), rand(0.8, 1.6), 0.6, 2.8, [0.55, 0.5, 0.45, 0.5], [0.5, 0.48, 0.45, 0], 2, -0.5);
      g.audio.explosion(30, false);
      for (const h of Object.values(g.input.hands)) h.pulse(1, 120);
      if (impact > 24) g.onSuperheroLanding && g.onSuperheroLanding();
    } else if (impact > 12) this.damage((impact - 12) * 4, this.bodyPos);
  }

  _weapons(dt, S, xr, menuOpen) {
    const g = this.g, inp = g.input, C = g.combat;
    for (const k in this.cool) this.cool[k] -= dt;
    if (menuOpen) { this.beamOn = false; this.beamMesh.visible = false; return; }
    const mult = g.settings.easyAim ? 1 : 0.6;
    // ---- primary (repulsor / flamer)
    const fireSide = (side) => {
      if (S.primary === 'flamer') {
        if (this.energy <= 0) return;
        const p = this.handPos(side, _v.clone()), d = this.aimDir(side, _w.clone());
        for (let i = 0; i < 3; i++) g.fx.fire(p, d);
        C.flamer(p, d, 60, dt);
        this.energy -= 12 * dt; this.lastUse = this.time;
        if (this.cool.flamer <= 0) { this.cool.flamer = 0.15; g.audio.flamer(); }
        return;
      }
      if (this.cool[side] > 0 || this.energy < 2) return;
      this.cool[side] = S.fireRate;
      const p = this.handPos(side, new THREE.Vector3());
      const d = this.aimDir(side, new THREE.Vector3());
      p.addScaledVector(d, 0.15);
      C.fire('repulsor', p, d, S.repulsor, { assist: 9 * mult + 2 });
      g.fx.muzzle(p);
      g.fx.flash(p, 0.5, 0xcfeeff, 0.08);
      g.audio.repulsor();
      this.energy -= 2.5; this.lastUse = this.time;
      inp.hands[side].pulse(0.6, 40);
      // recoil kick on the gauntlet
      if (this.hands[side]) this.hands[side].position.z = 0.05;
    };
    if (xr) {
      for (const side of ['left', 'right']) if (inp.hands[side].btn.squeeze) fireSide(side);
    } else if (inp.mouse.left && inp.mouse.locked) {
      this._alt = this._alt || 'left';
      if (this.cool[this._alt] <= 0 || S.primary === 'flamer') { fireSide(this._alt); this._alt = this._alt === 'left' ? 'right' : 'left'; }
    }
    // ---- missiles
    const missileBtn = xr ? inp.hands.right.pressed('a') : inp.keyPressed('KeyE');
    this.missileRegen += dt;
    if (this.missileRegen > 3.5 && this.missiles < S.missiles) { this.missiles++; this.missileRegen = 0; }
    this.locks = S.missiles > 0 ? C.findTargets(this.headPos, this.headDir, 22, 900, Math.min(this.missiles, 6)) : [];
    if (missileBtn) {
      if (this.missiles <= 0 || this.cool.missile > 0) g.audio.ui('deny');
      else {
        this.cool.missile = 0.6;
        const n = Math.min(this.missiles, Math.max(2, this.locks.length || 2), 6);
        for (let i = 0; i < n; i++) {
          const tgt = this.locks.length ? this.locks[i % this.locks.length] : null;
          const side = i % 2 ? 1 : -1;
          const yaw = this.yaw();
          const o = this.headPos.clone().add(_v.set(Math.cos(yaw) * 0.35 * side, -0.25, -Math.sin(yaw) * 0.35 * side));
          setTimeout(() => { C.fireMissile(o, this.headDir.clone(), tgt, 55); g.audio.missile(); }, i * 90);
        }
        this.missiles -= n;
      }
    }
    // ---- special (unibeam / minigun)
    const specialHeld = xr ? inp.hands.right.btn.b : (inp.mouse.right && inp.mouse.locked) || inp.key('KeyQ');
    this.beamOn = false;
    if (S.special === 'unibeam' && specialHeld && this.energy > 1) {
      this.beamOn = true;
      const o = this.headPos.clone().add(_v.set(0, -0.45 * (this.suit.scale || 1), 0)).addScaledVector(this.headDir, 0.9);
      const res = C.beam(o, this.headDir, 140 * (S.beamMult || 1), dt);
      this.beamPoint = res.point;
      this.beamMesh.visible = true;
      this.beamMesh.position.copy(o);
      this.beamMesh.lookAt(res.point);
      const w = 1 + Math.sin(this.time * 60) * 0.12;
      this.beamMesh.scale.set(w, w, res.dist);
      if (Math.random() < 0.6) g.fx.sparks(res.point, 3, [0.7, 0.9, 1], 10);
      if (res.world && Math.random() < 0.2) g.fx.repulsorImpact(res.point);
      this.energy -= 30 * dt; this.lastUse = this.time;
      for (const h of Object.values(inp.hands)) h.pulse(0.3, 20);
    } else this.beamMesh.visible = false;
    if (S.special === 'minigun' && specialHeld && this.cool.minigun <= 0 && this.energy > 0.5) {
      this.cool.minigun = 0.055;
      const yaw = this.yaw();
      const o = this.headPos.clone().add(_v.set(-Math.cos(yaw) * 0.3, -0.05, Math.sin(yaw) * 0.3));
      C.fire('bullet', o, this.headDir, 7, { assist: 5, spread: 0.012 });
      g.fx.muzzle(o.addScaledVector(this.headDir, 0.4), [1, 0.85, 0.4]);
      g.audio.minigun();
      this.energy -= 0.5; this.lastUse = this.time;
    }
  }

  _vitals(dt, S) {
    if (!S) { this.hp = Math.min(100, this.hp + dt * 5); return; }
    if (this.time - this.lastUse > 0.6) this.energy = Math.min(S.energy, this.energy + S.energyRegen * dt);
    this.energy = Math.max(0, this.energy);
    if (this.time - this.lastHit > 4.5 && this.hp < S.armor) this.hp = Math.min(S.armor, this.hp + 6 * (S.regen || 1) * dt);
    if (this.hp > S.armor * 0.4) this._lowWarned = false;
    // Mark II icing problem
    if (S.icing) {
      if (this.altitude > 3500) {
        this.ice = Math.min(1, this.ice + dt * 0.22);
        if (this.ice > 0.35 && !this._iceWarn) { this._iceWarn = true; this.g.audio.say('Sir, there is a potentially fatal buildup of ice occurring.', { priority: true }); this.g.audio.icing(); }
        if (this.ice >= 1 && !this.icedOut) { this.icedOut = true; this.g.audio.alarm(); this.g.audio.say('Thrusters frozen! Drop altitude to thaw them.', { priority: true }); }
      } else {
        this.ice = Math.max(0, this.ice - dt * (this.altitude < 2800 ? 0.35 : 0.1));
        if (this.ice < 0.2) { this._iceWarn = false; if (this.icedOut) { this.icedOut = false; this.g.audio.say('Ice cleared. Thrusters back online.'); } }
      }
    } else this.ice = 0;
    this.damageFlash = Math.max(0, this.damageFlash - dt * 1.5);
  }

  _pads(dt) {
    const pads = this.g.mansion.pads;
    let on = null;
    for (const p of pads) {
      p.cooldown -= dt;
      if (Math.hypot(this.headPos.x - p.pos.x, this.headPos.z - p.pos.z) < 0.9 && Math.abs(this.rig.position.y - p.pos.y) < 0.6 && p.cooldown <= 0) on = p;
    }
    if (on) {
      this.padTimer += dt;
      if (this.padTimer > 0.9) {
        this.padTimer = 0;
        this.g.fade(() => {
          this.teleport(on.to.x, on.to.y, on.to.z);
          for (const p of pads) p.cooldown = 2;
        });
        this.g.audio.ui('success');
      }
    } else this.padTimer = 0;
  }

  _updateBody() {
    this.camera.getWorldPosition(this.headPos);
    this.bodyPos.copy(this.headPos); this.bodyPos.y -= 0.55;
  }

  _visuals(dt, xr) {
    const g = this.g;
    for (const side of ['left', 'right']) {
      const gl = this.hands[side];
      if (!gl) continue;
      gl.position.z = damp(gl.position.z, 0, 18, dt);
      const tv = this.thrustLevels[side];
      const ud = gl.userData;
      const flick = 0.85 + Math.random() * 0.3;
      ud.flame.material.opacity = tv > 0 ? Math.min(0.9, tv * 0.9) * flick : 0;
      ud.flameCore.material.opacity = tv > 0 ? Math.min(1, tv) * flick : 0;
      const len = tv * (this.boosting ? 2.6 : 1.4) * flick;
      ud.flame.scale.set(1 + tv * 0.4, Math.max(0.01, len), 1 + tv * 0.4);
      if (ud.palm.material.color && this.suited) {
        const base = new THREE.Color(this.suit.colors.reactor).multiplyScalar(1.5 + tv * 2.5);
        ud.palm.material.color.copy(base);
      }
      if (tv > 0.05 && this.suited) {
        const p = gl.getWorldPosition(_v);
        const d = this.nozzleDir(side, _w);
        if (g.settings.thrustMode !== 'point') g.fx.thrustTrail(p.addScaledVector(d, 0.05), d, tv, this.boosting);
        else g.fx.thrustTrail(p, d, tv, this.boosting);
      }
    }
    // boots
    const tot = (this.thrustLevels.left + this.thrustLevels.right) / 2;
    this.boots.visible = this.suited && this.flying;
    if (this.boots.visible) {
      const yaw = this.yaw();
      const sc = this.suit.scale || 1;
      this.boots.position.set(this.headPos.x, this.headPos.y - 1.75 * sc, this.headPos.z);
      this.boots.rotation.y = yaw;
      const op = 0.25 + tot * 0.6;
      this.boots.userData.mat.opacity = op * (0.85 + Math.random() * 0.3);
      this.boots.children.forEach((b) => b.scale.set(1, 0.6 + tot * 1.6 * (this.boosting ? 1.8 : 1), 1));
      if (Math.random() < tot) g.fx.thrustTrail(this.boots.position, _v.set(0, -1, 0), 0.6, this.boosting);
    }
  }
}
