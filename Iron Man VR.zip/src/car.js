import * as THREE from 'three';
import { buildSupercar } from './world/cars.js';
import { groundAt, resolveSphere } from './world/colliders.js';
import { clamp, damp } from './util.js';

const _v = new THREE.Vector3(), _w = new THREE.Vector3();

// Tony's drivable supercar (arcade physics).
export class Car {
  constructor(game, spot) {
    this.g = game;
    this.mesh = buildSupercar(0xb7babd);
    this.mesh.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    game.scene.add(this.mesh);
    this.home = spot;
    this.pos = new THREE.Vector3(spot.x, spot.y, spot.z);
    this.yaw = spot.yaw; // 0 = facing +X
    this.speed = 0; this.steer = 0; this.vy = 0;
    this.active = false;
    this.hit = new THREE.Mesh(new THREE.BoxGeometry(4.6, 1.6, 2.2), new THREE.MeshBasicMaterial({ visible: false }));
    this.hit.position.y = 0.8;
    this.mesh.add(this.hit);
    this.interactable = { object: this.hit, type: 'car', label: "Tony's Supercar — get in" };
    game.mansion.interactables.push(this.interactable);
    this._apply();
  }
  reset() { this.pos.set(this.home.x, this.home.y, this.home.z); this.yaw = this.home.yaw; this.speed = 0; this._apply(); }

  enter() {
    const p = this.g.player;
    this.active = true;
    p.mode = 'car';
    p.vel.set(0, 0, 0);
    this.prevYaw = this.yaw;
    // face the driving direction
    p.setYaw(this.yaw - Math.PI / 2);
    this.g.audio.say('Engine started. Drive safe, sir.');
    this.g.hud.toast(this.g.input.xr ? 'Right trigger: gas · Left trigger: brake · Left stick: steer · X: exit' : 'W/S: gas/brake · A/D: steer · F: exit');
  }
  exit() {
    const p = this.g.player;
    this.active = false;
    p.mode = p.suited ? 'suit' : 'tony';
    // step out to the driver's side
    const fwd = _w.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const left = new THREE.Vector3(-fwd.z, 0, fwd.x).multiplyScalar(-1);
    const out = this.pos.clone().addScaledVector(left, 2.2);
    p.teleport(out.x, groundAt(out.x, out.z, this.pos.y + 1), out.z);
    this.speed = 0;
  }

  update(dt) {
    const inp = this.g.input;
    if (this.active) {
      let gas = 0, brake = 0, steer = 0;
      if (inp.xr) {
        gas = inp.hands.right.trigger; brake = inp.hands.left.trigger;
        steer = -inp.hands.left.stick.x;
        if (inp.hands.left.pressed('a')) { this.exit(); return; }
      } else {
        gas = inp.key('KeyW') ? 1 : 0; brake = inp.key('KeyS') ? 1 : 0;
        steer = (inp.key('KeyA') ? 1 : 0) - (inp.key('KeyD') ? 1 : 0);
        if (inp.keyPressed('KeyF')) { this.exit(); return; }
      }
      if (this.g.ui.isOpen()) { gas = 0; brake = 0; }
      const accel = 16, maxF = 72, maxR = 12;
      if (gas > 0) this.speed += accel * gas * dt * (1 - Math.max(0, this.speed) / maxF);
      if (brake > 0) this.speed -= (this.speed > 0.5 ? 30 : 8) * brake * dt;
      this.speed = clamp(this.speed, -maxR, maxF);
      this.steer = damp(this.steer, steer * (0.55 - Math.min(0.35, Math.abs(this.speed) / 140)), 6, dt);
    } else {
      this.steer = damp(this.steer, 0, 3, dt);
    }
    // rolling resistance
    this.speed *= Math.exp(-(this.active ? 0.08 : 1.5) * dt);
    if (Math.abs(this.speed) < 0.05) this.speed = 0;
    // bicycle model
    this.yaw += (this.speed / 2.8) * Math.tan(this.steer) * dt;
    const fwd = _v.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    this.pos.addScaledVector(fwd, this.speed * dt);
    // ground
    const gy = groundAt(this.pos.x, this.pos.z, this.pos.y + 1.0);
    if (this.pos.y > gy + 0.05) { this.vy -= 9.81 * dt; this.pos.y += this.vy * dt; if (this.pos.y < gy) { this.pos.y = gy; this.vy = 0; } }
    else { this.pos.y = gy; this.vy = 0; }
    // walls
    const c = _w.copy(this.pos); c.y += 1.5; // sphere floats above the floor so it only hits walls
    const before = c.clone();
    const n = resolveSphere(c, 1.2);
    if (n) {
      this.pos.x += c.x - before.x; this.pos.z += c.z - before.z;
      if (Math.abs(this.speed) > 8) { this.g.fx.sparks(c, 15); this.g.audio.hit(); }
      this.speed *= 0.5;
    }
    this._apply();
    if (this.active) {
      // carry the player
      const p = this.g.player;
      const seat = this.mesh.userData.seat.clone().applyMatrix4(this.mesh.matrixWorld);
      const headLocalY = p.camera.position.y;
      p.rotateRig(this.yaw - this.prevYaw);
      this.prevYaw = this.yaw;
      // seated eye height ~0.85 m above the seat cushion
      p.teleport(seat.x, seat.y + 0.85 - headLocalY, seat.z);
      p.vel.set(fwd.x * this.speed, 0, fwd.z * this.speed);
      p.speed = Math.abs(this.speed);
    }
    for (const w of this.mesh.userData.wheels) w.rotation.z -= (this.speed / 0.36) * dt;
    this.mesh.userData.wheels[0].rotation.y = this.steer; this.mesh.userData.wheels[1].rotation.y = this.steer;
  }
  _apply() {
    this.mesh.position.copy(this.pos);
    // pitch from ground slope
    const f = _v.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const yF = groundAt(this.pos.x + f.x * 1.5, this.pos.z + f.z * 1.5, this.pos.y + 1);
    const yB = groundAt(this.pos.x - f.x * 1.5, this.pos.z - f.z * 1.5, this.pos.y + 1);
    const pitch = Math.atan2(yF - yB, 3);
    this.mesh.rotation.set(0, this.yaw, clamp(pitch, -0.4, 0.4), 'YXZ');
    this.mesh.updateMatrixWorld();
  }
  get rpm() { return Math.min(1, Math.abs(this.speed) / 72); }
}
