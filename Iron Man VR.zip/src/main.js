import * as THREE from 'three';
import { buildSky } from './world/sky.js';
import { buildTerrain, buildOcean, buildVegetation } from './world/terrain.js';
import { buildCity } from './world/city.js';
import { buildMansion } from './world/mansion.js';
import { groundAt } from './world/colliders.js';
import { TOWER, CITY, EXPO, HQ, GULMIRA, coastX } from './world/layout.js';
import { Audio } from './audio.js';
import { Input } from './input.js';
import { FX } from './fx.js';
import { Combat } from './combat.js';
import { Enemies } from './enemies.js';
import { Player } from './player.js';
import { HUD } from './hud.js';
import { UI } from './ui.js';
import { Missions } from './missions.js';
import { Car } from './car.js';
import { Save, SLOTS } from './save.js';
import { SUITS, suitById } from './suits.js';

const params = new URLSearchParams(location.search);
const status = (t) => { const el = document.getElementById('loading'); if (el) el.textContent = t; };
const frame = () => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 0)));

async function boot() {
  // ---------------------------------------------------------------- renderer
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  renderer.setSize(innerWidth, innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.xr.enabled = true;
  renderer.xr.setReferenceSpaceType('local-floor');
  renderer.xr.setFoveation(0.4);
  document.body.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.05, 40000);
  addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });

  const game = { renderer, scene, camera };
  window.game = game; window.THREE = THREE; // handy for debugging from the console
  game.save = new Save();
  game.settings = Save.loadSettings();
  game.saveSettings = () => Save.saveSettings(game.settings);
  game.audio = new Audio();
  game.audio.voiceOn = game.settings.voice;

  // ---------------------------------------------------------------- world
  status('Generating sky…'); await frame();
  game.sky = buildSky(scene, renderer);
  status('Sculpting the Malibu coastline…'); await frame();
  game.terrain = buildTerrain(scene);
  game.ocean = buildOcean(scene);
  status('Planting palm trees…'); await frame();
  buildVegetation(scene);
  status('Building the city…'); await frame();
  game.city = buildCity(scene);
  status("Building Tony's mansion…"); await frame();
  game.mansion = buildMansion(scene);

  // ---------------------------------------------------------------- systems
  status('Booting J.A.R.V.I.S.…'); await frame();
  game.fx = new FX(scene, game.audio);
  game.combat = new Combat(scene, game.fx, game.audio);
  game.player = new Player(game); // creates the rig (camera parent)
  game.input = new Input(renderer, camera, game.player.rig, renderer.domElement);
  game.enemies = new Enemies(scene, game.combat, game.fx, game.audio, game.player);
  game.enemies.groundAt = groundAt;
  game.combat.player = game.player;
  game.hud = new HUD(game);
  game.ui = new UI(game);
  game.missions = new Missions(game);
  game.car = new Car(game, game.mansion.carSpot);
  game.audio.onSubtitle = (t) => game.hud.say(t);

  game.isUnlocked = (id) => {
    const s = suitById(id);
    return game.settings.unlockAll || s.unlock === 'start' || game.save.data.unlocks.includes(s.unlock);
  };
  game.unlockedCount = () => SUITS.filter((s) => game.isUnlocked(s.id)).length;
  game.refreshPods = () => game.mansion.refreshPods(game.isUnlocked, game.player.suited ? game.player.suit.id : null);
  game.applyTime = () => { game.sky.setTime(game.settings.time); game.city.setNight(game.sky.night); };
  game.applyTime();

  game.deploySuit = (id) => {
    if (!game.isUnlocked(id)) { game.audio.ui('deny'); return; }
    if (game.player.mode === 'car') game.car.exit();
    if (game.player.mode === 'suitup') return;
    game.save.data.suit = id; game.save.write();
    game.mansion.setHologramSuit(suitById(id));
    game.player.suitUp(id, () => {
      game.refreshPods();
      if (!game._flightTipShown) {
        game._flightTipShown = true;
        game.hud.toast(game.input.xr ? 'Point palms DOWN + squeeze TRIGGERS to fly' : 'SPACE to take off · WASD to fly · SHIFT boost', '#7fd8ff', 7);
      }
    });
    game.refreshPods();
  };

  // fade to black for teleports
  const fadeMesh = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 12), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0, side: THREE.BackSide, depthTest: false, depthWrite: false, fog: false }));
  fadeMesh.renderOrder = 2000; fadeMesh.frustumCulled = false;
  camera.add(fadeMesh);
  let fadeState = null;
  game.fade = (cb) => { fadeState = { t: 0, cb, done: false }; };

  game.fastTravel = (where) => {
    game.fade(() => {
      const P = game.player;
      if (P.mode === 'car') game.car.exit();
      if (where === 'workshop') { const s = game.mansion.spawn; P.teleport(s.x, s.y, s.z, s.yaw); }
      else if (where === 'roof') { const r = game.mansion.roof; P.teleport(r.x + 4, r.y, r.z, Math.PI / 2); }
      else if (where === 'tower') P.teleport(TOWER.x - 34, CITY.y + 232.6, TOWER.z, Math.PI / 2);
      game.player.vel.set(0, 0, 0);
    });
  };

  game.onPlayerDeath = () => {
    game.audio.say('Suit critical. Rebooting all systems.', { priority: true });
    setTimeout(() => {
      game.fade(() => {
        const cp = game.missions.checkpointFor();
        if (cp) { game.player.respawn({ x: cp.x, y: cp.y, z: cp.z }); game.missions.restartStep(); game.hud.toast('Checkpoint — try again!', '#ffd34a'); }
        else {
          if (game.missions.active) game.missions.fail('You were taken down.');
          const r = game.mansion.roof;
          game.player.respawn({ x: r.x + 4, y: r.y, z: r.z, yaw: Math.PI / 2 });
        }
      });
    }, 2500);
  };
  let landingQuip = 0;
  game.onSuperheroLanding = () => {
    if (performance.now() - landingQuip > 60000 && Math.random() < 0.5) {
      landingQuip = performance.now();
      game.audio.say(['Very dramatic landing, sir.', 'The superhero landing. Terrible for the knees.', 'Nicely stuck.'][Math.floor(Math.random() * 3)]);
    }
  };
  game.combat.onKill = (e) => { game.save.data.kills++; if (game.save.data.kills % 5 === 0) game.save.write(); };
  game.enemies.onBossIced = (e) => { game.audio.say("He's icing up! Now's your chance, sir!", { priority: true }); game.hud.toast('IRON MONGER ICED — ATTACK!', '#7fd8ff', 4); };
  game.enemies.onEnemyMissile = () => { if (Math.random() < 0.3) game.audio.say('Missile lock! Evasive maneuvers!'); game.audio.alarm(); };

  // interaction helpers
  game.wantsPointer = () => !game.player.suited && game.player.mode === 'tony';
  game.input.onHandConnected = () => game.player.attachHands();
  renderer.xr.addEventListener('sessionstart', () => {
    game.player.attachHands();
    game.fx.setScale(900);
    game.player.camera.position.set(0, 0, 0);
    game.player.pitch = 0;
  });
  renderer.xr.addEventListener('sessionend', () => { game.player.attachHands(); game.fx.setScale(renderer.domElement.height / 2); });
  game.fx.setScale(renderer.domElement.height / 2);

  // ---------------------------------------------------------------- start state
  const sp = game.mansion.spawn;
  game.player.teleport(sp.x, sp.y, sp.z, sp.yaw);
  game.player.setSuit(game.save.data.suit || 'mk3');
  game.player.attachHands();
  game.mansion.setHologramSuit(suitById(game.save.data.suit || 'mk3'));
  game.refreshPods();
  // ---------------------------------------------------------------- save slots
  game.paused = true; // until the player picks a slot on the main menu
  game.save.capture = () => {
    const P = game.player;
    if (!P.alive) return null; // keep the last good state
    P.rig.updateMatrixWorld(true);
    const ref = P.mode === 'car' ? game.car.pos : P.camera.getWorldPosition(new THREE.Vector3());
    return {
      pos: [ref.x, P.mode === 'car' ? game.car.pos.y : P.rig.position.y, ref.z], yaw: P.yaw(),
      suited: P.suited || P.mode === 'suitup', suit: P.suit ? P.suit.id : game.save.data.suit,
    };
  };
  game.placeName = (x, z) => {
    if (Math.hypot(x, z) < 160) return 'Malibu Mansion';
    if (Math.hypot(x - EXPO.x, z - EXPO.z) < EXPO.r + 100) return 'Stark Expo';
    if (Math.max(Math.abs(x - CITY.x), Math.abs(z - CITY.z)) < CITY.half + 100) return 'Downtown';
    if (Math.hypot(x - HQ.x, z - HQ.z) < HQ.r + 200) return 'Stark Industries';
    if (Math.hypot(x - GULMIRA.x, z - GULMIRA.z) < GULMIRA.r + 1500) return 'Gulmira';
    if (x < coastX(z)) return 'Pacific Ocean';
    if (z < -2500) return 'Northern Mountains';
    return 'Malibu Hills';
  };
  game.slotSummary = (n) => {
    const d = game.save.read(n);
    if (!d) return null;
    const mins = Math.floor((d.playtime || 0) / 60);
    const st = d.state;
    return {
      suit: suitById((st && st.suit) || d.suit).name,
      story: d.done.filter((id) => /^m\d$/.test(id)).length,
      caches: d.caches.length,
      armor: SUITS.filter((s) => game.settings.unlockAll || s.unlock === 'start' || d.unlocks.includes(s.unlock)).length,
      time: mins < 60 ? `${mins} min` : `${Math.floor(mins / 60)} h ${mins % 60} min`,
      where: st && st.pos ? game.placeName(st.pos[0], st.pos[2]) : 'Workshop',
      saved: d.savedAt ? new Date(d.savedAt).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '',
    };
  };
  game.loadSlot = (n) => {
    const P = game.player;
    game.save.use(n);
    game.missions.abort(true);
    game.enemies.clear(); game.combat.clearHostile();
    if (P.mode === 'car') game.car.exit();
    game.car.reset();
    P.suitAnim = null; P.alive = true; P.vel.set(0, 0, 0);
    const d = game.save.data, st = d.state;
    P.setSuit((st && st.suit) || d.suit || 'mk3');
    P.suited = !!(st && st.suited); P.mode = P.suited ? 'suit' : 'tony';
    P.attachHands();
    if (st && st.pos) {
      const [x, y, z] = st.pos;
      P.teleport(x, y, z, st.yaw);
      const flying = y > groundAt(x, z, y + 1) + 1.5;
      P.grounded = !flying; P.deskFlight = flying && P.suited;
    } else { const s = game.mansion.spawn; P.teleport(s.x, s.y, s.z, s.yaw); P.grounded = true; P.deskFlight = false; }
    game.missions.manualWaypoint = null;
    game.missions.refreshCaches();
    game.mansion.setHologramSuit(suitById(P.suit.id));
    game.refreshPods();
    autosaveT = 0;
  };
  game.saveToSlot = (n) => {
    const ok = game.save.saveTo(n);
    game.hud.toast(ok ? `Saved to Slot ${n}` : 'Could not save: browser storage is blocked', ok ? '#8fffa8' : '#ff7a6a');
    game.audio.ui(ok ? 'success' : 'deny');
  };
  game.toMainMenu = () => {
    if (game.player.alive && game.player.mode !== 'suitup') game.save.write();
    if (game.ui.isOpen()) game.ui.close();
    game.paused = true;
    if (document.pointerLockElement) document.exitPointerLock();
    const session = renderer.xr.getSession();
    if (session) session.end().catch(() => {});
    showMainMenu();
  };
  let autosaveT = 0;

  // debug / quick-start: ?suit=mk3&at=x,y,z&yaw=deg
  if (params.get('suit')) { game.player.setSuit(params.get('suit')); game.player.suited = true; game.player.mode = 'suit'; game.player.attachHands(); game.refreshPods(); }
  if (params.get('at')) { const [x, y, z] = params.get('at').split(',').map(Number); game.player.teleport(x, y, z, params.get('yaw') ? (Number(params.get('yaw')) * Math.PI) / 180 : null); if (y > groundAt(x, z, y) + 2) { game.player.grounded = false; game.player.deskFlight = true; } }
  if (params.get('pitch')) game.player.pitch = (Number(params.get('pitch')) * Math.PI) / 180;
  if (params.has('nohud')) { game.hud.mesh.visible = false; game.hud.frame.visible = false; game.hud.update = () => {}; }
  if (params.get('time')) { game.settings.time = params.get('time'); game.applyTime(); }

  // ---------------------------------------------------------------- interaction
  const raycaster = new THREE.Raycaster();
  raycaster.far = 9;
  const interactTargets = () => game.mansion.interactables.map((i) => i.object);
  function pointedInteractable() {
    const inp = game.input;
    const rays = [];
    if (inp.xr) {
      for (const side of ['right', 'left']) {
        const h = inp.hands[side];
        if (!h.ray) continue;
        const o = h.ray.getWorldPosition(new THREE.Vector3());
        const d = new THREE.Vector3(0, 0, -1).applyQuaternion(h.ray.getWorldQuaternion(new THREE.Quaternion()));
        rays.push({ o, d, side });
      }
    } else {
      rays.push({ o: game.player.headPos.clone(), d: game.player.headDir.clone(), side: 'right' });
    }
    for (const r of rays) {
      raycaster.set(r.o, r.d);
      const hit = raycaster.intersectObjects(interactTargets(), false)[0];
      if (hit) return { item: game.mansion.interactables.find((i) => i.object === hit.object), side: r.side };
    }
    return null;
  }
  function interact(item) {
    if (item.type === 'pod') {
      if (!game.isUnlocked(item.suit.id)) { game.audio.ui('deny'); game.audio.say(`The ${item.suit.name} is locked. ${({ m1: 'Complete the flight test.', m2: 'Liberate Gulmira first.', m3: 'Stop the drone swarm downtown.', m4: 'Win the Expo showdown.', m5: 'Defeat the Iron Monger.', side_drones: 'Complete two drone hunts.', side_caches10: 'Find ten Stark Tech caches.', side_caches20: 'Find all twenty caches.', side_races: 'Finish all three races.', side_rescue: 'Complete the rescue mission.' })[item.suit.unlock] || ''}`); return; }
      if (game.player.suited && game.player.suit.id === item.suit.id) { game.audio.say('You are already wearing it, sir.'); return; }
      game.deploySuit(item.suit.id);
    } else if (item.type === 'holotable') game.ui.show('missions');
    else if (item.type === 'car') game.car.enter();
  }

  // ---------------------------------------------------------------- loop
  let last = performance.now(), t = 0;
  function loop() {
    const now = performance.now();
    const dt = Math.min((now - last) / 1000, 1 / 30);
    last = now;
    t += dt;
    const inp = game.input, P = game.player;
    inp.update();
    if (game.paused) { game.sky.update(P.headPos); renderer.render(scene, camera); inp.endFrame(); return; }
    game.save.data.playtime = (game.save.data.playtime || 0) + dt;
    autosaveT += dt;
    if (autosaveT > 60 && P.alive && P.mode !== 'suitup') {
      autosaveT = 0;
      if (game.save.write()) game.hud.toast('Autosaved', '#9fc3dc', 1.5);
    }

    // menu toggle
    const menuBtn = inp.xr ? inp.hands.left.pressed('b') : inp.keyPressed('Tab') || inp.keyPressed('KeyM');
    if (menuBtn && P.mode !== 'suitup') game.ui.toggle();

    P.update(dt);
    game.car.update(dt);

    // interaction (pods, holotable, car)
    let prompt = '';
    if (!game.ui.isOpen() && P.mode !== 'car' && P.mode !== 'suitup' && P.alive) {
      const pi = pointedInteractable();
      if (pi) {
        const it = pi.item;
        const key = inp.xr ? (P.suited ? 'X' : 'Trigger') : 'F / Click';
        prompt = it.type === 'pod' ? `${key}: ${game.isUnlocked(it.suit.id) ? 'Suit up — ' + it.suit.name : it.suit.name + ' (locked)'}` : `${key}: ${it.label}`;
        const go = inp.xr ? (P.suited ? inp.hands.left.pressed('a') : inp.hands[pi.side].pressed('trigger')) : inp.keyPressed('KeyF') || (!P.suited && inp.mousePressed('left') && inp.mouse.locked);
        if (go) interact(it);
      }
    }
    if (P.mode === 'car') prompt = inp.xr ? 'X: get out' : 'F: get out';
    game.hud.prompt = prompt;

    game.ui.update(dt);
    game.enemies.update(dt);
    game.combat.update(dt);
    game.missions.update(dt);
    game.fx.update(dt);
    game.mansion.update(dt, t, P.headPos);
    game.city.update(dt);
    game.ocean.update(dt, t, P.headPos);
    game.sky.update(P.headPos);
    game.hud.update(dt);
    if (game.sky.sky.material.uniforms.time) game.sky.sky.material.uniforms.time.value = t;
    game.audio.update({
      thrustL: P.thrustLevels.left, thrustR: P.thrustLevels.right, boost: P.boosting,
      speed: P.speed, beam: P.beamOn, suited: P.suited, carRpm: P.mode === 'car' ? game.car.rpm : -1,
    });
    // lock-on marker tint
    for (const e of game.enemies.list) if (e.marker && !e.friendly) e.marker.material.color.set(P.locks.includes(e) ? 0xffd34a : 0xffffff);

    if (fadeState) {
      fadeState.t += dt;
      const k = fadeState.t / 0.25;
      if (k >= 1 && !fadeState.done) { fadeState.done = true; fadeState.cb && fadeState.cb(); }
      fadeMesh.material.opacity = k < 1 ? k : Math.max(0, 2 - k);
      if (k >= 2) { fadeState = null; fadeMesh.material.opacity = 0; }
    }

    renderer.render(scene, camera);
    inp.endFrame();
  }
  renderer.setAnimationLoop(loop);

  // ---------------------------------------------------------------- start screen
  status('Ready.');
  document.getElementById('start').classList.add('ready');
  const greet = (isNew) => {
    game.audio.init();
    setTimeout(() => {
      game.audio.say(isNew ? 'Welcome home, sir. All armor is charged and waiting in the Hall of Armor.' : 'Welcome back, sir. Picking up where we left off.');
      if (isNew) game.hud.toast(game.input.xr ? 'Point at an armor and pull the trigger to suit up · Y: menu' : 'Look at an armor and press F to suit up · TAB: menu', '#7fd8ff', 8);
    }, 600);
  };
  // main menu: slot picker
  let selected = game.save.slot, deleteArmed = 0;
  const slotsEl = document.getElementById('slots');
  function renderSlots() {
    slotsEl.innerHTML = '';
    for (const n of SLOTS) {
      const sm = game.slotSummary(n);
      const card = document.createElement('div');
      card.className = 'slot' + (n === selected ? ' sel' : '') + (sm ? '' : ' empty');
      card.tabIndex = 0;
      card.setAttribute('role', 'button');
      card.innerHTML = `<div class="slot-head"><span>SLOT ${n}</span>${sm ? `<span class="slot-time">${sm.time}</span>` : ''}</div>` + (sm
        ? `<div class="slot-suit">${sm.suit}</div><div class="slot-where">${sm.where}</div>
           <div class="slot-stats"><span>Story ${sm.story}/5</span><span>Caches ${sm.caches}/20</span><span>Armor ${sm.armor}/16</span></div>
           <div class="slot-foot"><span>${sm.saved}</span><button class="slot-del" data-n="${n}">${deleteArmed === n ? 'Confirm delete' : 'Delete'}</button></div>`
        : `<div class="slot-suit">New game</div><div class="slot-where">Start in the workshop</div>`);
      const pick = () => { selected = n; deleteArmed = 0; renderSlots(); };
      card.onclick = pick;
      card.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } };
      slotsEl.appendChild(card);
    }
    slotsEl.querySelectorAll('.slot-del').forEach((b) => b.onclick = (e) => {
      e.stopPropagation();
      const n = Number(b.dataset.n);
      if (deleteArmed === n) { game.save.remove(n); deleteArmed = 0; } else deleteArmed = n;
      renderSlots();
    });
    const sm = game.slotSummary(selected);
    document.getElementById('btn-desktop').textContent = sm ? 'CONTINUE ON DESKTOP' : 'NEW GAME ON DESKTOP';
    const vb = document.getElementById('btn-vr');
    if (!vb.disabled) vb.textContent = sm ? 'CONTINUE IN VR' : 'NEW GAME IN VR';
  }
  function showMainMenu() { selected = game.save.slot; deleteArmed = 0; document.getElementById('start').style.display = ''; renderSlots(); }
  const beginPlay = () => {
    const isNew = !game.save.read(selected);
    game.loadSlot(selected);
    if (isNew) game.save.write(); // claim the slot
    document.getElementById('start').style.display = 'none';
    game.paused = false;
    greet(isNew);
  };
  document.getElementById('btn-desktop').onclick = () => {
    renderer.domElement.requestPointerLock?.();
    beginPlay();
  };
  const vrBtn = document.getElementById('btn-vr');
  const xrOK = navigator.xr && (await navigator.xr.isSessionSupported('immersive-vr').catch(() => false));
  if (!xrOK) { vrBtn.disabled = true; vrBtn.textContent = 'VR NOT DETECTED'; document.getElementById('vr-help').style.display = 'block'; }
  vrBtn.onclick = async () => {
    // Try the best setup first, then simpler ones — some runtimes reject floor-level tracking.
    const attempts = [
      { opts: { optionalFeatures: ['local-floor', 'bounded-floor'] }, space: 'local-floor' },
      { opts: { optionalFeatures: ['local-floor'] }, space: 'local-floor' },
      { opts: {}, space: 'local' },
    ];
    let lastErr = null;
    for (const a of attempts) {
      try {
        const session = await navigator.xr.requestSession('immersive-vr', a.opts);
        renderer.xr.setReferenceSpaceType(a.space);
        await renderer.xr.setSession(session);
        if (a.space === 'local') {
          // 'local' puts the origin at your head — shift it so you stand at normal height
          const base = renderer.xr.getReferenceSpace();
          renderer.xr.setReferenceSpace(base.getOffsetReferenceSpace(new XRRigidTransform({ x: 0, y: -1.65, z: 0 })));
        }
        beginPlay();
        session.addEventListener('end', () => { if (!game.paused) game.toMainMenu(); });
        return;
      } catch (e) { lastErr = e; }
    }
    status('VR could not start (' + (lastErr ? lastErr.message : 'unknown error') + '). Check that SteamVR is running with the headset awake and set as the OpenXR runtime. Inside claude.ai VR may be blocked — use PLAY.bat on your PC.');
    const help = document.getElementById('vr-help'); if (help) help.style.display = 'block';
  };
  renderSlots();
  if (params.has('auto')) { document.getElementById('start').style.display = 'none'; game.paused = false; }
}

boot().catch((e) => { console.error(e); status('Error: ' + e.message); });
