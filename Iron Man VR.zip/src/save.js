// Three save slots in localStorage. Each slot holds story progress plus where you were and what you wore.
const SLOT_KEY = (n) => `ironman-vr-slot-${n}`;
const META_KEY = 'ironman-vr-meta-v1';
const OLD_KEY = 'ironman-vr-save-v1', SKEY = 'ironman-vr-settings-v1';
export const SLOTS = [1, 2, 3];

export const fresh = () => ({ suit: 'mk3', unlocks: [], done: [], races: {}, caches: [], kills: 0, playtime: 0, savedAt: 0, state: null });
export const DEFAULT_SETTINGS = {
  thrustMode: 'palm', flightAssist: true, smoothTurn: false, vignette: true, easyAim: true,
  time: 'golden', voice: true, unlockAll: false, godMode: false, mouseSens: 1,
};

const get = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const set = (k, v) => { try { localStorage.setItem(k, v); return true; } catch { return false; } };

export class Save {
  constructor() {
    // move a pre-slots save into slot 1
    const old = get(OLD_KEY);
    if (old && !get(SLOT_KEY(1))) { set(SLOT_KEY(1), old); try { localStorage.removeItem(OLD_KEY); } catch {} }
    let meta = {};
    try { meta = JSON.parse(get(META_KEY) || '{}'); } catch {}
    this.slot = SLOTS.includes(meta.last) ? meta.last : 1;
    this.data = this.read(this.slot) || fresh();
    this.capture = null; // set by the game: returns the player's current state
  }
  read(n) {
    const raw = get(SLOT_KEY(n));
    if (!raw) return null;
    try { return { ...fresh(), ...JSON.parse(raw) }; } catch { return null; }
  }
  // write the active slot (progress + current player state)
  write() {
    if (this.capture) { const st = this.capture(); if (st) this.data.state = st; }
    this.data.savedAt = Date.now();
    const ok = set(SLOT_KEY(this.slot), JSON.stringify(this.data));
    set(META_KEY, JSON.stringify({ last: this.slot }));
    return ok;
  }
  use(n) { this.slot = n; this.data = this.read(n) || fresh(); set(META_KEY, JSON.stringify({ last: n })); }
  saveTo(n) { this.slot = n; return this.write(); }
  remove(n) {
    try { localStorage.removeItem(SLOT_KEY(n)); } catch {}
    if (n === this.slot) this.data = fresh();
  }
  reset() { this.data = fresh(); this.write(); }
  static loadSettings() {
    try { return { ...DEFAULT_SETTINGS, ...JSON.parse(get(SKEY) || '{}') }; } catch { return { ...DEFAULT_SETTINGS }; }
  }
  static saveSettings(s) { set(SKEY, JSON.stringify(s)); }
}
