import * as THREE from 'three';
import { clamp, fmtTime } from './util.js';

const W = 1280, H = 800;
const CY = '#9fe8ff', CY2 = 'rgba(159,232,255,', OR = '#ffb347', RD = '#ff4a3d';

export class HUD {
  constructor(game) {
    this.g = game;
    this.canvas = document.createElement('canvas');
    this.canvas.width = W; this.canvas.height = H;
    this.ctx = this.canvas.getContext('2d');
    this.tex = new THREE.CanvasTexture(this.canvas);
    this.tex.colorSpace = THREE.SRGBColorSpace;
    this.tex.minFilter = THREE.LinearFilter;
    const dist = 1.15;
    const geo = new THREE.PlaneGeometry(1.5, 1.5 * H / W, 24, 1);
    // gently curve the HUD around the eye
    const p = geo.attributes.position;
    for (let i = 0; i < p.count; i++) { const x = p.getX(i); p.setZ(i, -(x * x) * 0.32); }
    this.mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: this.tex, transparent: true, depthTest: false, depthWrite: false, toneMapped: false, fog: false }));
    this.mesh.position.set(0, -0.02, -dist);
    this.mesh.renderOrder = 1000;
    this.mesh.frustumCulled = false;
    game.camera.add(this.mesh);

    // helmet interior frame (dark edges + faint gold tint)
    const fc = document.createElement('canvas'); fc.width = fc.height = 512;
    const fg = fc.getContext('2d');
    const gr = fg.createRadialGradient(256, 256, 120, 256, 256, 256);
    gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.72, 'rgba(10,6,2,0.0)'); gr.addColorStop(0.9, 'rgba(10,6,2,0.65)'); gr.addColorStop(1, 'rgba(0,0,0,0.95)');
    fg.fillStyle = gr; fg.fillRect(0, 0, 512, 512);
    const ft = new THREE.CanvasTexture(fc);
    this.frame = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 1.3), new THREE.MeshBasicMaterial({ map: ft, transparent: true, depthTest: false, depthWrite: false, fog: false }));
    this.frame.position.set(0, 0, -0.45);
    this.frame.renderOrder = 999;
    this.frame.frustumCulled = false;
    game.camera.add(this.frame);

    // comfort vignette (separate so it can fade with speed)
    const vc = document.createElement('canvas'); vc.width = vc.height = 256;
    const vg = vc.getContext('2d');
    const vgr = vg.createRadialGradient(128, 128, 40, 128, 128, 128);
    vgr.addColorStop(0, 'rgba(0,0,0,0)'); vgr.addColorStop(0.55, 'rgba(0,0,0,0)'); vgr.addColorStop(1, 'rgba(0,0,0,1)');
    vg.fillStyle = vgr; vg.fillRect(0, 0, 256, 256);
    this.vignette = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.2), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(vc), transparent: true, opacity: 0, depthTest: false, depthWrite: false, fog: false }));
    this.vignette.position.set(0, 0, -0.3);
    this.vignette.renderOrder = 998;
    this.vignette.frustumCulled = false;
    game.camera.add(this.vignette);

    this.subtitle = ''; this.subT = 0;
    this.toasts = [];
    this.prompt = '';
    this.timer = 0;
    this.bootT = 99;
    this.dirty = true;
    this.big = null; this.bigT = 0;
  }
  boot() { this.bootT = 0; }
  say(text) { this.subtitle = text; this.subT = Math.max(4, text.length * 0.07); this.dirty = true; }
  toast(text, color = CY, dur = 3) { this.toasts.push({ text, color, t: dur }); if (this.toasts.length > 3) this.toasts.shift(); this.dirty = true; }
  banner(title, sub = '', color = '#ffd34a', dur = 4) { this.big = { title, sub, color }; this.bigT = dur; this.dirty = true; }

  update(dt) {
    const P = this.g.player;
    const sc = this.g.input.xr ? 1.0 : 1.72;
    this.mesh.scale.set(sc, sc, 1);
    this.subT -= dt; this.bigT -= dt; this.bootT += dt;
    for (const t of this.toasts) t.t -= dt;
    this.toasts = this.toasts.filter((t) => t.t > 0);
    this.frame.visible = P.suited && this.g.player.mode !== 'car';
    // comfort vignette
    const s = this.g.settings;
    const target = s.vignette && this.g.input.xr ? clamp((P.speed - 25) / 80, 0, 0.75) : 0;
    this.vignette.material.opacity += (target - this.vignette.material.opacity) * Math.min(1, dt * 4);
    this.timer -= dt;
    if (this.timer > 0 && !this.dirty) return;
    this.timer = 1 / 20; this.dirty = false;
    this.draw();
    this.tex.needsUpdate = true;
  }

  draw() {
    const g = this.ctx, P = this.g.player, game = this.g;
    g.clearRect(0, 0, W, H);
    const suited = P.suited && P.mode !== 'car';
    const S = suited ? P.suit.stats : null;
    g.textBaseline = 'middle';
    g.lineCap = 'round';

    // damage + ice overlays
    if (P.damageFlash > 0.02) {
      const gr = g.createRadialGradient(W / 2, H / 2, 200, W / 2, H / 2, 700);
      gr.addColorStop(0, 'rgba(255,0,0,0)'); gr.addColorStop(1, `rgba(255,30,20,${P.damageFlash * 0.55})`);
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
    }
    if (P.ice > 0.05) {
      const gr = g.createRadialGradient(W / 2, H / 2, 150, W / 2, H / 2, 750);
      gr.addColorStop(0, 'rgba(220,240,255,0)'); gr.addColorStop(1, `rgba(220,240,255,${P.ice * 0.8})`);
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
    }
    if (!P.alive) {
      g.fillStyle = 'rgba(80,0,0,0.5)'; g.fillRect(0, 0, W, H);
      this.text('SUIT CRITICAL — REBOOTING', W / 2, H / 2, 46, RD, 'center', true);
    }

    if (suited) {
      const boot = clamp(this.bootT / 2.2, 0, 1);
      g.globalAlpha = boot < 1 ? (Math.random() < 0.15 ? 0.3 : boot) : 1;
      this.compass();
      this.bars(S);
      this.rightInfo(S);
      this.radar();
      // reticle
      g.strokeStyle = CY2 + '0.8)'; g.lineWidth = 2;
      g.beginPath(); g.arc(W / 2, H / 2 + 20, 14, 0, Math.PI * 2); g.stroke();
      g.beginPath(); g.moveTo(W / 2 - 26, H / 2 + 20); g.lineTo(W / 2 - 18, H / 2 + 20); g.moveTo(W / 2 + 18, H / 2 + 20); g.lineTo(W / 2 + 26, H / 2 + 20); g.stroke();
      if (P.locks.length && S.missiles) this.text(`LOCK ×${P.locks.length}`, W / 2, H / 2 + 52, 18, OR, 'center');
      // warnings
      const warns = [];
      if (P.ice > 0.2) warns.push([`ICING ${Math.round(P.ice * 100)}%`, P.icedOut ? RD : OR]);
      if (P.energy < S.energy * 0.15) warns.push(['ENERGY LOW', OR]);
      if (P.hp < S.armor * 0.25) warns.push(['ARMOR CRITICAL', RD]);
      if (P.altitude > 6000) warns.push(['THIN AIR — THRUST REDUCED', OR]);
      warns.forEach(([t, c], i) => { if (Math.floor(performance.now() / 300) % 2 === 0 || i > 0) this.text(t, W / 2, 230 + i * 30, 24, c, 'center', true); });
      if (boot < 1) {
        g.globalAlpha = 1;
        const lines = ['J.A.R.V.I.S. ONLINE', 'ARC REACTOR ........ OK', 'REPULSORS .......... OK', 'FLIGHT STABILIZERS . OK', `ARMOR: ${P.suit.name.toUpperCase()}`];
        lines.slice(0, Math.ceil(boot * lines.length)).forEach((l, i) => this.text(l, W / 2 - 170, 300 + i * 30, 22, CY, 'left'));
      }
      g.globalAlpha = 1;
    }
    this.objective();
    this.bossBar();
    // prompt
    if (this.prompt) {
      g.fillStyle = 'rgba(0,10,20,0.6)';
      const w = Math.min(900, 30 + this.prompt.length * 13);
      g.fillRect(W / 2 - w / 2, H - 250, w, 44);
      this.text(this.prompt, W / 2, H - 228, 24, '#ffffff', 'center');
    }
    // toasts
    this.toasts.forEach((t, i) => this.text(t.text, W / 2, 330 + i * 40 + (suited ? 60 : 0), 30, t.color, 'center', true));
    // big banner
    if (this.bigT > 0 && this.big) {
      const a = clamp(this.bigT, 0, 1);
      g.globalAlpha = a;
      g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(0, 480, W, 120);
      this.text(this.big.title, W / 2, 525, 52, this.big.color, 'center', true);
      if (this.big.sub) this.text(this.big.sub, W / 2, 575, 24, '#ffffff', 'center');
      g.globalAlpha = 1;
    }
    // subtitles
    if (this.subT > 0 && this.subtitle) {
      g.globalAlpha = clamp(this.subT, 0, 1);
      g.font = '24px Arial';
      const lines = wrap(g, this.subtitle, 820);
      const h = lines.length * 30 + 16;
      g.fillStyle = 'rgba(0,8,16,0.65)'; g.fillRect(W / 2 - 440, H - 200, 880, h);
      lines.forEach((l, i) => this.text((i === 0 ? 'J.A.R.V.I.S.: ' : '') + l, W / 2, H - 200 + 22 + i * 30, 24, i === 0 ? CY : '#e8f6ff', 'center'));
      g.globalAlpha = 1;
    }
  }

  text(t, x, y, size, color, align = 'left', bold = false) {
    const g = this.ctx;
    g.font = `${bold ? 'bold ' : ''}${size}px Arial`;
    g.textAlign = align;
    g.shadowColor = 'rgba(0,0,0,0.9)'; g.shadowBlur = 6;
    g.fillStyle = color; g.fillText(t, x, y);
    g.shadowBlur = 0;
  }

  compass() {
    const g = this.ctx, P = this.g.player;
    const yawDeg = ((-P.yaw() * 180 / Math.PI) % 360 + 360) % 360; // 0 = -Z ("north")
    const cx = W / 2, y = 120, span = 120, px = 3.2;
    g.strokeStyle = CY2 + '0.5)'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(cx - span * px / 2, y + 16); g.lineTo(cx + span * px / 2, y + 16); g.stroke();
    for (let d = -span / 2; d <= span / 2; d++) {
      const hd = Math.round(yawDeg + d);
      if (hd % 5) continue;
      const x = cx + (hd - yawDeg) * px;
      const h = ((hd % 360) + 360) % 360;
      const major = h % 45 === 0;
      g.beginPath(); g.moveTo(x, y + 16); g.lineTo(x, y + (major ? 0 : 8)); g.stroke();
      if (major) this.text(['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][h / 45], x, y - 12, 18, CY, 'center', true);
    }
    this.text(String(Math.round(yawDeg)).padStart(3, '0'), cx, y + 36, 18, '#ffffff', 'center', true);
    // waypoint
    const wp = this.g.missions.waypoint();
    if (wp) {
      const dx = wp.x - P.headPos.x, dz = wp.z - P.headPos.z;
      const brg = ((Math.atan2(dx, -dz) * 180 / Math.PI) % 360 + 360) % 360;
      let rel = brg - yawDeg; rel = ((rel + 540) % 360) - 180;
      const x = cx + clamp(rel, -span / 2, span / 2) * px;
      g.fillStyle = '#ffd34a';
      g.beginPath(); g.moveTo(x, y + 20); g.lineTo(x - 9, y + 34); g.lineTo(x + 9, y + 34); g.closePath(); g.fill();
      const dist = Math.hypot(dx, dz, (wp.y ?? P.headPos.y) - P.headPos.y);
      this.text(dist > 1000 ? (dist / 1000).toFixed(1) + ' km' : Math.round(dist) + ' m', x, y + 50, 16, '#ffd34a', 'center', true);
    }
  }

  bars(S) {
    const g = this.ctx, P = this.g.player;
    const arc = (cx, cy, r, a0, a1, frac, color, label, val) => {
      g.lineWidth = 12; g.strokeStyle = 'rgba(159,232,255,0.15)';
      g.beginPath(); g.arc(cx, cy, r, a0, a1); g.stroke();
      g.strokeStyle = color;
      g.beginPath(); g.arc(cx, cy, r, a1 - (a1 - a0) * clamp(frac, 0, 1), a1); g.stroke();
      return { label, val };
    };
    const hpF = P.hp / S.armor, enF = P.energy / S.energy;
    arc(W / 2, H / 2 + 20, 330, Math.PI * 0.8, Math.PI * 1.08, hpF, hpF < 0.25 ? RD : hpF < 0.5 ? OR : CY);
    arc(W / 2, H / 2 + 20, 305, Math.PI * 0.8, Math.PI * 1.08, enF, enF < 0.15 ? OR : '#ffe08a');
    this.text('ARMOR', 200, 470, 18, CY, 'left', true);
    this.text(Math.ceil(P.hp) + '', 200, 495, 26, '#ffffff', 'left', true);
    this.text('POWER', 270, 470, 18, '#ffe08a', 'left', true);
    this.text(Math.ceil(enF * 100) + '%', 270, 495, 26, '#ffffff', 'left', true);
  }

  rightInfo(S) {
    const P = this.g.player;
    const x = W - 300;
    this.text('SPD', x, 300, 18, CY, 'left', true);
    this.text(Math.round(P.speed * 3.6) + ' km/h', x + 50, 300, 26, '#ffffff', 'left', true);
    this.text('ALT', x, 335, 18, CY, 'left', true);
    this.text(Math.round(P.altitude) + ' m', x + 50, 335, 26, '#ffffff', 'left', true);
    if (S.missiles) { this.text('MSL', x, 370, 18, CY, 'left', true); this.text(`${P.missiles}/${S.missiles}`, x + 50, 370, 26, '#ffffff', 'left', true); }
    this.text(P.suit.name.toUpperCase(), x, 410, 20, '#ffd34a', 'left', true);
    if (P.boosting) this.text('AFTERBURNER', x, 440, 20, OR, 'left', true);
  }

  radar() {
    const g = this.ctx, P = this.g.player;
    const cx = W - 230, cy = H - 230, r = 92, range = 900;
    g.fillStyle = 'rgba(0,20,30,0.35)'; g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.fill();
    g.strokeStyle = CY2 + '0.5)'; g.lineWidth = 1.5;
    g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.stroke();
    g.beginPath(); g.arc(cx, cy, r / 2, 0, Math.PI * 2); g.stroke();
    const yaw = P.yaw();
    const c = Math.cos(yaw), s = Math.sin(yaw);
    const plot = (wx, wz, color, size, clampEdge = false) => {
      const dx = wx - P.headPos.x, dz = wz - P.headPos.z;
      // rotate into view space (forward = up on the radar)
      let rx = dx * c - dz * s, ry = dx * s + dz * c;
      let px = rx / range * r, py = ry / range * r;
      const d = Math.hypot(px, py);
      if (d > r) { if (!clampEdge) return; px *= r / d; py *= r / d; }
      g.fillStyle = color; g.beginPath(); g.arc(cx + px, cy + py, size, 0, Math.PI * 2); g.fill();
    };
    for (const e of this.g.enemies.list) if (e.alive) plot(e.pos.x, e.pos.z, e.friendly ? '#5ad1ff' : e.boss ? OR : RD, e.boss ? 6 : 3.5);
    const wp = this.g.missions.waypoint();
    if (wp) plot(wp.x, wp.z, '#ffd34a', 6, true);
    g.fillStyle = '#ffffff';
    g.beginPath(); g.moveTo(cx, cy - 7); g.lineTo(cx - 5, cy + 5); g.lineTo(cx + 5, cy + 5); g.closePath(); g.fill();
  }

  objective() {
    const M = this.g.missions;
    const o = M.hudInfo();
    if (!o) return;
    const g = this.ctx;
    const x = 180, y = 210;
    g.fillStyle = 'rgba(0,10,20,0.5)'; g.fillRect(x - 12, y - 26, 420, 34 + o.lines.length * 28);
    g.fillStyle = '#ffd34a'; g.fillRect(x - 12, y - 26, 4, 34 + o.lines.length * 28);
    this.text(o.title, x, y - 8, 20, '#ffd34a', 'left', true);
    o.lines.forEach((l, i) => this.text(l, x, y + 22 + i * 28, 20, '#ffffff', 'left'));
    if (o.timer != null) this.text(fmtTime(Math.max(0, o.timer)), x + 395, y - 8, 22, o.timer < 10 ? RD : '#ffffff', 'right', true);
  }

  bossBar() {
    const b = this.g.enemies.list.find((e) => e.boss && e.alive);
    if (!b) return;
    const g = this.ctx;
    const w = 520, x = W / 2 - w / 2, y = 175;
    this.text(b.name, W / 2, y - 14, 20, OR, 'center', true);
    g.fillStyle = 'rgba(0,0,0,0.5)'; g.fillRect(x, y, w, 12);
    g.fillStyle = OR; g.fillRect(x, y, w * clamp(b.hp / b.maxHp, 0, 1), 12);
  }
}

function wrap(g, text, maxW) {
  const words = text.split(' '); const lines = []; let cur = '';
  for (const w of words) {
    const t = cur ? cur + ' ' + w : w;
    if (g.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t;
  }
  if (cur) lines.push(cur);
  return lines;
}
