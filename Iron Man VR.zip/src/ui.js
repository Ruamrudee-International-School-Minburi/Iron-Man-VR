import * as THREE from 'three';
import { SUITS, UNLOCK_TEXT } from './suits.js';
import { TIMES } from './world/sky.js';
import { SLOTS } from './save.js';

const PW = 1.7, PH = 1.06, CW = 1700, CH = 1060;
const _v = new THREE.Vector3(), _q = new THREE.Quaternion();

export class UI {
  constructor(game) {
    this.g = game;
    this.canvas = document.createElement('canvas'); this.canvas.width = CW; this.canvas.height = CH;
    this.ctx = this.canvas.getContext('2d');
    this.tex = new THREE.CanvasTexture(this.canvas); this.tex.colorSpace = THREE.SRGBColorSpace;
    this.panel = new THREE.Mesh(new THREE.PlaneGeometry(PW, PH), new THREE.MeshBasicMaterial({ map: this.tex, transparent: true, depthTest: false, depthWrite: false, toneMapped: false, fog: false, side: THREE.DoubleSide }));
    this.panel.renderOrder = 1100;
    this.panel.visible = false;
    game.scene.add(this.panel);
    this.buttons = [];
    this.tab = 'missions';
    this.open = false;
    this.hover = null;
    this.selMission = null; this.selSuit = null;
    this.raycaster = new THREE.Raycaster();
    // laser pointers
    this.lasers = {};
    for (const side of ['left', 'right']) {
      const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0, -1)]);
      const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0x7fd8ff, transparent: true, opacity: 0.8 }));
      line.scale.z = 3; line.visible = false; line.frustumCulled = false;
      const dot = new THREE.Mesh(new THREE.SphereGeometry(0.012, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff, depthTest: false }));
      dot.renderOrder = 1200; dot.visible = false;
      game.scene.add(dot);
      this.lasers[side] = { line, dot, attached: null };
    }
  }
  isOpen() { return this.open; }

  toggle(tab) {
    if (this.open && (!tab || tab === this.tab)) this.close();
    else this.show(tab);
  }
  show(tab) {
    if (tab) this.tab = tab;
    this.open = true;
    this.g.input.uiOpen = true;
    if (document.pointerLockElement) document.exitPointerLock();
    // place in front of the head
    const cam = this.g.camera;
    cam.getWorldPosition(_v);
    const dir = new THREE.Vector3(); cam.getWorldDirection(dir); dir.y = 0; dir.normalize();
    const d = this.g.input.xr ? 1.25 : 1.15;
    this.panel.position.copy(_v).addScaledVector(dir, d);
    this.panel.position.y = _v.y - (this.g.input.xr ? 0.1 : 0);
    this.panel.lookAt(_v.x, this.panel.position.y, _v.z);
    this.panel.visible = true;
    this.g.audio.ui('click');
    this.draw();
  }
  close() {
    this.open = false; this.panel.visible = false; this.g.input.uiOpen = false;
    this.g.audio.ui('click');
  }

  // ---------------------------------------------------------------- drawing
  btn(id, x, y, w, h, label, { active = false, disabled = false, color = null, sub = null, align = 'center', size = 30 } = {}) {
    const g = this.ctx;
    const hov = this.hover === id && !disabled;
    g.fillStyle = active ? 'rgba(255,211,74,0.25)' : hov ? 'rgba(127,216,255,0.28)' : 'rgba(127,216,255,0.08)';
    g.fillRect(x, y, w, h);
    g.strokeStyle = active ? '#ffd34a' : hov ? '#ffffff' : 'rgba(127,216,255,0.6)';
    g.lineWidth = active || hov ? 3 : 1.5;
    g.strokeRect(x, y, w, h);
    g.fillStyle = disabled ? 'rgba(255,255,255,0.35)' : color || '#ffffff';
    g.font = `bold ${size}px Arial`; g.textAlign = align; g.textBaseline = 'middle';
    const tx = align === 'center' ? x + w / 2 : x + 18;
    g.fillText(label, tx, sub ? y + h / 2 - 14 : y + h / 2);
    if (sub) { g.font = '22px Arial'; g.fillStyle = disabled ? 'rgba(255,255,255,0.3)' : '#9fc3dc'; g.fillText(sub, tx, y + h / 2 + 18); }
    this.buttons.push({ id, x, y, w, h, disabled });
  }
  text(t, x, y, size = 26, color = '#fff', align = 'left', bold = false) {
    const g = this.ctx; g.font = `${bold ? 'bold ' : ''}${size}px Arial`; g.fillStyle = color; g.textAlign = align; g.textBaseline = 'middle'; g.fillText(t, x, y);
  }
  wrapText(t, x, y, maxW, lh, size = 24, color = '#d8ecf8') {
    const g = this.ctx; g.font = `${size}px Arial`; g.fillStyle = color; g.textAlign = 'left';
    let line = '', yy = y;
    for (const w of t.split(' ')) { const test = line ? line + ' ' + w : w; if (g.measureText(test).width > maxW && line) { g.fillText(line, x, yy); line = w; yy += lh; } else line = test; }
    if (line) g.fillText(line, x, yy);
    return yy + lh;
  }

  draw() {
    const g = this.ctx, game = this.g;
    this.buttons = [];
    g.clearRect(0, 0, CW, CH);
    // glass panel
    const gr = g.createLinearGradient(0, 0, 0, CH);
    gr.addColorStop(0, 'rgba(4,22,38,0.92)'); gr.addColorStop(1, 'rgba(2,10,20,0.92)');
    g.fillStyle = gr; g.fillRect(0, 0, CW, CH);
    g.strokeStyle = '#7fd8ff'; g.lineWidth = 4; g.strokeRect(2, 2, CW - 4, CH - 4);
    g.fillStyle = 'rgba(127,216,255,0.6)'; g.fillRect(0, 96, CW, 2);
    this.text('J.A.R.V.I.S.', 40, 50, 44, '#7fd8ff', 'left', true);
    this.text('TACTICAL INTERFACE', 330, 52, 22, '#9fc3dc');
    const tabs = [['missions', 'MISSIONS'], ['suits', 'ARMORY'], ['saves', 'SAVES'], ['settings', 'SETTINGS']];
    tabs.forEach(([id, l], i) => this.btn('tab:' + id, 700 + i * 205, 20, 190, 60, l, { active: this.tab === id, size: 26 }));
    this.btn('close', CW - 170, 20, 140, 60, 'RESUME', { size: 26, color: '#ffd34a' });
    if (this.tab === 'missions') this.drawMissions();
    else if (this.tab === 'suits') this.drawSuits();
    else if (this.tab === 'saves') this.drawSaves();
    else this.drawSettings();
    this.tex.needsUpdate = true;
  }

  drawMissions() {
    const M = this.g.missions;
    const list = M.list();
    this.text('MAIN STORY', 40, 135, 26, '#ffd34a', 'left', true);
    let y = 160;
    list.filter((m) => m.main).forEach((m) => {
      const st = M.status(m.id);
      this.btn('mis:' + m.id, 40, y, 760, 64, m.title, { align: 'left', size: 26, active: this.selMission === m.id, disabled: st === 'locked', sub: st === 'locked' ? '🔒 Complete the previous mission' : st === 'done' ? '✔ Completed — replay' : m.where, color: st === 'done' ? '#8fffa8' : null });
      y += 70;
    });
    this.text('SIDE QUESTS', 40, y + 18, 26, '#ffd34a', 'left', true);
    y += 38;
    list.filter((m) => !m.main).forEach((m) => {
      const st = M.status(m.id);
      const best = M.bestText(m.id);
      this.btn('mis:' + m.id, 40, y, 760, 48, m.title, { align: 'left', size: 23, active: this.selMission === m.id, sub: null, color: st === 'done' ? '#8fffa8' : null });
      if (best) this.text(best, 785, y + 24, 20, '#9fc3dc', 'right');
      y += 53;
    });
    // detail pane
    const sel = list.find((m) => m.id === this.selMission);
    const x = 840;
    this.ctx.fillStyle = 'rgba(127,216,255,0.06)'; this.ctx.fillRect(x, 120, 820, 900);
    if (!sel) {
      this.wrapText('Select a mission. Main missions tell the story and unlock new armor. Side quests are repeatable — race the clock, hunt drones, rescue civilians and find hidden Stark Tech caches across the map.', x + 30, 180, 760, 36, 26);
      const c = this.g.save.data;
      this.text(`Caches found: ${c.caches.length} / 20`, x + 30, 420, 26, '#ffd34a');
      this.text(`Armor unlocked: ${SUITS.filter((s) => this.g.isUnlocked(s.id)).length} / ${SUITS.length}`, x + 30, 460, 26, '#ffd34a');
      this.text(`Enemies destroyed: ${c.kills}`, x + 30, 500, 26, '#ffd34a');
      if (M.active) this.btn('abort', x + 30, 900, 360, 80, 'ABORT CURRENT', { color: '#ff7a6a' });
      return;
    }
    this.text(sel.title, x + 30, 165, 38, '#ffffff', 'left', true);
    this.text(sel.where, x + 30, 210, 24, '#7fd8ff');
    let yy = this.wrapText(sel.desc, x + 30, 260, 760, 34, 26);
    if (sel.reward) { this.text('REWARD', x + 30, yy + 20, 22, '#ffd34a', 'left', true); this.text(sel.reward, x + 140, yy + 20, 24, '#ffffff'); yy += 50; }
    const best = M.bestText(sel.id);
    if (best) this.text(best, x + 30, yy + 20, 24, '#8fffa8');
    const st = M.status(sel.id);
    this.btn('start', x + 30, 900, 360, 80, M.active && M.active.def.id === sel.id ? 'RESTART' : 'START', { disabled: st === 'locked', color: '#ffd34a' });
    this.btn('waypoint', x + 420, 900, 360, 80, 'SET WAYPOINT', { disabled: st === 'locked' });
  }

  drawSuits() {
    const game = this.g;
    const cols = 4, bw = 395, bh = 100;
    SUITS.forEach((s, i) => {
      const x = 40 + (i % cols) * (bw + 12), y = 120 + Math.floor(i / cols) * (bh + 10);
      const un = game.isUnlocked(s.id);
      const eq = game.player.suited && game.player.suit.id === s.id;
      this.btn('suit:' + s.id, x, y, bw, bh, s.name, { align: 'left', active: this.selSuit === s.id, disabled: !un, sub: un ? (eq ? '● Equipped' : s.tag) : '🔒 ' + (UNLOCK_TEXT[s.unlock] || ''), color: eq ? '#ffd34a' : null, size: 28 });
      // color chips
      const g = this.ctx;
      [s.colors.p, s.colors.s].forEach((c, k) => { g.fillStyle = '#' + c.toString(16).padStart(6, '0'); g.fillRect(x + bw - 70 + k * 28, y + 14, 22, 22); });
    });
    const sel = SUITS.find((s) => s.id === this.selSuit);
    const y0 = 600;
    this.ctx.fillStyle = 'rgba(127,216,255,0.06)'; this.ctx.fillRect(40, y0, CW - 80, 420);
    if (!sel) { this.wrapText('Select an armor to see its stats. Deploy it anywhere — the suit flies to you, piece by piece.', 70, y0 + 50, 1500, 36, 28); return; }
    const S = sel.stats;
    this.text(`${sel.name}  —  ${sel.tag}`, 70, y0 + 45, 36, '#ffffff', 'left', true);
    this.wrapText(sel.desc, 70, y0 + 95, 900, 32, 24);
    const bar = (label, v, max, yy) => {
      this.text(label, 70, yy, 22, '#9fc3dc', 'left', true);
      const g = this.ctx; g.fillStyle = 'rgba(255,255,255,0.12)'; g.fillRect(260, yy - 10, 600, 20);
      g.fillStyle = '#7fd8ff'; g.fillRect(260, yy - 10, 600 * Math.min(1, v / max), 20);
    };
    bar('ARMOR', S.armor, 340, y0 + 180); bar('THRUST', S.thrust, 24, y0 + 215); bar('POWER', S.energy, 210, y0 + 250);
    bar('REPULSORS', S.repulsor || (S.primary === 'flamer' ? 20 : 0), 46, y0 + 285); bar('MISSILES', S.missiles, 14, y0 + 320);
    const traits = [];
    if (S.special === 'unibeam') traits.push('Unibeam'); if (S.special === 'minigun') traits.push('Shoulder minigun');
    if (S.primary === 'flamer') traits.push('Flamethrowers'); if (S.icing) traits.push('Ices above 3,500 m'); if (S.stealth) traits.push('Stealth');
    if ((S.regen || 1) > 1.3) traits.push('Fast self-repair'); if (sel.scale > 1.2) traits.push('Massive');
    this.text('TRAITS: ' + traits.join(' · '), 70, y0 + 365, 22, '#ffd34a');
    const un = this.g.isUnlocked(sel.id);
    this.btn('deploy', 1150, y0 + 260, 470, 110, un ? 'DEPLOY ARMOR' : 'LOCKED', { disabled: !un, color: '#ffd34a', size: 34 });
  }

  drawSaves() {
    const game = this.g;
    this.text('SAVE SLOTS', 60, 140, 28, '#ffd34a', 'left', true);
    this.text('The game autosaves to the active slot every minute and after missions, caches and suit changes.', 60, 180, 22, '#9fc3dc');
    SLOTS.forEach((n, i) => {
      const y = 220 + i * 200;
      const sm = game.slotSummary(n);
      const active = game.save.slot === n;
      const g = this.ctx;
      g.fillStyle = active ? 'rgba(255,211,74,0.12)' : 'rgba(127,216,255,0.06)';
      g.fillRect(60, y, 1580, 180);
      g.strokeStyle = active ? '#ffd34a' : 'rgba(127,216,255,0.4)'; g.lineWidth = active ? 3 : 1.5; g.strokeRect(60, y, 1580, 180);
      this.text(`SLOT ${n}`, 90, y + 40, 30, active ? '#ffd34a' : '#7fd8ff', 'left', true);
      if (active) this.text('● ACTIVE', 250, y + 40, 22, '#ffd34a', 'left', true);
      if (sm) {
        this.text(`${sm.suit}  ·  ${sm.where}`, 90, y + 88, 28, '#ffffff', 'left', true);
        this.text(`Story ${sm.story}/5   ·   Caches ${sm.caches}/20   ·   Armor ${sm.armor}/16   ·   Played ${sm.time}`, 90, y + 128, 23, '#d8ecf8');
        this.text(sm.saved ? 'Saved ' + sm.saved : '', 90, y + 160, 20, '#9fc3dc');
      } else this.text('Empty', 90, y + 100, 28, '#9fc3dc');
      this.btn('save:' + n, 1030, y + 40, 280, 100, this._confirmSlot === n ? 'OVERWRITE?' : 'SAVE HERE', { color: '#8fffa8', size: 28 });
      this.btn('load:' + n, 1330, y + 40, 280, 100, 'LOAD', { disabled: !sm, size: 28 });
    });
    this.btn('mainmenu', 60, 860, 480, 90, 'MAIN MENU', { color: '#ffd34a', size: 30 });
    this.text('Your progress is saved before returning to the main menu.', 580, 905, 22, '#9fc3dc');
  }

  drawSettings() {
    const s = this.g.settings;
    const rows = [
      ['thrustMode', 'Thrust direction', s.thrustMode === 'palm' ? 'PALM (Iron Man VR style)' : 'POINT (push opposite fingers)'],
      ['flightAssist', 'Flight stabilizers', s.flightAssist ? 'ON' : 'OFF'],
      ['smoothTurn', 'Turning (right stick)', s.smoothTurn ? 'SMOOTH' : 'SNAP 30°'],
      ['vignette', 'Comfort vignette at speed', s.vignette ? 'ON' : 'OFF'],
      ['easyAim', 'Aim assist', s.easyAim ? 'STRONG' : 'LIGHT'],
      ['time', 'Time of day', TIMES[s.time].label],
      ['voice', 'J.A.R.V.I.S. voice', this.g.audio.voiceOn ? 'ON' : 'OFF'],
      ['unlockAll', 'Unlock all armor (sandbox)', s.unlockAll ? 'ON' : 'OFF'],
      ['godMode', 'Invincible', s.godMode ? 'ON' : 'OFF'],
    ];
    rows.forEach(([id, label, val], i) => {
      const y = 125 + i * 82;
      this.text(label, 60, y + 35, 28, '#d8ecf8');
      this.btn('set:' + id, 760, y, 560, 70, val, { size: 26 });
    });
    this.btn('home', 1360, 125, 300, 70, 'FLY HOME', { size: 26, color: '#ffd34a' });
    this.btn('workshop', 1360, 207, 300, 70, 'TO WORKSHOP', { size: 26 });
    this.btn('tower', 1360, 289, 300, 70, 'TO STARK TOWER', { size: 26 });
    this.btn('suitdown', 1360, 371, 300, 70, 'REMOVE ARMOR', { size: 26, disabled: !this.g.player.suited });
    this.btn('mainmenu', 1360, 453, 300, 70, 'MAIN MENU', { size: 26, color: '#ffd34a' });
    this.btn('reset', 1360, 863, 300, 70, 'RESET PROGRESS', { size: 24, color: '#ff7a6a' });
  }

  // ---------------------------------------------------------------- interaction
  click(id) {
    const game = this.g, s = game.settings, M = game.missions;
    if (!id.startsWith('save:')) this._confirmSlot = 0;
    if (id.startsWith('tab:')) { this.tab = id.slice(4); }
    else if (id === 'close') { this.close(); return; }
    else if (id.startsWith('mis:')) this.selMission = id.slice(4);
    else if (id === 'start') { M.start(this.selMission); this.close(); return; }
    else if (id === 'waypoint') { M.setWaypoint(this.selMission); this.close(); return; }
    else if (id === 'abort') { M.abort(); }
    else if (id.startsWith('suit:')) this.selSuit = id.slice(5);
    else if (id === 'deploy') { this.close(); game.deploySuit(this.selSuit); return; }
    else if (id.startsWith('set:')) {
      const k = id.slice(4);
      if (k === 'thrustMode') s.thrustMode = s.thrustMode === 'palm' ? 'point' : 'palm';
      else if (k === 'time') { const keys = Object.keys(TIMES); s.time = keys[(keys.indexOf(s.time) + 1) % keys.length]; game.applyTime(); }
      else if (k === 'voice') { game.audio.voiceOn = !game.audio.voiceOn; s.voice = game.audio.voiceOn; }
      else if (k === 'unlockAll') { s.unlockAll = !s.unlockAll; game.refreshPods(); }
      else s[k] = !s[k];
      game.saveSettings();
    }
    else if (id === 'home') { this.close(); game.fastTravel('roof'); return; }
    else if (id === 'workshop') { this.close(); game.fastTravel('workshop'); return; }
    else if (id === 'tower') { this.close(); game.fastTravel('tower'); return; }
    else if (id === 'suitdown') { this.close(); game.player.suitDown(); game.audio.say('Armor disengaged.'); return; }
    else if (id === 'mainmenu') { this.g.toMainMenu(); return; }
    else if (id.startsWith('save:')) {
      const n = Number(id.slice(5));
      const occupied = n !== game.save.slot && game.save.read(n);
      if (occupied && this._confirmSlot !== n) { this._confirmSlot = n; }
      else { this._confirmSlot = 0; game.saveToSlot(n); }
    }
    else if (id.startsWith('load:')) {
      const n = Number(id.slice(5));
      this.close();
      game.fade(() => { game.loadSlot(n); game.hud.toast(`Loaded Slot ${n}`, '#8fffa8'); });
      return;
    }
    else if (id === 'reset') { if (this._confirmReset) { game.save.reset(); game.refreshPods(); this._confirmReset = false; game.hud.toast('Progress reset'); } else { this._confirmReset = true; game.hud.toast('Press RESET again to confirm', '#ff7a6a'); } }
    this.g.audio.ui('click');
    this.draw();
  }

  hitTest(ray) {
    this.raycaster.ray.copy(ray);
    const hit = this.raycaster.intersectObject(this.panel, false)[0];
    if (!hit) return null;
    const u = hit.uv.x * CW, v = (1 - hit.uv.y) * CH;
    const b = this.buttons.find((b) => u >= b.x && u <= b.x + b.w && v >= b.y && v <= b.y + b.h);
    return { point: hit.point, dist: hit.distance, button: b && !b.disabled ? b.id : null };
  }

  update(dt) {
    const inp = this.g.input;
    const xr = inp.xr;
    // attach lasers to XR rays
    for (const side of ['left', 'right']) {
      const L = this.lasers[side], h = inp.hands[side];
      if (xr && h.ray && L.attached !== h.ray) { h.ray.add(L.line); L.attached = h.ray; }
    }
    const pointing = this.g.wantsPointer();
    let newHover = null;
    if (this.open) {
      if (xr) {
        for (const side of ['left', 'right']) {
          const h = inp.hands[side], L = this.lasers[side];
          if (!h.ray) continue;
          const ray = new THREE.Ray(h.ray.getWorldPosition(new THREE.Vector3()), new THREE.Vector3(0, 0, -1).applyQuaternion(h.ray.getWorldQuaternion(_q)));
          const r = this.hitTest(ray);
          L.line.visible = true;
          L.line.scale.z = r ? r.dist : 3;
          L.dot.visible = !!r; if (r) L.dot.position.copy(r.point);
          if (r && r.button) { newHover = r.button; if (h.pressed('trigger')) this.click(r.button); }
        }
      } else {
        const ray = new THREE.Raycaster();
        ray.setFromCamera(new THREE.Vector2(inp.mouse.x, inp.mouse.y), this.g.camera);
        const r = this.hitTest(ray.ray);
        if (r && r.button) { newHover = r.button; if (inp.mousePressed('left')) this.click(r.button); }
      }
      if (newHover !== this.hover) { this.hover = newHover; if (newHover) this.g.audio.ui('hover'); this.draw(); }
      // follow if the player walked/flew far away
      const cam = this.g.camera.getWorldPosition(_v);
      if (cam.distanceTo(this.panel.position) > 4) this.show();
    } else {
      for (const side of ['left', 'right']) {
        const L = this.lasers[side];
        L.line.visible = xr && pointing; L.dot.visible = false; L.line.scale.z = 4;
      }
    }
  }
}
