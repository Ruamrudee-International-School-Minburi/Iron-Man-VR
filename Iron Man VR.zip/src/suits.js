import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { normalMapTexture } from './util.js';

// ------------------------------------------------------------------ suit catalogue
// unlock: 'start' | mission id | side-quest key. stats.thrust = m/s² per hand at full trigger.
const RED = 0x9b0f12, GOLD = 0xc9a24a, DARK = 0x2a2b2e, SILVER = 0xb8bcc2;
export const SUITS = [
  { id: 'mk1', name: 'Mark I', tag: 'The Cave Suit', desc: 'Built in a cave with a box of scraps. Heavy iron, flamethrowers, barely flies.',
    colors: { p: 0x6e6a64, s: 0x5a5650, t: 0x3a3836, eye: 0xfff1c8, reactor: 0xbfe8ff }, finish: 'iron', reactor: 'circle', accent: ['face'], bulk: 1.3,
    stats: { armor: 190, thrust: 10.5, energy: 70, energyRegen: 9, repulsor: 0, fireRate: 0.05, missiles: 1, primary: 'flamer', special: 'none', regen: 0.6 }, unlock: 'start' },
  { id: 'mk2', name: 'Mark II', tag: 'The Prototype', desc: 'Chrome test suit. Fast, fragile — and it ices up above 3,500 m.',
    colors: { p: SILVER, s: 0xa3a7ad, t: 0x4a4c50, eye: 0xdff4ff, reactor: 0xbfe8ff }, finish: 'chrome', reactor: 'circle', accent: ['face'], bulk: 1.0,
    stats: { armor: 90, thrust: 16, energy: 110, energyRegen: 14, repulsor: 18, fireRate: 0.22, missiles: 0, special: 'unibeam', icing: true, regen: 1 }, unlock: 'start' },
  { id: 'mk3', name: 'Mark III', tag: 'The Classic', desc: 'Gold-titanium alloy, hot-rod red. The one that started it all.',
    colors: { p: RED, s: GOLD, t: DARK, eye: 0xe9fbff, reactor: 0xbfe8ff }, finish: 'gloss', reactor: 'circle', accent: ['face', 'abs', 'forearm', 'thigh', 'shin'], bulk: 1.0,
    stats: { armor: 120, thrust: 17, energy: 120, energyRegen: 15, repulsor: 22, fireRate: 0.2, missiles: 6, special: 'unibeam', regen: 1 }, unlock: 'start' },
  { id: 'mk5', name: 'Mark V', tag: 'The Suitcase', desc: 'Portable armor. Light, agile, thin plating.',
    colors: { p: RED, s: 0xc7c9cc, t: 0x55575c, eye: 0xe9fbff, reactor: 0xbfe8ff }, finish: 'gloss', reactor: 'circle', accent: ['face', 'abs', 'upperarm', 'thigh', 'chest'], bulk: 0.95,
    stats: { armor: 85, thrust: 20, energy: 100, energyRegen: 16, repulsor: 20, fireRate: 0.18, missiles: 0, special: 'unibeam', regen: 1 }, unlock: 'm2' },
  { id: 'mk6', name: 'Mark VI', tag: 'New Element', desc: 'Triangular reactor powered by a brand-new element. Stronger unibeam.',
    colors: { p: RED, s: GOLD, t: DARK, eye: 0xe9fbff, reactor: 0xcff6ff }, finish: 'gloss', reactor: 'tri', accent: ['face', 'abs', 'forearm', 'thigh', 'shin', 'shoulder'], bulk: 1.02,
    stats: { armor: 125, thrust: 18, energy: 140, energyRegen: 18, repulsor: 24, fireRate: 0.19, missiles: 6, special: 'unibeam', beamMult: 1.35, regen: 1.1 }, unlock: 'm3' },
  { id: 'mk7', name: 'Mark VII', tag: 'Heavy Assault', desc: 'Deploys anywhere. Packed with micro-missiles.',
    colors: { p: RED, s: GOLD, t: DARK, eye: 0xe9fbff, reactor: 0xcff6ff }, finish: 'gloss', reactor: 'tri', accent: ['face', 'abs', 'forearm', 'thigh', 'shin', 'shoulder', 'chest'], bulk: 1.08,
    stats: { armor: 150, thrust: 19, energy: 150, energyRegen: 18, repulsor: 26, fireRate: 0.18, missiles: 12, special: 'unibeam', regen: 1.1 }, unlock: 'm5' },
  { id: 'wm', name: 'War Machine', tag: 'Mark II (Rhodey)', desc: 'Gunmetal battle armor with a shoulder-mounted minigun.',
    colors: { p: 0x4a4d52, s: 0x2b2d30, t: 0x1b1c1e, eye: 0xe9fbff, reactor: 0xbfe8ff }, finish: 'gunmetal', reactor: 'circle', accent: ['face', 'abs', 'shoulder', 'shin'], bulk: 1.12, gun: true,
    stats: { armor: 170, thrust: 16, energy: 130, energyRegen: 16, repulsor: 20, fireRate: 0.2, missiles: 8, special: 'minigun', regen: 1 }, unlock: 'm4' },
  { id: 'ip', name: 'Iron Patriot', tag: 'Red, White & Blue', desc: 'War Machine rebranded in national colors. Minigun included.',
    colors: { p: 0x1d3a86, s: 0xa1141a, t: 0xd8d8dc, eye: 0xe9fbff, reactor: 0xffffff }, finish: 'gloss', reactor: 'star', accent: ['face', 'abs', 'forearm', 'thigh', 'shoulder'], bulk: 1.1, gun: true,
    stats: { armor: 160, thrust: 17, energy: 130, energyRegen: 17, repulsor: 22, fireRate: 0.19, missiles: 10, special: 'minigun', regen: 1 }, unlock: 'side_drones' },
  { id: 'mk16', name: 'Mark XVI', tag: 'Nightclub (Stealth)', desc: 'Matte black stealth armor. Enemies struggle to see or track you.',
    colors: { p: 0x1c1d20, s: 0x2c2e33, t: 0x0d0d0f, eye: 0xf2f6ff, reactor: 0xdfe9ff }, finish: 'matte', reactor: 'circle', accent: ['face', 'abs', 'shin'], bulk: 0.98,
    stats: { armor: 100, thrust: 18, energy: 120, energyRegen: 16, repulsor: 22, fireRate: 0.2, missiles: 4, special: 'unibeam', stealth: true, regen: 1 }, unlock: 'side_caches10' },
  { id: 'mk33', name: 'Mark XXXIII', tag: 'Silver Centurion', desc: 'High-capacity energy cells. Unibeam that never quits.',
    colors: { p: 0x8e1016, s: 0xc0c3c8, t: 0x33353a, eye: 0xe9fbff, reactor: 0xbfe8ff }, finish: 'gloss', reactor: 'circle', accent: ['face', 'abs', 'forearm', 'thigh', 'shin', 'shoulder', 'chest'], bulk: 1.03,
    stats: { armor: 140, thrust: 18, energy: 190, energyRegen: 26, repulsor: 26, fireRate: 0.19, missiles: 6, special: 'unibeam', regen: 1.1 }, unlock: 'side_races' },
  { id: 'mk42', name: 'Mark XLII', tag: 'Extremis Prodigal Son', desc: 'Remote-controlled, modular, mostly gold. Quick regeneration.',
    colors: { p: 0x9a1015, s: 0xd2aa4e, t: DARK, eye: 0xe9fbff, reactor: 0xbfe8ff }, finish: 'gloss', reactor: 'circle', accent: ['face', 'abs', 'forearm', 'thigh', 'shin', 'chest', 'upperarm', 'shoulder'], bulk: 1.0,
    stats: { armor: 110, thrust: 20, energy: 130, energyRegen: 18, repulsor: 25, fireRate: 0.19, missiles: 6, special: 'unibeam', regen: 1.4 }, unlock: 'start' },
  { id: 'mk43', name: 'Mark XLIII', tag: 'Age of Ultron', desc: 'Sleek and balanced. A great all-rounder.',
    colors: { p: 0xa3121a, s: 0xd6ae52, t: DARK, eye: 0xe9fbff, reactor: 0xcff6ff }, finish: 'gloss', reactor: 'circle', accent: ['face', 'abs', 'forearm', 'thigh', 'shoulder', 'chest'], bulk: 1.02,
    stats: { armor: 135, thrust: 20, energy: 140, energyRegen: 19, repulsor: 27, fireRate: 0.18, missiles: 8, special: 'unibeam', regen: 1.2 }, unlock: 'side_rescue' },
  { id: 'hb', name: 'Hulkbuster', tag: 'Mark XLIV "Veronica"', desc: 'Massive. Slow to turn, devastating to be hit by.',
    colors: { p: 0xa0141a, s: 0xcfa549, t: 0x3b3c40, eye: 0xe9fbff, reactor: 0xcff6ff }, finish: 'gloss', reactor: 'circle', accent: ['face', 'abs', 'forearm', 'thigh', 'shin', 'shoulder'], bulk: 1.55, scale: 1.4,
    stats: { armor: 340, thrust: 14, energy: 170, energyRegen: 18, repulsor: 46, fireRate: 0.34, missiles: 10, special: 'unibeam', beamMult: 1.6, regen: 0.9 }, unlock: 'm5' },
  { id: 'mk46', name: 'Mark XLVI', tag: 'Civil War', desc: 'Faster thrusters and a tougher shell.',
    colors: { p: 0x8f0f15, s: 0xc89c45, t: 0x6d6e72, eye: 0xe9fbff, reactor: 0xcff6ff }, finish: 'gloss', reactor: 'circle', accent: ['face', 'abs', 'forearm', 'thigh', 'chest'], bulk: 1.02,
    stats: { armor: 145, thrust: 21, energy: 150, energyRegen: 20, repulsor: 28, fireRate: 0.18, missiles: 8, special: 'unibeam', regen: 1.3 }, unlock: 'm1' },
  { id: 'mk50', name: 'Mark L', tag: 'Bleeding Edge Nanotech', desc: 'Nanotech armor. Repairs itself rapidly, huge energy reserve.',
    colors: { p: 0x7e0c12, s: 0xc39a46, t: 0x1e1f22, eye: 0xf0fdff, reactor: 0xa8f0ff }, finish: 'nano', reactor: 'hex', accent: ['face', 'abs', 'forearm', 'thigh', 'shin', 'chest'], bulk: 0.98,
    stats: { armor: 150, thrust: 22, energy: 170, energyRegen: 24, repulsor: 30, fireRate: 0.17, missiles: 10, special: 'unibeam', regen: 2.0 }, unlock: 'start' },
  { id: 'mk85', name: 'Mark LXXXV', tag: 'Endgame', desc: 'The final armor. Best at everything.',
    colors: { p: 0x8a0d13, s: 0xd4a64a, t: 0x2a1c1c, eye: 0xf5fdff, reactor: 0xbff4ff }, finish: 'nano', reactor: 'circle', accent: ['face', 'abs', 'forearm', 'thigh', 'shin', 'chest', 'shoulder'], bulk: 1.03,
    stats: { armor: 210, thrust: 24, energy: 210, energyRegen: 28, repulsor: 34, fireRate: 0.16, missiles: 14, special: 'unibeam', beamMult: 1.4, regen: 2.2 }, unlock: 'side_caches20' },
];
export const suitById = (id) => SUITS.find((s) => s.id === id) || SUITS[2];

export const UNLOCK_TEXT = {
  start: 'Available', m1: 'Main mission 1: Flight Test', m2: 'Main mission 2: Gulmira', m3: 'Main mission 3: Drone Swarm',
  m4: 'Main mission 4: Expo Showdown', m5: 'Main mission 5: Iron Monger', side_drones: 'Side: finish 2 Drone Hunts',
  side_caches10: 'Side: collect 10 Stark Tech caches', side_caches20: 'Side: collect all 20 caches', side_races: 'Side: finish all 3 races',
  side_rescue: 'Side: complete the Rescue quest',
};

// ------------------------------------------------------------------ materials
let _metalDetail = null;
const matCache = new Map();
export function suitMaterials(suit) {
  if (matCache.has(suit.id)) return matCache.get(suit.id);
  if (!_metalDetail) { _metalDetail = normalMapTexture(128, 14, 0.5); _metalDetail.repeat.set(3, 3); }
  const f = suit.finish;
  const base = (color, extra = {}) => {
    const o = { color, metalness: 0.9, roughness: 0.3, clearcoat: 1, clearcoatRoughness: 0.08, normalMap: _metalDetail, normalScale: new THREE.Vector2(0.05, 0.05), ...extra };
    if (f === 'chrome') Object.assign(o, { metalness: 1, roughness: 0.12, clearcoat: 0.6 });
    if (f === 'iron') Object.assign(o, { metalness: 0.7, roughness: 0.62, clearcoat: 0, normalScale: new THREE.Vector2(0.6, 0.6) });
    if (f === 'matte') Object.assign(o, { metalness: 0.5, roughness: 0.6, clearcoat: 0.15 });
    if (f === 'gunmetal') Object.assign(o, { metalness: 0.92, roughness: 0.36, clearcoat: 0.5 });
    if (f === 'nano') Object.assign(o, { metalness: 0.95, roughness: 0.22, clearcoat: 1, sheen: 0.4, sheenColor: new THREE.Color(0xff5050) });
    return new THREE.MeshPhysicalMaterial(o);
  };
  const m = {
    p: base(suit.colors.p),
    s: base(suit.colors.s, f === 'gloss' || f === 'nano' ? { metalness: 1, roughness: 0.22 } : {}),
    t: base(suit.colors.t, { metalness: 0.8, roughness: 0.5, clearcoat: 0 }),
    eye: new THREE.MeshBasicMaterial({ color: new THREE.Color(suit.colors.eye).multiplyScalar(2.2), toneMapped: false }),
    glow: new THREE.MeshBasicMaterial({ color: new THREE.Color(suit.colors.reactor).multiplyScalar(2.5), toneMapped: false }),
  };
  matCache.set(suit.id, m);
  return m;
}

// ------------------------------------------------------------------ geometry helpers
const rbox = (w, h, d, r = 0.02) => new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2.1, h / 2.1, d / 2.1));
const cap = (r, len, rs = 12) => new THREE.CapsuleGeometry(r, len, 4, rs);
const sph = (r, ws = 20, hs = 14) => new THREE.SphereGeometry(r, ws, hs);
const _m4 = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _s = new THREE.Vector3(), _p = new THREE.Vector3();
function place(geo, x, y, z, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
  _m4.compose(_p.set(x, y, z), _q.setFromEuler(_e.set(rx, ry, rz)), _s.set(sx, sy, sz));
  return geo.applyMatrix4(_m4);
}

// Returns a list of {part, mat, geo} for a full suit, model space: feet at y=0, facing +Z.
function suitPieces(suit) {
  const b = suit.bulk || 1;
  const acc = new Set(suit.accent);
  const A = (k) => (acc.has(k) ? 's' : 'p');
  const out = [];
  const add = (part, mat, geo) => out.push({ part, mat, geo });

  // HEAD
  add('helmet', 'p', place(sph(0.122, 24, 18), 0, 1.68, -0.005, 0, 0, 0, 0.92, 1.1, 1.02));
  add('helmet', A('face'), place(new THREE.SphereGeometry(0.126, 24, 16, Math.PI / 2 - 0.78, 1.56, 0.72, 1.72), 0, 1.68, 0.004, 0, 0, 0, 0.93, 1.1, 1.02));
  add('helmet', 'p', place(rbox(0.05, 0.12, 0.05, 0.02), 0, 1.75, 0.09, -0.35, 0, 0)); // brow ridge
  for (const sx of [-1, 1]) {
    add('helmet', 'eye', place(new THREE.BoxGeometry(0.042, 0.011, 0.012), sx * 0.04, 1.705, 0.121, 0, sx * 0.25, sx * -0.17));
    add('helmet', 't', place(new THREE.BoxGeometry(0.004, 0.05, 0.004), sx * 0.04, 1.63, 0.123, 0, 0, 0)); // jaw lines
  }
  add('helmet', 't', place(new THREE.BoxGeometry(0.06, 0.004, 0.004), 0, 1.6, 0.124));
  add('neck', 't', place(new THREE.CylinderGeometry(0.06, 0.07, 0.1, 12), 0, 1.53, 0));

  // TORSO
  add('chest', 'p', place(rbox(0.42 * b, 0.3, 0.25 * b, 0.07), 0, 1.36, 0));
  for (const sx of [-1, 1]) add('chest', A('chest'), place(rbox(0.16 * b, 0.14, 0.05, 0.03), sx * 0.1 * b, 1.4, 0.115 * b, 0.1, sx * 0.25, 0));
  // reactor
  const rs = suit.reactor;
  const rGeo = rs === 'tri' ? new THREE.CylinderGeometry(0.075, 0.075, 0.02, 3) : rs === 'hex' ? new THREE.CylinderGeometry(0.06, 0.06, 0.02, 6) : rs === 'star' ? new THREE.CylinderGeometry(0.06, 0.06, 0.02, 5) : new THREE.CylinderGeometry(0.046, 0.046, 0.02, 24);
  add('chest', 'glow', place(rGeo, 0, 1.37, 0.128 * b, Math.PI / 2, 0, rs === 'tri' ? Math.PI : 0));
  add('chest', 't', place(new THREE.TorusGeometry(rs === 'tri' ? 0.07 : 0.055, 0.012, 8, rs === 'tri' ? 3 : 24), 0, 1.37, 0.124 * b, 0, 0, rs === 'tri' ? -Math.PI / 2 : 0));
  add('chest', 'p', place(rbox(0.3 * b, 0.12, 0.08, 0.03), 0, 1.36, -0.13 * b)); // back plate
  for (const sx of [-1, 1]) add('chest', 't', place(rbox(0.06, 0.2, 0.03, 0.01), sx * 0.08, 1.33, -0.17 * b, 0.15, 0, 0)); // back flaps
  add('abs', 't', place(cap(0.13 * b, 0.12), 0, 1.13, 0, 0, 0, 0, 1, 1, 0.75));
  for (let i = 0; i < 3; i++) add('abs', A('abs'), place(rbox(0.22 * b, 0.05, 0.05, 0.02), 0, 1.2 - i * 0.065, 0.085 * b));
  add('pelvis', 'p', place(rbox(0.33 * b, 0.13, 0.21 * b, 0.05), 0, 0.98, 0));
  add('pelvis', A('abs'), place(rbox(0.12, 0.09, 0.04, 0.02), 0, 0.96, 0.1 * b));

  // ARMS
  for (const sx of [-1, 1]) {
    const side = sx < 0 ? 'L' : 'R';
    const ox = sx * 0.25 * b;
    add('shoulder' + side, A('shoulder'), place(sph(0.088 * b), ox, 1.44, 0, 0, 0, 0, 1.05, 0.9, 1));
    add('shoulder' + side, 'p', place(rbox(0.13 * b, 0.05, 0.16 * b, 0.02), ox * 1.05, 1.5, 0, 0, 0, sx * -0.35));
    add('upperarm' + side, A('upperarm'), place(cap(0.054 * b, 0.17), ox + sx * 0.02, 1.27, 0, 0, 0, sx * 0.08));
    add('upperarm' + side, 't', place(sph(0.05 * b), ox + sx * 0.03, 1.13, 0));
    add('forearm' + side, A('forearm'), place(new THREE.CylinderGeometry(0.058 * b, 0.046 * b, 0.24, 14), ox + sx * 0.045, 1.0, 0.01, 0, 0, sx * 0.06));
    add('forearm' + side, 'p', place(rbox(0.07 * b, 0.12, 0.08 * b, 0.02), ox + sx * 0.06, 1.02, 0.02));
    add('hand' + side, 'p', place(rbox(0.045, 0.1, 0.08, 0.018), ox + sx * 0.055, 0.82, 0.01));
    add('hand' + side, 't', place(rbox(0.035, 0.07, 0.07, 0.012), ox + sx * 0.055, 0.745, 0.01));
    add('hand' + side, 'glow', place(new THREE.CylinderGeometry(0.018, 0.018, 0.01, 12), ox + sx * 0.03, 0.82, 0.01, 0, 0, Math.PI / 2));
    if (suit.gun && sx > 0) { // War Machine / Patriot shoulder minigun
      for (let k = 0; k < 6; k++) {
        const a = (k / 6) * Math.PI * 2;
        add('shoulderR', 't', place(new THREE.CylinderGeometry(0.012, 0.012, 0.42, 6), ox + 0.02 + Math.cos(a) * 0.03, 1.62 + Math.sin(a) * 0.03, 0.12, Math.PI / 2, 0, 0));
      }
      add('shoulderR', 'p', place(rbox(0.12, 0.1, 0.18, 0.02), ox + 0.02, 1.62, -0.06));
    }
  }
  // LEGS
  for (const sx of [-1, 1]) {
    const side = sx < 0 ? 'L' : 'R';
    const ox = sx * 0.1 * b;
    add('thigh' + side, A('thigh'), place(cap(0.083 * b, 0.26), ox, 0.73, 0));
    add('thigh' + side, 'p', place(rbox(0.12 * b, 0.22, 0.06, 0.025), ox * 1.1, 0.75, 0.06 * b));
    add('shin' + side, 't', place(sph(0.065 * b), ox, 0.52, 0.01));
    add('shin' + side, A('shin'), place(cap(0.064 * b, 0.25), ox, 0.31, 0));
    add('shin' + side, 'p', place(rbox(0.1 * b, 0.24, 0.05, 0.02), ox, 0.32, 0.055 * b));
    add('boot' + side, 'p', place(rbox(0.11 * b, 0.12, 0.25 * b, 0.035), ox, 0.06, 0.035));
    add('boot' + side, 'glow', place(new THREE.CylinderGeometry(0.03, 0.03, 0.01, 12), ox, 0.0, -0.02));
  }

  const sc = suit.scale || 1;
  if (sc !== 1) for (const o of out) o.geo.scale(sc, sc, sc);
  return out;
}

const PART_GROUPS = ['helmet', 'chest', 'abs', 'pelvis', 'neck', 'shoulderL', 'shoulderR', 'upperarmL', 'upperarmR', 'forearmL', 'forearmR', 'handL', 'handR', 'thighL', 'thighR', 'shinL', 'shinR', 'bootL', 'bootR'];

// merged: one mesh per material (cheap — for displays). Otherwise one sub-group per armor piece (for the suit-up animation).
export function buildSuitModel(suit, { merged = true, shadows = true } = {}) {
  const mats = suitMaterials(suit);
  const pieces = suitPieces(suit);
  const root = new THREE.Group();
  root.name = 'suit-' + suit.id;
  if (merged) {
    const byMat = {};
    for (const p of pieces) (byMat[p.mat] ||= []).push(p.geo);
    for (const k in byMat) {
      const geos = byMat[k].map((g) => { g.deleteAttribute('uv1'); return g.index ? g : g; });
      const mesh = new THREE.Mesh(mergeGeometries(normalizeAttrs(geos)), mats[k]);
      mesh.castShadow = shadows && k !== 'glow' && k !== 'eye';
      root.add(mesh);
    }
  } else {
    const groups = {};
    for (const name of PART_GROUPS) { const g = new THREE.Group(); g.name = name; groups[name] = g; root.add(g); }
    for (const p of pieces) {
      const mesh = new THREE.Mesh(p.geo, mats[p.mat]);
      mesh.castShadow = shadows && p.mat !== 'glow' && p.mat !== 'eye';
      (groups[p.part] || root).add(mesh);
    }
    root.userData.parts = groups;
  }
  return root;
}

function normalizeAttrs(geos) {
  // make every geometry indexed with the same attribute set (position/normal/uv)
  return geos.map((g) => {
    for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(k)) g.deleteAttribute(k);
    if (!g.index) {
      const idx = []; for (let i = 0; i < g.attributes.position.count; i++) idx.push(i);
      g.setIndex(idx);
    }
    return g;
  });
}

// ------------------------------------------------------------------ first-person gauntlets
// Built in WebXR grip space: fingers toward -Z, thumb +Y, forearm extends toward +Z.
// Palm normal: left hand +X, right hand -X (OpenXR grip convention).
export function buildGauntlet(suit, side) {
  const g = new THREE.Group();
  const sx = side === 'left' ? 1 : -1; // palm direction on X
  const sc = suit ? Math.min(suit.scale || 1, 1.25) * (suit.bulk > 1.2 ? 1.1 : 1) : 1;
  let mats;
  if (suit) mats = suitMaterials(suit);
  else {
    const skin = new THREE.MeshStandardMaterial({ color: 0xc89474, roughness: 0.6 });
    const sleeve = new THREE.MeshStandardMaterial({ color: 0x1c1c1e, roughness: 0.9 });
    const watch = new THREE.MeshStandardMaterial({ color: 0x888888, metalness: 1, roughness: 0.3 });
    mats = { p: skin, s: skin, t: sleeve, glow: watch, eye: watch };
  }
  const M = (geo, mat) => { const m = new THREE.Mesh(geo, mat); m.castShadow = false; g.add(m); return m; };
  if (suit) {
    M(place(new THREE.CylinderGeometry(0.052 * sc, 0.042 * sc, 0.26, 14), 0, 0, 0.19, Math.PI / 2, 0, 0), mats[suit.accent.includes('forearm') ? 's' : 'p']);
    M(place(rbox(0.075 * sc, 0.08 * sc, 0.14, 0.02), 0, 0.012, 0.17), mats.p);
    M(place(new THREE.TorusGeometry(0.043 * sc, 0.008, 6, 18), 0, 0, 0.06), mats.t);
  } else {
    M(place(new THREE.CylinderGeometry(0.035, 0.03, 0.26, 12), 0, 0, 0.19, Math.PI / 2, 0, 0), mats.p);
    M(place(new THREE.CylinderGeometry(0.05, 0.05, 0.08, 12), 0, 0, 0.33, Math.PI / 2, 0, 0), mats.t);
    M(place(new THREE.CylinderGeometry(0.036, 0.036, 0.022, 14), 0, 0, 0.08, Math.PI / 2, 0, 0), mats.glow);
  }
  // hand: flat "knife-hand" with palm facing ±X
  M(place(rbox(0.035 * sc, 0.085 * sc, 0.1 * sc, 0.014), 0, 0, -0.01), mats.p);
  for (let i = 0; i < 4; i++) {
    const f = M(place(rbox(0.022 * sc, 0.021 * sc, (0.078 - Math.abs(i - 1.2) * 0.008) * sc, 0.009), -sx * 0.004, (0.03 - i * 0.02) * sc, -0.09 * sc, 0, 0, 0), mats.p);
    f.rotation.y = sx * 0.25; // fingers curl slightly toward the palm
  }
  M(place(rbox(0.022 * sc, 0.02 * sc, 0.06 * sc, 0.008), sx * 0.02, 0.045 * sc, -0.03, 0, -sx * 0.5, 0), mats.p); // thumb
  // palm repulsor
  const palm = M(place(new THREE.CylinderGeometry(0.02 * sc, 0.02 * sc, 0.006, 16), sx * 0.019 * sc, 0, -0.01, 0, 0, Math.PI / 2), suit ? mats.glow.clone() : mats.p);
  const palmDir = new THREE.Vector3(sx, 0, 0);
  // thrust flame (additive cone), points out of the palm
  const flameMat = new THREE.MeshBasicMaterial({ color: 0xbfe6ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
  const flameGeo = new THREE.ConeGeometry(0.03, 0.5, 14, 1, true);
  flameGeo.rotateX(Math.PI);
  flameGeo.translate(0, -0.25, 0); // wide end at the palm, tip 0.5 m out along -Y
  flameGeo.rotateZ(sx > 0 ? Math.PI / 2 : -Math.PI / 2); // -Y -> palm direction
  const flame = new THREE.Mesh(flameGeo, flameMat);
  flame.position.set(sx * 0.024 * sc, 0, -0.01);
  flame.visible = !!suit;
  const core = new THREE.Mesh(flameGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
  core.scale.set(0.5, 0.55, 0.5);
  flame.add(core);
  g.add(flame);
  g.userData = { palm, palmDir, flame, flameCore: core };
  return g;
}
