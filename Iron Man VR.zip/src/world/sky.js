import * as THREE from 'three';
import { Sky } from 'three/addons/objects/Sky.js';

// Time-of-day presets: sun elevation/azimuth (deg), light colors, fog
export const TIMES = {
  golden: { label: 'Golden Hour', elev: 15, az: 245, sun: 0xffd2a1, sunI: 2.6, hemiSky: 0xffe2c4, hemiGround: 0x5a4a3a, hemiI: 0.85, fog: 0xd9b99a, exposure: 0.62, turbidity: 6, rayleigh: 2.2, night: false },
  day: { label: 'Midday', elev: 58, az: 200, sun: 0xfff4e5, sunI: 3.6, hemiSky: 0xcfe6ff, hemiGround: 0x6b5a45, hemiI: 1.0, fog: 0xbfd3e6, exposure: 0.48, turbidity: 3, rayleigh: 1.2, night: false },
  dusk: { label: 'Sunset', elev: 1.5, az: 255, sun: 0xff9a5a, sunI: 2.2, hemiSky: 0xffb08a, hemiGround: 0x3a2e2e, hemiI: 0.6, fog: 0xc98f72, exposure: 0.75, turbidity: 8, rayleigh: 3, night: false },
  night: { label: 'Night', elev: -12, az: 250, sun: 0x8fa8ff, sunI: 0.5, hemiSky: 0x33456e, hemiGround: 0x101018, hemiI: 0.55, fog: 0x0d1424, exposure: 0.9, turbidity: 2, rayleigh: 0.5, night: true },
};

export function buildSky(scene, renderer) {
  const sky = new Sky();
  sky.scale.setScalar(30000);
  sky.name = 'sky';
  scene.add(sky);

  const sun = new THREE.DirectionalLight(0xffffff, 3);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  const S = 90;
  Object.assign(sun.shadow.camera, { left: -S, right: S, top: S, bottom: -S, near: 1, far: 900 });
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.04;
  scene.add(sun, sun.target);

  const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1);
  scene.add(hemi);

  // a simple moon for night
  const moon = new THREE.Mesh(new THREE.SphereGeometry(180, 24, 16), new THREE.MeshBasicMaterial({ color: 0xdfe6ff, fog: false }));
  moon.visible = false;
  scene.add(moon);

  // stars
  const starGeo = new THREE.BufferGeometry();
  const sp = new Float32Array(2500 * 3);
  for (let i = 0; i < 2500; i++) {
    const v = new THREE.Vector3().randomDirection(); v.y = Math.abs(v.y) * 0.9 + 0.05; v.normalize().multiplyScalar(14000);
    sp.set([v.x, v.y, v.z], i * 3);
  }
  starGeo.setAttribute('position', new THREE.BufferAttribute(sp, 3));
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 2, sizeAttenuation: false, fog: false, transparent: true, opacity: 0.85 }));
  stars.visible = false;
  scene.add(stars);

  scene.fog = new THREE.Fog(0xcccccc, 2500, 23000);
  const pmrem = new THREE.PMREMGenerator(renderer);
  let envRT = null;
  const sunDir = new THREE.Vector3();
  let current = null;

  function setTime(name) {
    const T = TIMES[name] || TIMES.golden;
    current = T;
    const phi = THREE.MathUtils.degToRad(90 - Math.max(T.elev, -4));
    const theta = THREE.MathUtils.degToRad(T.az);
    sunDir.setFromSphericalCoords(1, phi, theta);
    const u = sky.material.uniforms;
    u.sunPosition.value.copy(sunDir);
    u.turbidity.value = T.turbidity; u.rayleigh.value = T.rayleigh;
    u.mieCoefficient.value = 0.004; u.mieDirectionalG.value = 0.85;
    if (u.cloudCoverage) { u.cloudCoverage.value = T.night ? 0.25 : 0.35; u.cloudDensity.value = 0.35; }
    if (u.showSunDisc) u.showSunDisc.value = T.night ? 0 : 1;
    sun.color.set(T.sun); sun.intensity = T.sunI;
    hemi.color.set(T.hemiSky); hemi.groundColor.set(T.hemiGround); hemi.intensity = T.hemiI;
    scene.fog.color.set(T.fog);
    renderer.toneMappingExposure = T.exposure;
    moon.visible = stars.visible = T.night;
    if (T.night) {
      // light comes from the moon; sky shader goes dark
      const md = new THREE.Vector3().setFromSphericalCoords(1, THREE.MathUtils.degToRad(50), THREE.MathUtils.degToRad(120));
      sunDir.copy(md);
    }
    // Environment map from the sky for realistic metal reflections
    const envScene = new THREE.Scene();
    const skyClone = new Sky();
    skyClone.scale.setScalar(1000);
    skyClone.material.uniforms = THREE.UniformsUtils.clone(u);
    if (skyClone.material.uniforms.showSunDisc) skyClone.material.uniforms.showSunDisc.value = 0;
    envScene.add(skyClone);
    if (T.night) envScene.background = new THREE.Color(0x0a1020);
    // fake ground in the env so metal reflects warm earth below the horizon
    const ground = new THREE.Mesh(new THREE.SphereGeometry(500, 32, 16, 0, Math.PI * 2, Math.PI / 2 + 0.02, Math.PI / 2), new THREE.MeshBasicMaterial({ color: T.night ? 0x050608 : 0x4a4036, side: THREE.BackSide }));
    envScene.add(ground);
    if (envRT) envRT.dispose();
    envRT = pmrem.fromScene(envScene, 0, 0.1, 2000);
    scene.environment = envRT.texture;
    scene.environmentIntensity = T.night ? 0.35 : 1.0;
  }

  return {
    sky, sun, hemi, sunDir, setTime,
    get night() { return current && current.night; },
    update(playerPos) {
      sky.position.copy(playerPos);
      stars.position.copy(playerPos);
      moon.position.copy(playerPos).addScaledVector(sunDir, 12000);
      // shadow frustum follows the player
      sun.position.copy(playerPos).addScaledVector(sunDir, 400);
      sun.target.position.copy(playerPos);
    },
  };
}
