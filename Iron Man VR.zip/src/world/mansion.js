import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { addBox, addRamp, setBasementZones } from './colliders.js';
import { buildSupercar, buildHotRod, buildCobra, buildHypercar } from './cars.js';
import { SUITS, buildSuitModel, UNLOCK_TEXT } from '../suits.js';
import { canvasTexture, noiseTexture } from '../util.js';
import { MANSION } from './layout.js';

const W = MANSION.workshopY;      // 51  workshop floor
const L1 = 60.2;                  // living room floor
const L1T = 65.4, L2 = 66.2;      // living ceiling / level-2 floor
const L2T = 70.2, L3 = 71.0;
const L3T = 74.4, ROOF = 75.2;

export function buildMansion(scene) {
  const group = new THREE.Group();
  group.name = 'mansion';
  scene.add(group);
  const interactables = [];

  // ---------------- materials
  const M = {
    white: new THREE.MeshStandardMaterial({ color: 0xf0eee8, roughness: 0.5 }),
    whiteEdge: new THREE.MeshStandardMaterial({ color: 0xe2e0da, roughness: 0.6 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xa8cddc, metalness: 0.1, roughness: 0.03, transparent: true, opacity: 0.2, depthWrite: false, side: THREE.DoubleSide, envMapIntensity: 2 }),
    concrete: new THREE.MeshStandardMaterial({ color: 0x8d8f91, roughness: 0.92, map: (() => { const t = noiseTexture(256, { base: 215, amp: 25, scale: 6 }); t.repeat.set(6, 2); return t; })() }),
    shopFloor: new THREE.MeshStandardMaterial({ color: 0x55585c, roughness: 0.22, metalness: 0.25 }),
    ceiling: new THREE.MeshStandardMaterial({ color: 0x1d1e21, roughness: 0.8 }),
    led: new THREE.MeshBasicMaterial({ color: new THREE.Color(0xeaf6ff).multiplyScalar(1.6), toneMapped: false }),
    blueLed: new THREE.MeshBasicMaterial({ color: new THREE.Color(0x56c8ff).multiplyScalar(2), toneMapped: false }),
    marble: new THREE.MeshStandardMaterial({ color: 0xdedad2, roughness: 0.25, metalness: 0.05 }),
    sofa: new THREE.MeshStandardMaterial({ color: 0xe6e0d4, roughness: 0.95 }),
    darkWood: new THREE.MeshStandardMaterial({ color: 0x3b2a1f, roughness: 0.55 }),
    black: new THREE.MeshPhysicalMaterial({ color: 0x050505, roughness: 0.12, clearcoat: 1 }),
    steel: new THREE.MeshStandardMaterial({ color: 0x9a9da2, metalness: 1, roughness: 0.3 }),
    darkSteel: new THREE.MeshStandardMaterial({ color: 0x2c2e31, metalness: 0.8, roughness: 0.45 }),
    rug: new THREE.MeshStandardMaterial({ color: 0x8a7d6c, roughness: 1 }),
    plant: new THREE.MeshStandardMaterial({ color: 0x2f5a2a, roughness: 0.8, flatShading: true }),
    pool: new THREE.MeshPhysicalMaterial({ color: 0x2ec4d6, roughness: 0.05, transmission: 0, transparent: true, opacity: 0.85 }),
    yellow: new THREE.MeshStandardMaterial({ color: 0xd7ab0f, roughness: 0.5 }),
  };
  M.marble.envMapIntensity = 0.6;
  M.white.envMapIntensity = 0.45;
  M.sofa.envMapIntensity = 0.5;
  M.shopFloor.envMapIntensity = 0.5;
  M.concrete.envMapIntensity = 0.3;
  M.ceiling.envMapIntensity = 0.2;

  const mesh = (geo, mat, x, y, z, { cast = true, receive = true, parent = group } = {}) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    m.castShadow = cast; m.receiveShadow = receive;
    parent.add(m);
    return m;
  };
  // axis-aligned box from min/max corners, optional collider
  const boxMM = (x0, y0, z0, x1, y1, z1, mat, { collide = true, cast = true, receive = true, parent = group, tag } = {}) => {
    const m = mesh(new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0), mat, (x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2, { cast, receive, parent });
    if (collide) addBox(x0, y0, z0, x1, y1, z1, tag);
    return m;
  };

  // ---------------- footprint shapes (plan view: x, z)
  const foot = (x0, x1, hw) => {
    const s = new THREE.Shape();
    s.moveTo(x1, -hw); s.lineTo(x1, hw); s.lineTo(x0, hw);
    s.absarc(x0, 0, hw, Math.PI / 2, Math.PI * 1.5, false);
    s.lineTo(x1, -hw);
    return s;
  };
  const slab = (shape, top, thick, mat) => {
    const geo = new THREE.ExtrudeGeometry(shape, { depth: thick, bevelEnabled: true, bevelThickness: 0.08, bevelSize: 0.08, bevelSegments: 2, curveSegments: 48 });
    geo.rotateX(Math.PI / 2);
    geo.translate(0, top, 0); // rotateX(+90°): shape-y -> world z, extrusion goes downward from `top`
    const m = mesh(geo, mat, 0, 0, 0);
    return m;
  };
  const slabCollider = (x0, x1, hw, top, thick) => {
    addBox(x0, top - thick, -hw, x1, top, hw);
    // semicircle approximated by stacked boxes
    for (let i = 0; i < 8; i++) {
      const a0 = (i / 8) * hw, a1 = ((i + 1) / 8) * hw;
      const ext = Math.sqrt(Math.max(0, hw * hw - a0 * a0));
      addBox(x0 - ext, top - thick, -a1, x0, top, -a0);
      addBox(x0 - ext, top - thick, a0, x0, top, a1);
    }
  };
  const railing = (shape, y, h = 1.1) => {
    const pts = shape.getPoints(48);
    const pos = [], idx = [];
    pts.forEach((p, i) => {
      pos.push(p.x, y, p.y, p.x, y + h, p.y);
      if (i > 0) { const a = (i - 1) * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    });
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setIndex(idx); g.computeVertexNormals();
    mesh(g, M.glass, 0, 0, 0, { cast: false, receive: false });
    // steel cap rail
    const cap = new THREE.BufferGeometry().setFromPoints(pts.map((p) => new THREE.Vector3(p.x, y + h, p.y)));
    group.add(new THREE.Line(cap, new THREE.LineBasicMaterial({ color: 0xcfd3d6 })));
  };
  const curvedWall = (x0, hw, yb, yt, mat, inset = 0.35, collide = true) => {
    const r = hw - inset;
    const g = new THREE.CylinderGeometry(r, r, yt - yb, 48, 1, true, Math.PI, Math.PI);
    mesh(g, mat, x0, (yb + yt) / 2, 0, { cast: false, receive: false });
    if (collide) {
      for (let i = 0; i <= 28; i++) {
        const a = Math.PI + (i / 28) * Math.PI;
        const px = x0 + r * Math.sin(a), pz = r * Math.cos(a);
        addBox(px - 1, yb, pz - 1, px + 1, yt, pz + 1, 'glass');
      }
    }
    // mullions
    for (let i = 0; i <= 12; i++) {
      const a = Math.PI + (i / 12) * Math.PI;
      mesh(new THREE.BoxGeometry(0.12, yt - yb, 0.12), M.steel, x0 + r * Math.sin(a), (yb + yt) / 2, r * Math.cos(a), { cast: false });
    }
  };

  // ================================================================ HOUSE (above ground)
  const F1 = foot(-52, 30, 28), F2 = foot(-40, 22, 24), F3 = foot(-28, 14, 16), F4 = foot(-29, 15, 17.2);
  slab(F1, L1, 1.6, M.marble); slabCollider(-52, 30, 28, L1, 1.6);
  slab(F1, L2, 0.8, M.white); slabCollider(-52, 30, 28, L2, 0.8);
  slab(F2, L3, 0.8, M.white); slabCollider(-40, 22, 24, L3, 0.8);
  slab(F4, ROOF, 0.8, M.white); slabCollider(-29, 15, 17.2, ROOF, 0.8);
  // level 1 walls
  curvedWall(-52, 28, L1, L1T, M.glass);
  for (const s of [-1, 1]) {
    boxMM(-52, L1, s > 0 ? 27.4 : -28, 30, L1 + 1.0, s > 0 ? 28 : -27.4, M.white);
    boxMM(-52, L1 + 1.0, s > 0 ? 27.6 : -27.8, 30, L1T - 0.6, s > 0 ? 27.8 : -27.6, M.glass, { cast: false, receive: false, collide: false });
    boxMM(-52, L1T - 0.6, s > 0 ? 27.4 : -28, 30, L1T, s > 0 ? 28 : -27.4, M.white);
    addBox(-52, L1, s > 0 ? 27.4 : -28, 30, L1T, s > 0 ? 28 : -27.4);
  }
  boxMM(29.4, L1, -28, 30, L1T, -2.2, M.white); boxMM(29.4, L1, 2.2, 30, L1T, 28, M.white); boxMM(29.4, L1 + 3, -2.2, 30, L1T, 2.2, M.white);
  // level 2 walls
  curvedWall(-40, 24, L2, L2T, M.glass, 0.6);
  for (const s of [-1, 1]) boxMM(-40, L2, s > 0 ? 23 : -23.6, 22, L2T, s > 0 ? 23.6 : -23, M.white);
  boxMM(21.4, L2, -23.6, 22, L2T, 23.6, M.white);
  // level 3
  curvedWall(-28, 16, L3, L3T, M.glass, 0.5);
  for (const s of [-1, 1]) boxMM(-28, L3, s > 0 ? 15 : -15.5, 14, L3T, s > 0 ? 15.5 : -15, M.white);
  boxMM(13.4, L3, -15.5, 14, L3T, 15.5, M.white);
  // terrace railings
  railing(F1, L2); railing(F2, L3); railing(F4, ROOF);
  // white sculpted fins under the cantilever
  for (const z of [-20, -8, 8, 20]) boxMM(-70, 52, z - 0.4, -46, L1 - 1.6, z + 0.4, M.whiteEdge, { collide: false });
  // support pillars down the cliff
  for (const z of [-16, 16]) mesh(new THREE.CylinderGeometry(0.9, 1.2, 40, 16), M.white, -60, L1 - 21.6, z);

  // pool deck (south lawn)
  boxMM(-48, 59.4, -48, -12, 59.95, -33, M.white, { collide: true });
  mesh(new THREE.BoxGeometry(32, 0.1, 12), M.pool, -30, 59.98, -40.5, { cast: false });
  // front entry steps / drive turnaround
  boxMM(30, 59.4, -6, 34, 60.2, 6, M.white);

  // ---------------- living room interior (L1)
  const living = new THREE.Group(); group.add(living);
  const sofa = (x, z, ry, len = 5) => {
    const g = new THREE.Group();
    const seat = new THREE.Mesh(new RoundedBoxGeometry(len, 0.45, 1.1, 3, 0.1), M.sofa);
    seat.position.y = 0.3; const back = new THREE.Mesh(new RoundedBoxGeometry(len, 0.6, 0.3, 3, 0.1), M.sofa);
    back.position.set(0, 0.7, -0.45);
    seat.castShadow = back.castShadow = true;
    g.add(seat, back);
    g.position.set(x, L1, z); g.rotation.y = ry;
    living.add(g);
    addBox(x - len / 2, L1, z - len / 2, x + len / 2, L1 + 0.5, z + len / 2);
  };
  sofa(-56, -5, Math.PI / 2 + 0.25); sofa(-56, 5, Math.PI / 2 - 0.25); sofa(-48, 0, Math.PI / 2, 4);
  mesh(new THREE.CylinderGeometry(4.5, 4.5, 0.02, 40), M.rug, -55, L1 + 0.01, 0, { cast: false });
  mesh(new RoundedBoxGeometry(2.2, 0.35, 1.2, 2, 0.05), M.darkWood, -54, L1 + 0.25, 0);
  // grand piano
  const piano = new THREE.Group();
  const pb = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.35, 32, 1, false, 0, Math.PI), M.black); pb.position.y = 0.85; pb.scale.set(1, 1, 1.6);
  const lid = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.03, 1.9), M.black); lid.position.set(0.3, 1.45, 0.6); lid.rotation.z = 0.5;
  const keys = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.05, 0.25), new THREE.MeshStandardMaterial({ color: 0xffffff })); keys.position.set(0, 0.95, -0.1);
  piano.add(pb, lid, keys);
  for (const [lx, lz] of [[-0.8, 0.1], [0.8, 0.1], [0, 1.6]]) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.7), M.black); l.position.set(lx, 0.35, lz); piano.add(l); }
  piano.position.set(-38, L1, 20); piano.rotation.y = -0.6; piano.traverse((o) => (o.castShadow = true)); living.add(piano);
  addBox(-40, L1, 18, -36, L1 + 1.2, 23);
  // bar
  boxMM(4, L1, -24, 16, L1 + 1.1, -22.5, M.darkWood);
  boxMM(4, L1 + 1.1, -24.2, 16, L1 + 1.18, -22.3, M.marble, { collide: false });
  for (let i = 0; i < 4; i++) mesh(new THREE.CylinderGeometry(0.22, 0.18, 0.8, 12), M.steel, 6 + i * 3, L1 + 0.4, -21.4);
  // media wall
  boxMM(28.2, L1 + 0.8, -6, 28.6, L1 + 4.2, 6, M.black, { collide: false });
  const tvTex = canvasTexture(512, 256, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, w, h); gr.addColorStop(0, '#0b1f33'); gr.addColorStop(1, '#03070c');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.fillStyle = '#c9a24a'; g.font = 'bold 54px Arial'; g.textAlign = 'center'; g.fillText('STARK INDUSTRIES', w / 2, h / 2 + 18);
  });
  const tv = mesh(new THREE.PlaneGeometry(11.4, 3.2), new THREE.MeshBasicMaterial({ map: tvTex, toneMapped: false }), 28.15, L1 + 2.5, 0, { cast: false });
  tv.rotation.y = -Math.PI / 2;
  // plants
  for (const [x, z] of [[-30, 25], [-30, -25], [20, 25], [24, -12]]) {
    mesh(new THREE.CylinderGeometry(0.45, 0.35, 0.8, 16), M.white, x, L1 + 0.4, z);
    mesh(new THREE.IcosahedronGeometry(0.9, 1), M.plant, x, L1 + 1.6, z);
  }
  // warm wood floor over the slab
  {
    const wood = new THREE.MeshStandardMaterial({ color: 0x8a6a48, roughness: 0.42, map: (() => { const t = noiseTexture(256, { base: 200, amp: 35, scale: 40 }); t.repeat.set(0.05, 0.4); return t; })() });
    wood.envMapIntensity = 0.5;
    const fg = new THREE.ShapeGeometry(F1, 48); fg.rotateX(Math.PI / 2); fg.translate(0, L1 + 0.095, 0); // slab bevel pokes 8 cm above L1
    const uv = fg.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, fg.attributes.position.getX(i), fg.attributes.position.getZ(i));
    const floor = mesh(fg, wood, 0, 0, 0, { cast: false, parent: living });
    floor.material.side = THREE.DoubleSide;
  }
  // dining table + chairs
  boxMM(-14, L1 + 0.72, 4, -6, L1 + 0.8, 8, M.darkWood, { parent: living });
  for (const [lx, lz] of [[-13.6, 4.4], [-6.4, 4.4], [-13.6, 7.6], [-6.4, 7.6]]) mesh(new THREE.BoxGeometry(0.12, 0.72, 0.12), M.steel, lx, L1 + 0.36, lz, { parent: living });
  for (let i = 0; i < 4; i++) for (const zz of [3.2, 8.8]) mesh(new RoundedBoxGeometry(0.5, 0.9, 0.5, 2, 0.06), M.sofa, -12.8 + i * 2.2, L1 + 0.45, zz, { parent: living });
  addBox(-14, L1, 3, -6, L1 + 0.8, 9);
  // TV lounge facing the media wall
  sofa(18, -5, -Math.PI / 2, 5); sofa(18, 5, -Math.PI / 2, 5);
  mesh(new THREE.CylinderGeometry(3.6, 3.6, 0.02, 40), M.rug, 22, L1 + 0.015, 0, { cast: false, parent: living });
  mesh(new RoundedBoxGeometry(1.4, 0.35, 2.4, 2, 0.05), M.darkWood, 22.5, L1 + 0.25, 0, { parent: living });
  // fireplace on the north wall
  boxMM(-8, L1, 26.6, 2, L1 + 1.2, 27.4, M.black, { parent: living });
  mesh(new THREE.BoxGeometry(8, 0.25, 0.3), new THREE.MeshBasicMaterial({ color: new THREE.Color(0xff8a3a).multiplyScalar(2), toneMapped: false }), -3, L1 + 0.45, 26.5, { cast: false, parent: living });
  // ceiling lights
  for (let x = -40; x <= 20; x += 10) mesh(new THREE.BoxGeometry(4, 0.05, 0.3), M.led, x, L1T - 0.83, 0, { cast: false });

  // master suite (L3) — bed
  boxMM(-20, L3, -3, -14, L3 + 0.6, 3, M.sofa);
  boxMM(-14, L3, -3.2, -13.6, L3 + 1.6, 3.2, M.darkWood);

  // ================================================================ BASEMENT WORKSHOP
  const shop = new THREE.Group(); shop.name = 'workshop'; group.add(shop);
  const SX0 = -30, SX1 = 20, SZ = 18, SH = 58.6;
  boxMM(SX0 - 0.6, W - 1, -SZ - 0.6, SX1 + 0.6, W, SZ + 0.6, M.shopFloor, { parent: shop });
  boxMM(SX0 - 0.6, SH - 0.3, -SZ - 0.6, SX1 + 0.6, SH - 0.1, SZ + 0.6, M.ceiling, { parent: shop, cast: true });
  // N/S walls
  boxMM(SX0 - 0.6, W, SZ, SX1 + 0.6, SH, SZ + 0.6, M.concrete, { parent: shop });
  boxMM(SX0 - 0.6, W, -SZ - 0.6, SX1 + 0.6, SH, -SZ, M.concrete, { parent: shop });
  // west wall with launch tunnel opening (z -6..6, up to 57)
  boxMM(SX0 - 0.6, W, -SZ, SX0, SH, -6, M.concrete, { parent: shop });
  boxMM(SX0 - 0.6, W, 6, SX0, SH, SZ, M.concrete, { parent: shop });
  boxMM(SX0 - 0.6, 57, -6, SX0, SH, 6, M.concrete, { parent: shop });
  // east wall with garage door opening (z -5.5..5.5, up to 56)
  boxMM(SX1, W, -SZ, SX1 + 0.6, SH, -5.5, M.concrete, { parent: shop });
  boxMM(SX1, W, 5.5, SX1 + 0.6, SH, SZ, M.concrete, { parent: shop });
  boxMM(SX1, 56, -5.5, SX1 + 0.6, SH, 5.5, M.concrete, { parent: shop });
  // ceiling LED strips
  for (let x = -26; x <= 16; x += 6) mesh(new THREE.BoxGeometry(0.25, 0.06, 30), M.led, x, SH - 0.33, 0, { parent: shop, cast: false });
  // floor guide lines
  for (const z of [-7, 7]) mesh(new THREE.BoxGeometry(48, 0.01, 0.12), M.blueLed, -5, W + 0.006, z, { parent: shop, cast: false, receive: false });
  // workshop lights (point lights, no shadows)
  const shopLights = [];
  for (const [x, z] of [[-20, 0], [-4, -8], [-4, 9], [12, 0]]) {
    const l = new THREE.PointLight(0xe6f2ff, 60, 32, 1.6);
    l.position.set(x, SH - 1.2, z);
    shop.add(l); shopLights.push(l);
  }

  // launch tunnel to the cliff face (west)
  const TX0 = -76;
  boxMM(TX0, W - 1, -6.6, SX0, W, 6.6, M.shopFloor, { parent: shop });
  boxMM(TX0, W, -6.6, SX0, 57, -6, M.concrete, { parent: shop });
  boxMM(TX0, W, 6, SX0, 57, 6.6, M.concrete, { parent: shop });
  boxMM(TX0, 57, -6.6, SX0, 58.6, 6.6, M.ceiling, { parent: shop });
  for (let x = TX0 + 4; x < SX0; x += 6) {
    for (const z of [-5.9, 5.9]) mesh(new THREE.BoxGeometry(2.5, 0.1, 0.1), M.blueLed, x, 56.2, z, { parent: shop, cast: false });
    mesh(new THREE.BoxGeometry(0.15, 0.02, 10), M.blueLed, x, W + 0.01, 0, { parent: shop, cast: false });
  }
  // garage ramp (east), rises to the driveway
  addRamp(SX1, 85, -6, 6, W, 60.0);
  {
    const len = Math.hypot(85 - SX1, 60 - W);
    const ramp = mesh(new THREE.BoxGeometry(len, 0.4, 12), M.concrete, (SX1 + 85) / 2, (W + 60) / 2 - 0.2, 0, { parent: shop });
    ramp.rotation.z = Math.atan2(60 - W, 85 - SX1);
  }
  for (const s of [-1, 1]) {
    boxMM(SX1, W - 1, s > 0 ? 6 : -6.6, 86, 60.6, s > 0 ? 6.6 : -6, M.concrete, { parent: shop });
  }
  boxMM(SX1, 58.6, -6.6, 32, 60.2, 6.6, M.ceiling, { parent: shop }); // ramp roof under the house
  for (let x = SX1 + 3; x < 32; x += 3) mesh(new THREE.BoxGeometry(0.2, 0.05, 10), M.led, x, 58.55, 0, { parent: shop, cast: false });

  setBasementZones([
    [SX0 - 1, W - 1, -SZ - 1, SX1 + 1, SH + 0.5, SZ + 1],
    [TX0 - 4, W - 1, -7, SX0 + 1, 58.6, 7],
    [SX1 - 1, W - 1, -7, 87, 61.5, 7],
  ]);

  // ---- glass office (SW corner) with desk & monitors
  boxMM(-30, W, -8.2, -20, W + 3.2, -8, M.glass, { parent: shop, cast: false, receive: false });
  boxMM(-20.2, W, -18, -20, W + 3.2, -10.5, M.glass, { parent: shop, cast: false, receive: false });
  boxMM(-28, W + 0.75, -16, -23, W + 0.85, -14, M.darkSteel, { parent: shop });
  const screenTex = (title) => canvasTexture(512, 320, (g, w, h) => {
    g.fillStyle = 'rgba(4,20,36,0.95)'; g.fillRect(0, 0, w, h);
    g.strokeStyle = '#4fc3ff'; g.lineWidth = 2; g.strokeRect(6, 6, w - 12, h - 12);
    g.fillStyle = '#7fd8ff'; g.font = 'bold 26px Arial'; g.fillText(title, 20, 40);
    g.strokeStyle = 'rgba(80,190,255,0.7)';
    for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(20, 70 + i * 38); for (let x = 20; x < w - 20; x += 12) g.lineTo(x, 70 + i * 38 + Math.sin(x * 0.05 + i) * 10 * Math.random()); g.stroke(); }
    g.beginPath(); g.arc(w - 90, h - 90, 60, 0, Math.PI * 2); g.stroke();
    g.beginPath(); g.arc(w - 90, h - 90, 38, 0, Math.PI * 1.4); g.stroke();
  });
  const screens = [['J.A.R.V.I.S. // SYSTEMS', -29.6, 54.5, -14.5, Math.PI / 2], ['ARC REACTOR OUTPUT', -29.6, 54.5, 12, Math.PI / 2], ['MARK SERIES TELEMETRY', -29.6, 54.5, -9.5, Math.PI / 2], ['FLIGHT STABILIZERS', -25.5, W + 1.6, -15.6, 0]];
  for (const [t, x, y, z, ry] of screens) {
    const s = mesh(new THREE.PlaneGeometry(t === 'FLIGHT STABILIZERS' ? 1.6 : 4.5, t === 'FLIGHT STABILIZERS' ? 1 : 2.8), new THREE.MeshBasicMaterial({ map: screenTex(t), toneMapped: false, transparent: true, opacity: 0.92 }), x, y, z, { parent: shop, cast: false });
    s.rotation.y = ry;
  }

  // ---- workbenches with tools & parts
  const bench = (x, z, ry) => {
    const b = new THREE.Group();
    const top = new THREE.Mesh(new THREE.BoxGeometry(5, 0.08, 1.3), M.darkSteel); top.position.y = 0.95;
    b.add(top);
    for (const [lx, lz] of [[-2.3, -0.55], [2.3, -0.55], [-2.3, 0.55], [2.3, 0.55]]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.95, 0.08), M.steel); l.position.set(lx, 0.47, lz); b.add(l); }
    // parts: gauntlet prototype, helmet, tools
    const hel = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 12), new THREE.MeshPhysicalMaterial({ color: 0x9b0f12, metalness: 0.9, roughness: 0.3, clearcoat: 1 })); hel.position.set(-1.4, 1.14, 0); hel.scale.set(0.9, 1.1, 1);
    const glove = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.05, 0.4, 12), M.steel); glove.rotation.z = Math.PI / 2; glove.position.set(0.2, 1.05, 0.1);
    const reactor = new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.02, 8, 24), M.blueLed); reactor.rotation.x = Math.PI / 2; reactor.position.set(1.3, 1.0, -0.2);
    b.add(hel, glove, reactor);
    for (let i = 0; i < 8; i++) { const t = new THREE.Mesh(new THREE.BoxGeometry(0.2 + Math.random() * 0.3, 0.03, 0.04), M.steel); t.position.set(-2 + Math.random() * 4, 1.0, 0.4 + Math.random() * 0.2); t.rotation.y = Math.random() * 3; b.add(t); }
    b.traverse((o) => { o.castShadow = true; o.receiveShadow = true; });
    b.position.set(x, W, z); b.rotation.y = ry;
    shop.add(b);
    addBox(x - 2.6, W, z - 2.6, x + 2.6, W + 1, z + 2.6);
  };
  bench(-17, 1.5, 0.08); bench(-24, 9, Math.PI / 2);

  // ---- holotable (opens the J.A.R.V.I.S. mission board)
  const holo = new THREE.Group();
  holo.position.set(-6, W, 4);
  const tbl = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.1, 0.95, 40), M.darkSteel); tbl.position.y = 0.47; tbl.castShadow = true;
  const tblTop = new THREE.Mesh(new THREE.CylinderGeometry(1.42, 1.42, 0.04, 40), new THREE.MeshBasicMaterial({ color: new THREE.Color(0x2fa8ff).multiplyScalar(1.4), toneMapped: false, transparent: true, opacity: 0.8 })); tblTop.position.y = 0.97;
  holo.add(tbl, tblTop);
  const holoBeam = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 2.3, 40, 1, true), new THREE.MeshBasicMaterial({ color: 0x3fb4ff, transparent: true, opacity: 0.06, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
  holoBeam.position.y = 2.1; holo.add(holoBeam);
  const holoModel = new THREE.Group(); holoModel.position.y = 1.05; holo.add(holoModel);
  shop.add(holo);
  addBox(-7.4, W, 2.6, -4.6, W + 0.97, 5.4);
  const holoHit = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 3.2, 12), new THREE.MeshBasicMaterial({ visible: false }));
  holoHit.position.set(-6, W + 1.6, 4); shop.add(holoHit);
  interactables.push({ object: holoHit, type: 'holotable', label: 'J.A.R.V.I.S. Mission Board' });
  const holoMat = new THREE.MeshBasicMaterial({ color: 0x1f8fd0, wireframe: true, transparent: true, opacity: 0.32, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
  function setHologramSuit(suit) {
    holoModel.clear();
    const m = buildSuitModel(suit, { merged: true, shadows: false });
    m.traverse((o) => { if (o.isMesh) o.material = holoMat; });
    m.scale.setScalar(0.62 / (suit.scale || 1));
    holoModel.add(m);
  }

  // ---- Dum-E (robot arm)
  const dume = new THREE.Group();
  {
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 0.4, 20), M.darkSteel); base.position.y = 0.2;
    const j1 = new THREE.Group(); j1.position.y = 0.4;
    const a1 = new THREE.Mesh(new THREE.BoxGeometry(0.22, 1.3, 0.22), M.steel); a1.position.y = 0.65;
    const j2 = new THREE.Group(); j2.position.y = 1.3;
    const a2 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 1.0, 0.18), M.yellow); a2.position.y = 0.5;
    const claw = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.3, 8), M.darkSteel); claw.position.y = 1.1; claw.rotation.x = Math.PI;
    j2.add(a2, claw); j2.rotation.z = 0.9;
    j1.add(a1, j2); j1.rotation.z = -0.3;
    dume.add(base, j1);
    dume.userData = { j1, j2 };
    dume.traverse((o) => (o.castShadow = true));
  }
  dume.position.set(-20, W, 6); shop.add(dume);
  addBox(-20.6, W, 5.4, -19.4, W + 2, 6.6);

  // ---- suit-up gantry
  const gantry = new THREE.Group(); gantry.position.set(8, W, 9);
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.7, 0.12, 48), M.darkSteel); plate.position.y = 0.06; plate.receiveShadow = true;
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.45, 0.04, 8, 64), M.blueLed); ring.rotation.x = Math.PI / 2; ring.position.y = 0.13;
  gantry.add(plate, ring);
  for (const a of [0.6, Math.PI - 0.6, Math.PI + 1.3, -1.3]) {
    const arm = new THREE.Group();
    const p1 = new THREE.Mesh(new THREE.BoxGeometry(0.25, 3.2, 0.25), M.darkSteel); p1.position.y = 1.6;
    const p2 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 1.2, 0.18), M.steel); p2.position.set(-0.4, 3.0, 0); p2.rotation.z = 1.0;
    arm.add(p1, p2);
    arm.position.set(Math.cos(a) * 2.1, 0, Math.sin(a) * 2.1); arm.rotation.y = -a;
    arm.traverse((o) => (o.castShadow = true));
    gantry.add(arm);
  }
  shop.add(gantry);

  // ---- cars
  const hotrod = buildHotRod(); hotrod.position.set(-24, W, -13); hotrod.rotation.y = -Math.PI / 2 + 0.3; shop.add(hotrod);
  const cobra = buildCobra(); cobra.position.set(-14.5, W, -13); cobra.rotation.y = -Math.PI / 2 + 0.15; shop.add(cobra);
  const hyper = buildHypercar(); hyper.position.set(-5, W, -13); hyper.rotation.y = -Math.PI / 2; shop.add(hyper);
  for (const [x, z] of [[-24, -13], [-14.5, -13], [-5, -13]]) addBox(x - 1.1, W, z - 2.3, x + 1.1, W + 1.2, z + 2.3);
  for (const c of [hotrod, cobra, hyper]) c.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  const carSpot = { x: 8, y: W, z: -1, yaw: 0 };
  const mkPlaque = (t, x, z) => {
    const p = mesh(new THREE.PlaneGeometry(2.2, 0.45), new THREE.MeshBasicMaterial({ map: canvasTexture(512, 104, (g, w, h) => { g.fillStyle = '#0a0c10'; g.fillRect(0, 0, w, h); g.fillStyle = '#d8dde3'; g.font = 'bold 40px Arial'; g.textAlign = 'center'; g.fillText(t, w / 2, 68); }) }), x, W + 0.4, z, { parent: shop, cast: false });
    p.rotation.x = -0.6;
  };
  mkPlaque("'32 FLATHEAD ROADSTER", -24, -9.6); mkPlaque('CLASSIC ROADSTER', -14.5, -9.6); mkPlaque('WHITE HYPERCAR', -5, -9.6);

  // ---- elevator pads
  const pads = [];
  const padTex = (t) => canvasTexture(256, 64, (g, w, h) => { g.fillStyle = '#7fd8ff'; g.font = 'bold 30px Arial'; g.textAlign = 'center'; g.fillText(t, w / 2, 42); });
  const addPad = (x, y, z, to, label) => {
    const p = new THREE.Group();
    const disk = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 0.05, 32), new THREE.MeshBasicMaterial({ color: new THREE.Color(0x2fa8ff).multiplyScalar(1.3), toneMapped: false, transparent: true, opacity: 0.55 }));
    disk.position.y = 0.03;
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 2.4, 32, 1, true), new THREE.MeshBasicMaterial({ color: 0x3fb4ff, transparent: true, opacity: 0.08, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    beam.position.y = 1.2;
    const lbl = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.4), new THREE.MeshBasicMaterial({ map: padTex('▲ ' + label), transparent: true, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    lbl.position.y = 2.6;
    p.add(disk, beam, lbl);
    p.position.set(x, y, z);
    group.add(p);
    pads.push({ group: p, label: lbl, pos: new THREE.Vector3(x, y, z), to, name: label, cooldown: 0 });
  };
  addPad(15.5, W, 13, { x: 24, y: L1, z: 18 }, 'LIVING ROOM');
  addPad(24, L1, 21.5, { x: 15.5, y: W, z: 9.5 }, 'WORKSHOP');
  addPad(24, L1, -19, { x: 6, y: ROOF, z: 0 }, 'ROOF DECK');
  addPad(2, ROOF, 0, { x: 22, y: L1, z: -15.5 }, 'LIVING ROOM');

  // ================================================================ HALL OF ARMOR
  const pods = [];
  const podBase = new THREE.CylinderGeometry(0.75, 0.85, 0.25, 32);
  const podRing = new THREE.TorusGeometry(0.72, 0.025, 8, 48);
  const podBack = new THREE.BoxGeometry(2.2, 3.6, 0.2);
  const podGlass = new THREE.BoxGeometry(2.0, 3.3, 0.04);
  const podGlassMat = M.glass.clone(); podGlassMat.opacity = 0.07; podGlassMat.envMapIntensity = 0.8;
  SUITS.forEach((suit, i) => {
    const x = -27 + i * 3.0, z = 16.3;
    const pod = new THREE.Group(); pod.position.set(x, W, z);
    const base = new THREE.Mesh(podBase, M.darkSteel); base.position.y = 0.125; base.receiveShadow = true;
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x4fc3ff, toneMapped: false });
    const ringM = new THREE.Mesh(podRing, ringMat); ringM.rotation.x = Math.PI / 2; ringM.position.y = 0.26;
    const back = new THREE.Mesh(podBack, M.darkSteel); back.position.set(0, 1.8, 1.25 - 0.1);
    const strip = new THREE.Mesh(new THREE.BoxGeometry(0.05, 3.2, 0.02), ringMat);
    const s1 = strip.clone(); s1.position.set(-0.95, 1.8, 1.03); const s2 = strip.clone(); s2.position.set(0.95, 1.8, 1.03);
    const glass = new THREE.Mesh(podGlass, podGlassMat); glass.position.set(0, 1.8, -1.0);
    const model = buildSuitModel(suit, { merged: true });
    const sc = suit.scale || 1;
    if (sc > 1.2) model.scale.setScalar(1.55 / sc * 1.05); // Hulkbuster gets shrunk a bit to fit its pod
    model.position.y = 0.26; model.rotation.y = Math.PI;
    const lblCanvas = document.createElement('canvas'); lblCanvas.width = 512; lblCanvas.height = 160;
    const lblTex = new THREE.CanvasTexture(lblCanvas); lblTex.colorSpace = THREE.SRGBColorSpace;
    const lbl = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.56), new THREE.MeshBasicMaterial({ map: lblTex, transparent: true, toneMapped: false }));
    lbl.position.set(0, 0.62, -0.95); lbl.rotation.set(0.5, Math.PI, 0);
    pod.add(base, ringM, back, s1, s2, glass, model, lbl);
    pod.rotation.y = 0;
    // pods face -Z (into the room): the label & suit are rotated; the group stays axis-aligned
    shop.add(pod);
    addBox(x - 1.1, W, z - 0.9, x + 1.1, W + 3.7, z + 1.4);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(2.4, 3.6, 1.6), new THREE.MeshBasicMaterial({ visible: false }));
    hit.position.set(0, 1.8, 0); pod.add(hit);
    const entry = { suit, pod, model, ringMat, lblCanvas, lblTex, hit, unlocked: true };
    pods.push(entry);
    interactables.push({ object: hit, type: 'pod', suit, label: suit.name });
  });
  const hallSign = mesh(new THREE.PlaneGeometry(14, 1.2), new THREE.MeshBasicMaterial({ map: canvasTexture(1024, 88, (g, w, h) => { g.fillStyle = '#d6e7f5'; g.font = '300 60px Arial'; g.textAlign = 'center'; g.fillText('H A L L   O F   A R M O R', w / 2, 64); }), transparent: true, toneMapped: false }), -4.5, 57.3, 17.9, { parent: shop, cast: false });
  hallSign.rotation.y = Math.PI;

  function refreshPods(isUnlocked, selectedId) {
    for (const p of pods) {
      p.unlocked = isUnlocked(p.suit.id);
      const sel = p.suit.id === selectedId;
      p.ringMat.color.set(!p.unlocked ? 0xff3030 : sel ? 0xffd34a : 0x4fc3ff);
      p.model.visible = true;
      p.model.traverse((o) => { if (o.isMesh) o.visible = true; });
      const g = p.lblCanvas.getContext('2d');
      g.clearRect(0, 0, 512, 160);
      g.fillStyle = 'rgba(5,10,16,0.88)'; g.fillRect(0, 0, 512, 160);
      g.fillStyle = sel ? '#ffd34a' : p.unlocked ? '#bfe6ff' : '#ff6060'; g.fillRect(0, 0, 512, 6);
      g.textAlign = 'center';
      g.fillStyle = '#ffffff'; g.font = 'bold 44px Arial'; g.fillText(p.suit.name.toUpperCase(), 256, 56);
      g.fillStyle = '#9fc3dc'; g.font = '28px Arial'; g.fillText(p.suit.tag, 256, 96);
      g.font = 'bold 24px Arial';
      g.fillStyle = p.unlocked ? (sel ? '#ffd34a' : '#4fc3ff') : '#ff7070';
      g.fillText(p.unlocked ? (sel ? '● EQUIPPED' : 'POINT + TRIGGER TO SUIT UP') : '🔒 ' + (UNLOCK_TEXT[p.suit.unlock] || 'Locked'), 256, 138);
      p.lblTex.needsUpdate = true;
    }
  }

  // drivable car hit target is created by car.js; keep spot here
  return {
    group, interactables, pods, pads, refreshPods, setHologramSuit, shopLights, carSpot,
    spawn: { x: 0, y: W, z: 2, yaw: Math.PI },
    roof: { x: 0, y: ROOF, z: 0 },
    launchPoint: new THREE.Vector3(-40, 54, 0),
    gantryPos: new THREE.Vector3(8, W, 9),
    update(dt, t, playerPos) {
      holoModel.rotation.y += dt * 0.5;
      holoBeam.material.opacity = 0.05 + Math.sin(t * 3) * 0.015;
      dume.userData.j1.rotation.z = -0.3 + Math.sin(t * 0.7) * 0.2;
      dume.userData.j2.rotation.z = 0.9 + Math.sin(t * 1.1) * 0.25;
      dume.rotation.y = Math.sin(t * 0.3) * 0.8;
      ring.material.color.setHSL(0.56, 1, 0.55 + Math.sin(t * 2) * 0.1);
      for (const p of pads) p.label.lookAt(playerPos.x, p.label.getWorldPosition(_tmp).y, playerPos.z);
      // lights only matter when near the workshop
      const near = Math.abs(playerPos.x) < 120 && Math.abs(playerPos.z) < 80 && playerPos.y < 80;
      for (const l of shopLights) l.intensity = near ? 60 : 0;
    },
  };
}
const _tmp = new THREE.Vector3();
