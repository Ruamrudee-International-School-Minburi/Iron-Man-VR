// World layout — every module agrees on where things are. Units = meters. Ocean is to the west (-X).
export const HALF = 12000; // world is 24 km x 24 km

export const MANSION = { x: 0, z: 0, floorY: 60, workshopY: 51, padY: 59.6 };
export const CITY = { x: 4200, z: 600, half: 1600, y: 30 };
export const TOWER = { x: 4200, z: 600 };             // Stark Tower, downtown
export const EXPO = { x: 5150, z: 1650, r: 330 };     // Stark Expo park (inside the city)
export const HQ = { x: 2300, z: 2700, y: 34, r: 360 }; // Stark Industries HQ + big arc reactor
export const GULMIRA = { x: 2600, z: -8600, y: 140, r: 950 };

// Coastal road from the mansion driveway to the city
export const ROAD_PTS = [
  [85, 0], [220, 30], [500, 160], [900, 260], [1350, 240], [1800, 380], [2250, 520], [2620, 600],
];

export function coastX(z) {
  return -70 + 260 * Math.sin(z / 1300) + 70 * Math.sin(z / 430);
}
