import * as THREE from 'three';
import { heightAt } from './terrain.js';
import { clamp } from '../util.js';

// Static world collision: axis-aligned boxes in a spatial hash + sloped ramps + the terrain heightfield.
const CELL = 80;
const boxes = [];
const grid = new Map();
const ramps = [];
const key = (cx, cz) => cx * 73856093 ^ cz * 19349663;

export function addBox(minX, minY, minZ, maxX, maxY, maxZ, tag = 'static') {
  const b = { min: new THREE.Vector3(minX, minY, minZ), max: new THREE.Vector3(maxX, maxY, maxZ), tag };
  boxes.push(b);
  for (let cx = Math.floor(minX / CELL); cx <= Math.floor(maxX / CELL); cx++)
    for (let cz = Math.floor(minZ / CELL); cz <= Math.floor(maxZ / CELL); cz++) {
      const k = key(cx, cz);
      if (!grid.has(k)) grid.set(k, []);
      grid.get(k).push(b);
    }
  return b;
}
export function addBoxFromObject(obj, tag) {
  const bb = new THREE.Box3().setFromObject(obj);
  return addBox(bb.min.x, bb.min.y, bb.min.z, bb.max.x, bb.max.y, bb.max.z, tag);
}
// A ramp rising along +X from (x0,y0) to (x1,y1) over z in [z0,z1]
export function addRamp(x0, x1, z0, z1, y0, y1) { ramps.push({ x0, x1, z0, z1, y0, y1 }); }

const _seen = new Set();
function near(minX, minZ, maxX, maxZ, out) {
  out.length = 0; _seen.clear();
  for (let cx = Math.floor(minX / CELL); cx <= Math.floor(maxX / CELL); cx++)
    for (let cz = Math.floor(minZ / CELL); cz <= Math.floor(maxZ / CELL); cz++) {
      const arr = grid.get(key(cx, cz));
      if (!arr) continue;
      for (const b of arr) if (!_seen.has(b)) { _seen.add(b); out.push(b); }
    }
  return out;
}
const _list = [];

// Highest walkable surface under (x,z) that is at or below y + step.
export function groundAt(x, z, y = 1e9, step = 0.7) {
  let g = heightAt(x, z);
  if (g > y + step && insideBasement(x, y + 0.5, z)) {
    // below the terrain surface inside the carved-out basement — boxes/ramps give the floor there
    g = -1e9;
  }
  for (const b of near(x, z, x, z, _list)) {
    if (x >= b.min.x && x <= b.max.x && z >= b.min.z && z <= b.max.z && b.max.y <= y + step && b.max.y > g) g = b.max.y;
  }
  for (const r of ramps) {
    if (x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1) {
      const ry = r.y0 + (r.y1 - r.y0) * clamp((x - r.x0) / (r.x1 - r.x0), 0, 1);
      if (ry <= y + step && ry > g) g = ry;
    }
  }
  if (g === -1e9) g = heightAt(x, z);
  return g;
}

// Push a sphere out of all boxes. Returns the collision normal (or null).
const _n = new THREE.Vector3();
export function resolveSphere(pos, r) {
  let hit = null;
  for (const b of near(pos.x - r, pos.z - r, pos.x + r, pos.z + r, _list)) {
    const cx = clamp(pos.x, b.min.x, b.max.x), cy = clamp(pos.y, b.min.y, b.max.y), cz = clamp(pos.z, b.min.z, b.max.z);
    let dx = pos.x - cx, dy = pos.y - cy, dz = pos.z - cz;
    const d2 = dx * dx + dy * dy + dz * dz;
    if (d2 >= r * r) continue;
    if (d2 > 1e-8) {
      const d = Math.sqrt(d2);
      _n.set(dx / d, dy / d, dz / d);
      pos.addScaledVector(_n, r - d);
    } else {
      // center inside box — push out along the shallowest axis
      const pen = [pos.x - b.min.x, b.max.x - pos.x, pos.y - b.min.y, b.max.y - pos.y, pos.z - b.min.z, b.max.z - pos.z];
      let m = 0; for (let i = 1; i < 6; i++) if (pen[i] < pen[m]) m = i;
      _n.set(0, 0, 0);
      const axis = 'xyz'[m >> 1], sgn = m & 1 ? 1 : -1;
      _n[axis] = sgn;
      pos[axis] += sgn * (pen[m] + r);
    }
    hit = (hit || new THREE.Vector3()).add(_n);
  }
  return hit ? hit.normalize() : null;
}

// Segment test against boxes + terrain. Returns {point, dist} or null.
export function segmentHit(a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
  const len = Math.hypot(dx, dy, dz);
  let best = null;
  for (const bx of near(Math.min(a.x, b.x), Math.min(a.z, b.z), Math.max(a.x, b.x), Math.max(a.z, b.z), _list)) {
    let t0 = 0, t1 = 1, ok = true;
    for (const ax of ['x', 'y', 'z']) {
      const d = ax === 'x' ? dx : ax === 'y' ? dy : dz;
      if (Math.abs(d) < 1e-9) { if (a[ax] < bx.min[ax] || a[ax] > bx.max[ax]) { ok = false; break; } continue; }
      let ta = (bx.min[ax] - a[ax]) / d, tb = (bx.max[ax] - a[ax]) / d;
      if (ta > tb) [ta, tb] = [tb, ta];
      t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
      if (t0 > t1) { ok = false; break; }
    }
    if (ok && (!best || t0 < best.t)) best = { t: t0 };
  }
  // terrain: sample along segment
  const steps = Math.max(1, Math.ceil(len / 6));
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    if (best && t > best.t) break;
    const x = a.x + dx * t, y = a.y + dy * t, z = a.z + dz * t;
    if (y < heightAt(x, z) && !insideBasement(x, y, z)) { best = { t: (i - 0.5) / steps }; break; }
  }
  if (!best) return null;
  return { point: new THREE.Vector3(a.x + dx * best.t, a.y + dy * best.t, a.z + dz * best.t), dist: len * best.t };
}

// The workshop & tunnels are carved under the terrain surface.
let basementZones = [];
export function setBasementZones(z) { basementZones = z; }
export function insideBasement(x, y, z) {
  for (const b of basementZones) if (x > b[0] && x < b[3] && y > b[1] && y < b[4] && z > b[2] && z < b[5]) return true;
  return false;
}
