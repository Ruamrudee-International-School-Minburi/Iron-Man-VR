import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { fbm, ridged, noise2, smoothstep, lerp, clamp, noiseTexture, normalMapTexture, mulberry32 } from '../util.js';
import { HALF, MANSION, CITY, HQ, GULMIRA, ROAD_PTS, coastX } from './layout.js';

// ---------------------------------------------------------------- height field
function rectDist(x, z, x0, x1, z0, z1) {
  return Math.max(x0 - x, x - x1, z0 - z, z - z1);
}

function baseHeight(x, z) {
  const d = x - coastX(z);
  // cliffs: tall around the mansion, beaches elsewhere
  let cliffMask = smoothstep(-0.25, 0.35, noise2(z / 2600, 7.7));
  cliffMask = Math.max(cliffMask, 1 - smoothstep(400, 900, Math.abs(z)));
  const cliffH = lerp(7, 46 + 14 * noise2(z / 700, 3.1), cliffMask);
  const cliffW = lerp(160, 34, cliffMask);
  let h = (d < 0 ? Math.max(-70, d * 0.09) : 0) - 2.5 + cliffH * smoothstep(-8, cliffW, d);

  const inland = smoothstep(40, 1300, d);
  h += (fbm(x / 1700, z / 1700, 5) * 0.5 + 0.5) * 170 * inland;
  h += fbm(x / 260, z / 260, 3) * 6 * smoothstep(0, 60, d);

  const north = smoothstep(-800, -4200, z);
  const mMask = smoothstep(1300, 4200, d) * (0.3 + 0.7 * north);
  const r = ridged(x / 2700, z / 2700, 5);
  h += r * r * 1050 * mMask;

  // desert plateau toward Gulmira
  const desert = smoothstep(-5200, -7000, z);
  h = lerp(h, 120 + fbm(x / 900, z / 900, 4) * 60, desert * (1 - smoothstep(0, 1, mMask * 1.6 - 0.4)) * 0.85);

  // city (square), HQ, Gulmira flatten
  const cd = Math.max(Math.abs(x - CITY.x), Math.abs(z - CITY.z));
  h = lerp(h, CITY.y, 1 - smoothstep(CITY.half, CITY.half + 650, cd));
  const hd = Math.hypot(x - HQ.x, z - HQ.z);
  h = lerp(h, HQ.y, 1 - smoothstep(HQ.r, HQ.r + 400, hd));
  const gd = Math.hypot(x - GULMIRA.x, z - GULMIRA.z);
  h = lerp(h, GULMIRA.y + fbm(x / 300, z / 300, 3) * 4, 1 - smoothstep(GULMIRA.r, GULMIRA.r + 900, gd));

  // mansion pad: blends inland, sharp to the cliff on the ocean side
  const pd = rectDist(x, z, -62, 45, -48, 48);
  const pw = (1 - smoothstep(0, 40, pd)) * smoothstep(-76, -62, x);
  h = lerp(h, MANSION.padY, pw);
  return h;
}

// --- road profile (smoothed so the car can drive it)
const ROAD = (() => {
  const pts = ROAD_PTS.map(([x, z]) => ({ x, z, y: 0 }));
  pts.forEach((p) => (p.y = baseHeight(p.x, p.z)));
  pts[0].y = MANSION.padY + 0.02;
  for (let it = 0; it < 4; it++) for (let i = 1; i < pts.length - 1; i++) pts[i].y = (pts[i - 1].y + pts[i].y * 2 + pts[i + 1].y) / 4;
  return pts;
})();
export const roadPoints = ROAD;

export function roadInfo(x, z) {
  let best = 1e9, by = 0;
  for (let i = 0; i < ROAD.length - 1; i++) {
    const a = ROAD[i], b = ROAD[i + 1];
    const abx = b.x - a.x, abz = b.z - a.z;
    const t = clamp(((x - a.x) * abx + (z - a.z) * abz) / (abx * abx + abz * abz), 0, 1);
    const px = a.x + abx * t, pz = a.z + abz * t;
    const dd = Math.hypot(x - px, z - pz);
    if (dd < best) { best = dd; by = lerp(a.y, b.y, t); }
  }
  return { dist: best, y: by };
}

export function heightAt(x, z) {
  let h = baseHeight(x, z);
  // road corridor (cheap bounding check first)
  if (x > 0 && x < 2700 && z > -150 && z < 800) {
    const r = roadInfo(x, z);
    if (r.dist < 45) h = lerp(h, r.y - 0.15, 1 - smoothstep(9, 45, r.dist));
  }
  // cuts for the basement: launch tunnel (west) and driveway ramp (east)
  if (x > -95 && x < -26 && Math.abs(z) < 8) h = Math.min(h, MANSION.workshopY - 0.5);
  if (x > 16 && x < 86 && Math.abs(z) < 7) {
    const ry = MANSION.workshopY + clamp((x - 20) / 65, 0, 1) * (MANSION.padY - MANSION.workshopY + 0.4);
    h = Math.min(h, ry - 0.08);
  }
  return h;
}

export function slopeAt(x, z) {
  const e = 3;
  const dx = heightAt(x + e, z) - heightAt(x - e, z);
  const dz = heightAt(x, z + e) - heightAt(x, z - e);
  return Math.hypot(dx, dz) / (2 * e);
}

export function isDesert(x, z) { return z < -5600; }

// ---------------------------------------------------------------- colors
const C = {
  seabed: new THREE.Color(0.34, 0.32, 0.24), sand: new THREE.Color(0.74, 0.66, 0.48),
  dry: new THREE.Color(0.46, 0.41, 0.26), scrub: new THREE.Color(0.22, 0.28, 0.13),
  rock: new THREE.Color(0.26, 0.22, 0.19), darkRock: new THREE.Color(0.25, 0.23, 0.21),
  desert: new THREE.Color(0.76, 0.58, 0.37), snow: new THREE.Color(0.93, 0.95, 0.98),
  concrete: new THREE.Color(0.5, 0.49, 0.47), asphalt: new THREE.Color(0.18, 0.18, 0.19),
  lawn: new THREE.Color(0.2, 0.34, 0.12),
};
const _c = new THREE.Color();
function colorAt(x, z, h, slope) {
  if (h < 0.5) return _c.copy(C.seabed).lerp(C.sand, smoothstep(-8, 0.5, h));
  const n = fbm(x / 140, z / 140, 3);
  _c.copy(C.dry).lerp(C.scrub, smoothstep(-0.25, 0.35, n));
  if (h < 4) _c.lerp(C.sand, 1 - smoothstep(1.5, 4, h));
  const desert = smoothstep(-5000, -6200, z);
  if (desert > 0) _c.lerp(C.desert, desert * (0.85 + 0.15 * n));
  if (h > 600) _c.lerp(C.darkRock, smoothstep(600, 800, h) * 0.6);
  if (slope > 0.55) { _c.lerp(C.rock, smoothstep(0.55, 1.1, slope)); _c.multiplyScalar(0.85 + 0.3 * (0.5 + 0.5 * Math.sin(h * 0.9 + n * 4))); }
  if (h > 880) _c.lerp(C.snow, smoothstep(880, 980, h) * (slope < 1.2 ? 1 : 0.4));
  const cd = Math.max(Math.abs(x - CITY.x), Math.abs(z - CITY.z));
  if (cd < CITY.half + 120) _c.lerp(C.concrete, 1 - smoothstep(CITY.half - 50, CITY.half + 120, cd));
  if (Math.hypot(x - HQ.x, z - HQ.z) < HQ.r + 30) _c.lerp(C.lawn, 0.8);
  // mansion pad / driveway tint
  if (rectDist(x, z, -60, 44, -46, 46) < 0) _c.lerp(C.lawn, 0.55);
  if (x > 0 && x < 2700 && z > -150 && z < 800) {
    const r = roadInfo(x, z);
    if (r.dist < 16) _c.lerp(C.dry, 0.5);
  }
  return _c;
}

// ---------------------------------------------------------------- meshes
function buildGrid(segs, mapFn, lowerInside = 0) {
  const n = segs + 1;
  const pos = new Float32Array(n * n * 3), uv = new Float32Array(n * n * 2), col = new Float32Array(n * n * 3);
  const idx = [];
  for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
    const x = mapFn(i / segs), z = mapFn(j / segs);
    let y = heightAt(x, z);
    if (lowerInside && Math.abs(x) < lowerInside && Math.abs(z) < lowerInside) y -= 6;
    const k = j * n + i;
    pos[k * 3] = x; pos[k * 3 + 1] = y; pos[k * 3 + 2] = z;
    uv[k * 2] = x / 24; uv[k * 2 + 1] = z / 24;
  }
  for (let j = 0; j < segs; j++) for (let i = 0; i < segs; i++) {
    const a = j * n + i, b = a + 1, c = a + n, d = c + 1;
    idx.push(a, c, b, b, c, d);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  const nrm = geo.attributes.normal.array;
  for (let k = 0; k < n * n; k++) {
    const ny = nrm[k * 3 + 1];
    const slope = Math.sqrt(Math.max(0, 1 - ny * ny)) / Math.max(0.05, ny);
    const c = colorAt(pos[k * 3], pos[k * 3 + 2], pos[k * 3 + 1], slope);
    col[k * 3] = c.r; col[k * 3 + 1] = c.g; col[k * 3 + 2] = c.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  geo.computeBoundingSphere();
  return geo;
}

export function buildTerrain(scene) {
  const detail = noiseTexture(256, { base: 205, amp: 45, scale: 14 });
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, map: detail, roughness: 0.96, metalness: 0 });
  mat.envMapIntensity = 0.35;

  // World mesh — vertices concentrated near the mansion via a power warp.
  const P = 2.15;
  const world = new THREE.Mesh(
    buildGrid(340, (t) => { const u = t * 2 - 1; return Math.sign(u) * Math.pow(Math.abs(u), P) * HALF; }, 296),
    mat,
  );
  world.receiveShadow = true;
  world.name = 'terrain-world';
  scene.add(world);

  // High-detail patch around the mansion (2 m spacing).
  const patch = new THREE.Mesh(buildGrid(300, (t) => (t - 0.5) * 600), mat);
  patch.receiveShadow = true;
  patch.name = 'terrain-patch';
  scene.add(patch);

  // Road ribbon
  scene.add(buildRoadMesh());
  return { world, patch };
}

function buildRoadMesh() {
  const tex = (() => {
    const c = document.createElement('canvas'); c.width = 64; c.height = 256;
    const g = c.getContext('2d');
    g.fillStyle = '#2b2c2e'; g.fillRect(0, 0, 64, 256);
    for (let i = 0; i < 600; i++) { g.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`; g.fillRect(Math.random() * 64, Math.random() * 256, 2, 2); }
    g.fillStyle = '#d8d8d0'; g.fillRect(2, 0, 2, 256); g.fillRect(60, 0, 2, 256);
    g.fillStyle = '#e0b52a'; g.fillRect(30, 0, 1.5, 256); g.fillRect(33, 0, 1.5, 256);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapT = THREE.RepeatWrapping; t.anisotropy = 8;
    return t;
  })();
  const pts = [];
  for (let i = 0; i < ROAD.length - 1; i++) {
    const a = ROAD[i], b = ROAD[i + 1];
    const len = Math.hypot(b.x - a.x, b.z - a.z), steps = Math.ceil(len / 4);
    for (let s = 0; s < steps; s++) { const t = s / steps; pts.push([lerp(a.x, b.x, t), lerp(a.z, b.z, t)]); }
  }
  pts.push([ROAD[ROAD.length - 1].x, ROAD[ROAD.length - 1].z]);
  // smooth the polyline corners
  for (let it = 0; it < 6; it++) for (let i = 1; i < pts.length - 1; i++) {
    pts[i] = [(pts[i - 1][0] + pts[i][0] * 2 + pts[i + 1][0]) / 4, (pts[i - 1][1] + pts[i][1] * 2 + pts[i + 1][1]) / 4];
  }
  const W = 7, pos = [], uv = [], idx = [];
  let dist = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i], q = pts[Math.min(i + 1, pts.length - 1)], o = pts[Math.max(i - 1, 0)];
    let dx = q[0] - o[0], dz = q[1] - o[1]; const l = Math.hypot(dx, dz) || 1; dx /= l; dz /= l;
    const nx = -dz, nz = dx;
    if (i > 0) dist += Math.hypot(p[0] - pts[i - 1][0], p[1] - pts[i - 1][1]);
    for (const s of [-1, 1]) {
      const x = p[0] + nx * W * s, z = p[1] + nz * W * s;
      pos.push(x, heightAt(x, z) + 0.12, z);
      uv.push(s < 0 ? 0 : 1, dist / 16);
    }
    if (i > 0) { const a = (i - 1) * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geo.setIndex(idx); geo.computeVertexNormals();
  const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ map: tex, roughness: 0.85, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 }));
  m.receiveShadow = true;
  m.name = 'road';
  return m;
}

// ---------------------------------------------------------------- ocean
export function buildOcean(scene) {
  const normal = normalMapTexture(512, 9, 1.4);
  normal.repeat.set(2000, 2000); // 30 m wave tiles
  const mat = new THREE.MeshStandardMaterial({
    color: 0x0b3a52, roughness: 0.2, metalness: 0.0, normalMap: normal, normalScale: new THREE.Vector2(0.22, 0.22),
  });
  mat.envMapIntensity = 1.0;
  const uTime = { value: 0 };
  // two scrolling normal layers at different scales hide tiling; strength fades with distance to avoid glitter
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = uTime;
    sh.fragmentShader = 'uniform float uTime;\n' + sh.fragmentShader.replace(
      'vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;',
      `vec3 n1 = texture2D( normalMap, vNormalMapUv + uTime * vec2( 0.012, 0.007 ) ).xyz * 2.0 - 1.0;
      vec3 n2 = texture2D( normalMap, vNormalMapUv * 0.21 + uTime * vec2( -0.003, 0.004 ) ).xyz * 2.0 - 1.0;
      vec3 n3 = texture2D( normalMap, vNormalMapUv * 3.7 + uTime * vec2( 0.02, -0.03 ) ).xyz * 2.0 - 1.0;
      vec3 mapN = normalize( vec3( n1.xy + n2.xy * 1.3 + n3.xy * 0.5, n1.z * n2.z ) );
      mapN.xy *= mix( 0.3, 1.0, 1.0 - smoothstep( 200.0, 5000.0, length( vViewPosition ) ) );`);
  };
  const geo = new THREE.PlaneGeometry(60000, 60000, 1, 1);
  geo.rotateX(-Math.PI / 2);
  const ocean = new THREE.Mesh(geo, mat);
  ocean.receiveShadow = false;
  ocean.name = 'ocean';
  scene.add(ocean);
  return {
    mesh: ocean,
    update(dt, t, playerPos) {
      const step = 60000 / 2000 * 100; // 3 km steps keep all layers aligned (lcm of tile sizes)
      ocean.position.x = Math.round(playerPos.x / step) * step;
      ocean.position.z = Math.round(playerPos.z / step) * step;
      uTime.value = t;
    },
  };
}

// ---------------------------------------------------------------- vegetation
function colored(geo, color) {
  geo = geo.index ? geo.toNonIndexed() : geo;
  const n = geo.attributes.position.count, c = new Float32Array(n * 3);
  const col = new THREE.Color(color);
  for (let i = 0; i < n; i++) { c[i * 3] = col.r; c[i * 3 + 1] = col.g; c[i * 3 + 2] = col.b; }
  geo.setAttribute('color', new THREE.BufferAttribute(c, 3));
  geo.deleteAttribute('uv');
  return geo;
}

export function palmGeometry() {
  const parts = [];
  const trunk = new THREE.CylinderGeometry(0.18, 0.32, 11, 7, 6);
  const tp = trunk.attributes.position;
  for (let i = 0; i < tp.count; i++) { const y = tp.getY(i) + 5.5; tp.setX(i, tp.getX(i) + Math.pow(y / 11, 2) * 1.2); }
  trunk.translate(0, 5.5, 0);
  parts.push(colored(trunk, 0x6d5a43));
  for (let k = 0; k < 9; k++) {
    const f = new THREE.ConeGeometry(0.55, 4.6, 3, 1);
    f.scale(1, 1, 0.18);
    f.translate(0, 2.3, 0);
    f.rotateX(Math.PI / 2 + 0.55);
    f.rotateY((k / 9) * Math.PI * 2);
    f.translate(1.2, 11, 0);
    parts.push(colored(f, k % 2 ? 0x3d6b2a : 0x4c7a30));
  }
  return mergeGeometries(parts);
}

export function buildVegetation(scene) {
  const rnd = mulberry32(42);
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, flatShading: true });
  const dummy = new THREE.Object3D();
  const placeOK = (x, z, h, s, minH = 1.5) => {
    if (h < minH) return false;
    if (s > 0.7) return false;
    if (Math.max(Math.abs(x - CITY.x), Math.abs(z - CITY.z)) < CITY.half + 60) return false;
    if (Math.hypot(x - HQ.x, z - HQ.z) < HQ.r + 40) return false;
    if (Math.hypot(x - GULMIRA.x, z - GULMIRA.z) < GULMIRA.r) return false;
    if (rectDist(x, z, -95, 90, -60, 60) < 0) return false;
    if (x > 0 && x < 2700 && z > -150 && z < 800 && roadInfo(x, z).dist < 14) return false;
    return true;
  };

  // shrubs
  {
    const g1 = colored(new THREE.IcosahedronGeometry(1, 0), 0xffffff); // tinted per instance
    const count = 7000;
    const im = new THREE.InstancedMesh(g1, mat, count);
    let n = 0;
    for (let tries = 0; tries < count * 4 && n < count; tries++) {
      const r = Math.pow(rnd(), 1.6) * 7000;
      const a = rnd() * Math.PI * 2;
      const x = Math.cos(a) * r + 600, z = Math.sin(a) * r;
      const h = heightAt(x, z);
      if (z < -5300 || h > 650 || !placeOK(x, z, h, slopeAt(x, z))) continue;
      const s = 0.6 + rnd() * 1.8;
      dummy.position.set(x, h + s * 0.3, z);
      dummy.scale.set(s * (0.8 + rnd() * 0.5), s * (0.5 + rnd() * 0.5), s * (0.8 + rnd() * 0.5));
      dummy.rotation.set(0, rnd() * 6, 0);
      dummy.updateMatrix();
      im.setMatrixAt(n, dummy.matrix);
      im.setColorAt(n, new THREE.Color().setHSL(0.17 + rnd() * 0.08, 0.35, 0.22 + rnd() * 0.12));
      n++;
    }
    im.count = n; im.castShadow = true; im.receiveShadow = true;
    scene.add(im);
  }
  // pines on the mountains
  {
    const g = mergeGeometries([colored(new THREE.CylinderGeometry(0.25, 0.35, 3, 5).translate(0, 1.5, 0), 0x4a3a2a),
      colored(new THREE.ConeGeometry(2.4, 7, 6).translate(0, 6, 0), 0x22381f),
      colored(new THREE.ConeGeometry(1.7, 5, 6).translate(0, 9, 0), 0x274223)]);
    const count = 6000;
    const im = new THREE.InstancedMesh(g, mat, count);
    let n = 0;
    for (let tries = 0; tries < count * 6 && n < count; tries++) {
      const x = rnd() * 11000 - 1000, z = rnd() * 11000 - 7500;
      const h = heightAt(x, z);
      if (h < 220 || h > 900 || z < -5600 || !placeOK(x, z, h, slopeAt(x, z))) continue;
      const s = 0.8 + rnd() * 1.4;
      dummy.position.set(x, h - 0.3, z); dummy.scale.setScalar(s); dummy.rotation.set(0, rnd() * 6, 0); dummy.updateMatrix();
      im.setMatrixAt(n++, dummy.matrix);
    }
    im.count = n; im.castShadow = true;
    scene.add(im);
  }
  // palms along the coast + around the mansion
  {
    const g = palmGeometry();
    const count = 420;
    const im = new THREE.InstancedMesh(g, mat, count);
    let n = 0;
    const add = (x, z, s) => {
      const h = heightAt(x, z);
      dummy.position.set(x, h - 0.2, z); dummy.scale.setScalar(s); dummy.rotation.set(0, rnd() * 6, 0); dummy.updateMatrix();
      im.setMatrixAt(n++, dummy.matrix);
    };
    // mansion garden palms
    [[-30, -55], [-10, -58], [15, -56], [30, -52], [-30, 55], [-8, 58], [18, 56], [38, 50], [60, -20], [62, 22], [95, -14], [95, 14], [130, -12], [130, 16]]
      .forEach(([x, z]) => add(x, z, 0.9 + rnd() * 0.3));
    for (let tries = 0; tries < 6000 && n < count; tries++) {
      const z = rnd() * 9000 - 4000;
      const x = coastX(z) + 30 + rnd() * 400;
      const h = heightAt(x, z);
      if (!placeOK(x, z, h, slopeAt(x, z), 2)) continue;
      add(x, z, 0.8 + rnd() * 0.5);
    }
    im.count = n; im.castShadow = true;
    scene.add(im);
  }
  // desert rocks
  {
    const g = colored(new THREE.DodecahedronGeometry(1, 0), 0x9a7a55);
    const count = 900;
    const im = new THREE.InstancedMesh(g, mat, count);
    let n = 0;
    for (let tries = 0; tries < count * 4 && n < count; tries++) {
      const x = GULMIRA.x + (rnd() - 0.5) * 7000, z = GULMIRA.z + (rnd() - 0.5) * 6000;
      if (Math.hypot(x - GULMIRA.x, z - GULMIRA.z) < 500) continue;
      const h = heightAt(x, z);
      const s = 1 + rnd() * 5;
      dummy.position.set(x, h + s * 0.2, z); dummy.scale.set(s, s * 0.6, s * 1.2); dummy.rotation.set(rnd(), rnd() * 6, rnd()); dummy.updateMatrix();
      im.setMatrixAt(n++, dummy.matrix);
    }
    im.count = n; im.castShadow = true; im.receiveShadow = true;
    scene.add(im);
  }
}
