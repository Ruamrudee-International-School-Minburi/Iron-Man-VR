import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { addBox } from './colliders.js';
import { heightAt } from './terrain.js';
import { trafficCarGeometry } from './cars.js';
import { CITY, TOWER, EXPO, HQ, GULMIRA } from './layout.js';
import { mulberry32, canvasTexture, noiseTexture, textTexture } from '../util.js';

const BLOCK = 150, ROADW = 30, NB = 21;
export const GX0 = CITY.x - (NB * BLOCK) / 2, GZ0 = CITY.z - (NB * BLOCK) / 2;
export const cityRoads = { x: [], z: [] };
for (let k = 0; k <= NB; k++) { cityRoads.x.push(GX0 + k * BLOCK); cityRoads.z.push(GZ0 + k * BLOCK); }

// ---------------------------------------------------------------- facade textures
function facade(style, rnd) {
  const S = 256;
  const lit = [];
  const col = canvasTexture(S, S, (g) => {
    if (style === 0) { // blue glass curtain wall
      const gr = g.createLinearGradient(0, 0, 0, S); gr.addColorStop(0, '#6f8faa'); gr.addColorStop(1, '#3f5a72');
      g.fillStyle = gr; g.fillRect(0, 0, S, S);
      g.fillStyle = '#c9d3dc';
      for (let i = 0; i <= 4; i++) g.fillRect(i * 64 - 2, 0, 4, S);
      for (let j = 0; j <= 4; j++) g.fillRect(0, j * 64 - 1.5, S, 3);
    } else if (style === 1) { // concrete with punched windows
      g.fillStyle = '#c8bca8'; g.fillRect(0, 0, S, S);
      for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { g.fillStyle = '#2c3640'; g.fillRect(i * 64 + 12, j * 64 + 14, 40, 36); g.fillStyle = '#7d8a96'; g.fillRect(i * 64 + 12, j * 64 + 14, 40, 3); }
    } else { // dark glass with white frames
      g.fillStyle = '#1c242c'; g.fillRect(0, 0, S, S);
      g.fillStyle = '#e8e8e8';
      for (let j = 0; j <= 4; j++) g.fillRect(0, j * 64 - 4, S, 8);
      for (let i = 0; i <= 8; i++) g.fillRect(i * 32 - 1, 0, 2, S);
    }
  }, { repeat: true });
  const emi = canvasTexture(S, S, (g) => {
    g.fillStyle = '#000'; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
      if (rnd() < 0.42) { g.fillStyle = rnd() < 0.7 ? '#ffcf8a' : '#cfe6ff'; g.fillRect(i * 64 + 10, j * 64 + 12, 44, 40); }
    }
  }, { repeat: true });
  // a plain wall/roof pixel area at uv (0.01,0.01) — style 0/2 corners are frame color, good for roofs
  return { col, emi };
}

// box with world-scaled UVs (u: meters/12, v: meters/14) on the sides and a fixed roof uv
function pushBox(A, x0, y0, z0, x1, y1, z1) {
  const P = A.pos, U = A.uv, N = A.nrm, I = A.idx;
  const quad = (p, n, uvs) => {
    const b = P.length / 3;
    for (let k = 0; k < 4; k++) { P.push(...p[k]); N.push(...n); U.push(...uvs[k]); }
    I.push(b, b + 1, b + 2, b, b + 2, b + 3);
  };
  const w = x1 - x0, d = z1 - z0, h = y1 - y0;
  const v0 = y0 / 14, v1 = y1 / 14;
  const ux = w / 12, uz = d / 12;
  quad([[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]], [0, 0, 1], [[0, v0], [ux, v0], [ux, v1], [0, v1]]);
  quad([[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]], [0, 0, -1], [[0, v0], [ux, v0], [ux, v1], [0, v1]]);
  quad([[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]], [1, 0, 0], [[0, v0], [uz, v0], [uz, v1], [0, v1]]);
  quad([[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]], [-1, 0, 0], [[0, v0], [uz, v0], [uz, v1], [0, v1]]);
  const r = [0.005, 0.005];
  quad([[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]], [0, 1, 0], [r, r, r, r]);
}
function arraysToGeo(A) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(A.pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(A.nrm, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(A.uv, 2));
  g.setIndex(A.idx);
  g.computeBoundingSphere();
  return g;
}

export function buildCity(scene) {
  const rnd = mulberry32(7);
  const group = new THREE.Group(); group.name = 'city'; scene.add(group);
  const styles = [0, 1, 2].map((s) => facade(s, rnd));
  const mats = styles.map((st, i) => {
    const m = new THREE.MeshStandardMaterial({
      map: st.col, emissiveMap: st.emi, emissive: 0xffffff, emissiveIntensity: 0,
      roughness: i === 1 ? 0.85 : 0.18, metalness: i === 1 ? 0.0 : 0.7,
    });
    m.envMapIntensity = i === 1 ? 0.4 : 1.3;
    return m;
  });
  const CH = 4; // chunks per axis
  const chunks = [];
  for (let i = 0; i < CH * CH; i++) chunks.push([0, 1, 2].map(() => ({ pos: [], uv: [], nrm: [], idx: [] })));
  const chunkOf = (x, z) => {
    const cx = Math.min(CH - 1, Math.max(0, Math.floor(((x - GX0) / (NB * BLOCK)) * CH)));
    const cz = Math.min(CH - 1, Math.max(0, Math.floor(((z - GZ0) / (NB * BLOCK)) * CH)));
    return chunks[cz * CH + cx];
  };
  const Y = CITY.y;
  const buildings = [];
  for (let bi = 0; bi < NB; bi++) for (let bj = 0; bj < NB; bj++) {
    const cx = GX0 + (bi + 0.5) * BLOCK, cz = GZ0 + (bj + 0.5) * BLOCK;
    const dT = Math.hypot(cx - TOWER.x, cz - TOWER.z);
    if (dT < 80) continue; // tower plaza
    if (Math.hypot(cx - EXPO.x, cz - EXPO.z) < EXPO.r + 60) continue; // expo park
    if (rnd() < 0.06) continue; // small parks
    const inner = BLOCK - ROADW - 8;
    const split = rnd() < 0.55 ? 2 : 1;
    for (let a = 0; a < split; a++) for (let b = 0; b < split; b++) {
      const lot = inner / split;
      const lx = cx - inner / 2 + lot * (a + 0.5), lz = cz - inner / 2 + lot * (b + 0.5);
      const w = lot * (0.62 + rnd() * 0.32), d = lot * (0.62 + rnd() * 0.32);
      let h;
      if (dT < 550) h = 70 + rnd() * rnd() * 260;
      else if (dT < 1100) h = 30 + rnd() * rnd() * 130;
      else h = 10 + rnd() * 38;
      if (split === 2) h *= 0.75;
      const style = h > 90 ? (rnd() < 0.55 ? 0 : 2) : rnd() < 0.6 ? 1 : rnd() < 0.5 ? 0 : 2;
      const A = chunkOf(lx, lz)[style];
      const x0 = lx - w / 2, x1 = lx + w / 2, z0 = lz - d / 2, z1 = lz + d / 2;
      pushBox(A, x0, Y, z0, x1, Y + h, z1);
      addBox(x0, Y - 5, z0, x1, Y + h, z1, 'building');
      buildings.push({ x: lx, z: lz, w, d, h: Y + h });
      let top = Y + h;
      if (h > 60 && rnd() < 0.6) { // setback
        const s = 0.6 + rnd() * 0.2, h2 = h * (0.15 + rnd() * 0.3);
        pushBox(A, lx - w * s / 2, top, lz - d * s / 2, lx + w * s / 2, top + h2, lz + d * s / 2);
        addBox(lx - w * s / 2, top, lz - d * s / 2, lx + w * s / 2, top + h2, lz + d * s / 2, 'building');
        top += h2;
      }
      // roof details
      const R = chunkOf(lx, lz)[1];
      for (let k = 0; k < 2 + Math.floor(rnd() * 3); k++) {
        const rx = lx + (rnd() - 0.5) * w * 0.4, rz = lz + (rnd() - 0.5) * d * 0.4, rs = 2 + rnd() * 4;
        pushBox(R, rx - rs, top, rz - rs, rx + rs, top + 1.5 + rnd() * 3, rz + rs);
      }
      if (h > 180 && rnd() < 0.5) pushBox(R, lx - 0.6, top, lz - 0.6, lx + 0.6, top + 25 + rnd() * 20, lz + 0.6);
    }
  }
  for (const ch of chunks) ch.forEach((A, i) => {
    if (!A.pos.length) return;
    const m = new THREE.Mesh(arraysToGeo(A), mats[i]);
    m.castShadow = true; m.receiveShadow = true;
    group.add(m);
  });

  // ---- ground with streets
  const streetTex = canvasTexture(512, 512, (g, w) => {
    const r = (ROADW / BLOCK) * w / 2; // road half-width in px at each edge
    g.fillStyle = '#2a2b2d'; g.fillRect(0, 0, w, w);
    g.fillStyle = '#8c8a86'; g.fillRect(r, r, w - 2 * r, w - 2 * r); // sidewalk
    g.fillStyle = '#6f6d69'; g.fillRect(r + 8, r + 8, w - 2 * r - 16, w - 2 * r - 16); // lot
    g.fillStyle = '#d8d6cf';
    for (let i = 0; i < w; i += 22) { g.fillRect(i, 0, 10, 1.5); g.fillRect(i, w - 1.5, 10, 1.5); g.fillRect(0, i, 1.5, 10); g.fillRect(w - 1.5, i, 1.5, 10); }
    // crosswalks
    g.fillStyle = '#e8e6df';
    for (let i = 0; i < 6; i++) { g.fillRect(r + 4 + i * 6, 0, 3, r - 4); g.fillRect(r + 4 + i * 6, w - r + 4, 3, r - 4); g.fillRect(0, r + 4 + i * 6, r - 4, 3); g.fillRect(w - r + 4, r + 4 + i * 6, r - 4, 3); }
  }, { repeat: true });
  streetTex.repeat.set(NB, NB);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(NB * BLOCK, NB * BLOCK), new THREE.MeshStandardMaterial({ map: streetTex, roughness: 0.9 }));
  ground.rotation.x = -Math.PI / 2;
  ground.position.set(CITY.x, Y + 0.06, CITY.z);
  ground.receiveShadow = true;
  group.add(ground);

  buildStarkTower(group, rnd);
  buildExpo(group);
  buildHQ(group);
  buildGulmira(scene);
  const traffic = buildTraffic(group, rnd);

  return {
    group, buildings, traffic,
    setNight(n) { for (const m of mats) m.emissiveIntensity = n ? 0.85 : 0; },
    update(dt) { traffic.update(dt); },
  };
}

// ---------------------------------------------------------------- Stark Tower
function buildStarkTower(group, rnd) {
  const Y = CITY.y;
  const glass = new THREE.MeshPhysicalMaterial({ color: 0x7c9ab4, metalness: 0.9, roughness: 0.08, clearcoat: 1 });
  glass.envMapIntensity = 1.6;
  const white = new THREE.MeshStandardMaterial({ color: 0xe6e6e6, roughness: 0.4, metalness: 0.3 });
  const prof = [[0, 0], [26, 0], [26, 12], [23, 14], [23, 150], [20, 230], [30, 245], [31, 262], [22, 272], [16, 300], [6, 318], [0, 320]].map(([r, y]) => new THREE.Vector2(r, y));
  const tower = new THREE.Mesh(new THREE.LatheGeometry(prof, 40), glass);
  tower.position.set(TOWER.x, Y, TOWER.z);
  tower.castShadow = true; tower.receiveShadow = true;
  group.add(tower);
  // spine fin
  const fin = new THREE.Mesh(new THREE.BoxGeometry(6, 300, 14), white);
  fin.position.set(TOWER.x + 22, Y + 150, TOWER.z); fin.castShadow = true;
  group.add(fin);
  // landing pad (cantilevered west, facing the ocean)
  const padTex = canvasTexture(256, 256, (g, w) => {
    g.fillStyle = '#3a3c40'; g.fillRect(0, 0, w, w);
    g.strokeStyle = '#e8c547'; g.lineWidth = 8; g.beginPath(); g.arc(128, 128, 110, 0, Math.PI * 2); g.stroke();
    g.fillStyle = '#ffffff'; g.font = 'bold 120px Arial'; g.textAlign = 'center'; g.fillText('S', 128, 170);
  });
  const pad = new THREE.Mesh(new THREE.CylinderGeometry(15, 15, 1.2, 40), [new THREE.MeshStandardMaterial({ color: 0xcfcfcf, metalness: 0.6, roughness: 0.4 }), new THREE.MeshStandardMaterial({ map: padTex }), white]);
  pad.position.set(TOWER.x - 34, Y + 232, TOWER.z);
  pad.castShadow = pad.receiveShadow = true;
  group.add(pad);
  addBox(TOWER.x - 49, Y + 231.4, TOWER.z - 11, TOWER.x - 19, Y + 232.6, TOWER.z + 11);
  // STARK sign facing west
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(56, 13), new THREE.MeshBasicMaterial({ map: textTexture('STARK', { font: 'bold 120px Arial', color: '#f4f8ff', w: 1024, h: 220, glow: '#9fd7ff' }), transparent: true, toneMapped: false, depthWrite: false }));
  sign.position.set(TOWER.x - 31.5, Y + 255, TOWER.z); sign.rotation.y = -Math.PI / 2;
  group.add(sign);
  // colliders (stacked boxes)
  for (const [r, y0, y1] of [[24, 0, 150], [21, 150, 230], [28, 230, 272], [14, 272, 320]]) addBox(TOWER.x - r * 0.85, Y + y0, TOWER.z - r * 0.85, TOWER.x + r * 0.85, Y + y1, TOWER.z + r * 0.85, 'building');
  // plaza
  const plaza = new THREE.Mesh(new THREE.CylinderGeometry(60, 60, 0.3, 48), new THREE.MeshStandardMaterial({ color: 0xbdb8ae, roughness: 0.6 }));
  plaza.position.set(TOWER.x, Y + 0.1, TOWER.z); plaza.receiveShadow = true;
  group.add(plaza);
}

// ---------------------------------------------------------------- Stark Expo
function buildExpo(group) {
  const Y = CITY.y;
  const steel = new THREE.MeshStandardMaterial({ color: 0xb8bcc2, metalness: 1, roughness: 0.25 });
  const grass = new THREE.Mesh(new THREE.CylinderGeometry(EXPO.r, EXPO.r, 0.3, 64), new THREE.MeshStandardMaterial({ color: 0x3f6b2c, roughness: 1 }));
  grass.position.set(EXPO.x, Y + 0.12, EXPO.z); grass.receiveShadow = true; group.add(grass);
  const water = new THREE.Mesh(new THREE.CylinderGeometry(85, 85, 0.4, 64), new THREE.MeshStandardMaterial({ color: 0x1b6c8c, roughness: 0.05, metalness: 0.1 }));
  water.position.set(EXPO.x, Y + 0.25, EXPO.z); group.add(water);
  // Unisphere-style globe
  const G = new THREE.Group(); G.position.set(EXPO.x, Y + 72, EXPO.z);
  const R = 42;
  for (let i = 0; i < 10; i++) { const t = new THREE.Mesh(new THREE.TorusGeometry(R, 0.5, 6, 64), steel); t.rotation.y = (i / 10) * Math.PI; G.add(t); }
  for (let j = -3; j <= 3; j++) { const lat = (j / 4) * (Math.PI / 2); const t = new THREE.Mesh(new THREE.TorusGeometry(R * Math.cos(lat), 0.45, 6, 64), steel); t.rotation.x = Math.PI / 2; t.position.y = R * Math.sin(lat); G.add(t); }
  for (const a of [0.4, -0.5, 1.1]) { const t = new THREE.Mesh(new THREE.TorusGeometry(R * 1.25, 0.6, 6, 80), steel); t.rotation.set(Math.PI / 2 + a, a, 0); G.add(t); }
  // continents as flattened plates
  const land = new THREE.MeshStandardMaterial({ color: 0x9aa0a6, metalness: 0.9, roughness: 0.35, side: THREE.DoubleSide });
  for (let k = 0; k < 7; k++) {
    const s = new THREE.Mesh(new THREE.SphereGeometry(R + 0.3, 16, 12, k * 0.9, 0.6 + (k % 3) * 0.2, 0.6 + (k % 2) * 0.5, 0.5 + (k % 3) * 0.2), land);
    G.add(s);
  }
  G.traverse((o) => (o.castShadow = true));
  group.add(G);
  const stand = new THREE.Mesh(new THREE.CylinderGeometry(3, 8, 32, 12), steel);
  stand.position.set(EXPO.x, Y + 16, EXPO.z); stand.castShadow = true; group.add(stand);
  addBox(EXPO.x - 30, Y + 30, EXPO.z - 30, EXPO.x + 30, Y + 114, EXPO.z + 30, 'building');
  addBox(EXPO.x - 6, Y, EXPO.z - 6, EXPO.x + 6, Y + 32, EXPO.z + 6, 'building');
  // pavilions
  const cols = [0xd23b2b, 0xe6e6e6, 0x2a62c9, 0xe0b23a, 0x1e1e1e, 0x9fd2e8, 0xe6e6e6, 0xd23b2b];
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2 + 0.2;
    const x = EXPO.x + Math.cos(a) * 230, z = EXPO.z + Math.sin(a) * 230;
    const m = new THREE.MeshStandardMaterial({ color: cols[i], roughness: 0.35, metalness: 0.2 });
    let mesh;
    if (i % 3 === 0) { mesh = new THREE.Mesh(new THREE.SphereGeometry(30, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), m); mesh.position.set(x, Y, z); addBox(x - 24, Y, z - 24, x + 24, Y + 28, z + 24, 'building'); }
    else if (i % 3 === 1) { mesh = new THREE.Mesh(new THREE.BoxGeometry(60, 22, 40), m); mesh.position.set(x, Y + 11, z); mesh.rotation.y = -a; addBox(x - 30, Y, z - 30, x + 30, Y + 22, z + 30, 'building'); }
    else { mesh = new THREE.Mesh(new THREE.CylinderGeometry(18, 26, 34, 6), m); mesh.position.set(x, Y + 17, z); addBox(x - 22, Y, z - 22, x + 22, Y + 34, z + 22, 'building'); }
    mesh.castShadow = mesh.receiveShadow = true;
    group.add(mesh);
  }
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(90, 18), new THREE.MeshBasicMaterial({ map: textTexture('STARK EXPO', { font: 'bold 110px Arial', color: '#ffffff', w: 1024, h: 210, glow: '#ff5a3a' }), transparent: true, side: THREE.DoubleSide, toneMapped: false, depthWrite: false }));
  sign.position.set(EXPO.x - 200, Y + 46, EXPO.z - 150); sign.lookAt(EXPO.x - 1000, Y + 46, EXPO.z - 600);
  group.add(sign);
  const signPost = new THREE.Mesh(new THREE.BoxGeometry(2, 46, 2), steel); signPost.position.set(EXPO.x - 200, Y + 23, EXPO.z - 150); group.add(signPost);
}

// ---------------------------------------------------------------- Stark Industries HQ + Arc Reactor
export const REACTOR = { x: HQ.x + 70, z: HQ.z, r: 62, top: HQ.y + 26 };
function buildHQ(group) {
  const Y = HQ.y;
  const glass = new THREE.MeshPhysicalMaterial({ color: 0x8aa3b6, metalness: 0.85, roughness: 0.1 });
  glass.envMapIntensity = 1.4;
  const white = new THREE.MeshStandardMaterial({ color: 0xdedede, roughness: 0.5 });
  const main = new THREE.Mesh(new THREE.BoxGeometry(170, 34, 46), glass);
  main.position.set(HQ.x - 110, Y + 17, HQ.z); main.castShadow = main.receiveShadow = true; group.add(main);
  addBox(HQ.x - 195, Y, HQ.z - 23, HQ.x - 25, Y + 34, HQ.z + 23, 'building');
  const roofBand = new THREE.Mesh(new THREE.BoxGeometry(172, 3, 48), white); roofBand.position.set(HQ.x - 110, Y + 35.5, HQ.z); group.add(roofBand);
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(90, 10), new THREE.MeshBasicMaterial({ map: textTexture('STARK INDUSTRIES', { font: 'bold 80px Arial', color: '#ffffff', w: 1024, h: 120 }), transparent: true, toneMapped: false, depthWrite: false }));
  sign.position.set(HQ.x - 196, Y + 26, HQ.z); sign.rotation.y = -Math.PI / 2; group.add(sign);
  // arc reactor building
  const R = REACTOR;
  const drum = new THREE.Mesh(new THREE.CylinderGeometry(R.r, R.r + 4, 26, 64), white);
  drum.position.set(R.x, Y + 13, R.z); drum.castShadow = drum.receiveShadow = true; group.add(drum);
  const roof = new THREE.Mesh(new THREE.CylinderGeometry(R.r, R.r, 1, 64), new THREE.MeshStandardMaterial({ color: 0x4a4d52, metalness: 0.7, roughness: 0.4 }));
  roof.position.set(R.x, R.top, R.z); roof.receiveShadow = true; group.add(roof);
  const glow = new THREE.MeshBasicMaterial({ color: new THREE.Color(0x7fd8ff).multiplyScalar(2), toneMapped: false });
  const ring = new THREE.Mesh(new THREE.TorusGeometry(R.r * 0.7, 2.2, 12, 96), glow); ring.rotation.x = Math.PI / 2; ring.position.set(R.x, R.top + 0.8, R.z); group.add(ring);
  const core = new THREE.Mesh(new THREE.CylinderGeometry(14, 14, 0.6, 48), glow); core.position.set(R.x, R.top + 0.7, R.z); group.add(core);
  for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2; const s = new THREE.Mesh(new THREE.BoxGeometry(R.r * 0.55, 0.6, 2), white); s.position.set(R.x + Math.cos(a) * R.r * 0.42, R.top + 0.6, R.z + Math.sin(a) * R.r * 0.42); s.rotation.y = -a; group.add(s); }
  for (const [a, b] of [[0.85, 0.85], [0.6, 1], [1, 0.6]]) addBox(R.x - R.r * a, Y, R.z - R.r * b, R.x + R.r * a, R.top + 0.5, R.z + R.r * b, 'building');
  // parking lot
  const lot = new THREE.Mesh(new THREE.PlaneGeometry(140, 90), new THREE.MeshStandardMaterial({ color: 0x3a3b3d, roughness: 0.95 }));
  lot.rotation.x = -Math.PI / 2; lot.position.set(HQ.x - 110, Y + 0.08, HQ.z + 100); lot.receiveShadow = true; group.add(lot);
}

// ---------------------------------------------------------------- Gulmira (desert village)
function buildGulmira(scene) {
  const rnd = mulberry32(99);
  const mud = new THREE.MeshStandardMaterial({ color: 0xb59a74, roughness: 1, map: noiseTexture(128, { base: 210, amp: 45, scale: 10 }) });
  const dark = new THREE.MeshStandardMaterial({ color: 0x3d2f22, roughness: 1 });
  const geos = [], darks = [];
  const box = (x, y, z, w, h, d) => { geos.push(new THREE.BoxGeometry(w, h, d).translate(x, y + h / 2, z)); addBox(x - w / 2, y, z - d / 2, x + w / 2, y + h, z + d / 2, 'building'); };
  for (let i = 0; i < 70; i++) {
    const a = rnd() * Math.PI * 2, r = 30 + Math.sqrt(rnd()) * 300;
    const x = GULMIRA.x + Math.cos(a) * r, z = GULMIRA.z + Math.sin(a) * r;
    const y = heightAt(x, z) - 0.5;
    const w = 7 + rnd() * 10, d = 7 + rnd() * 10, h = 4 + rnd() * 6;
    box(x, y, z, w, h, d);
    if (rnd() < 0.35) box(x + (rnd() - 0.5) * w * 0.3, y + h, z + (rnd() - 0.5) * d * 0.3, w * 0.5, 3.5, d * 0.5);
    // windows/doors
    darks.push(new THREE.BoxGeometry(1.4, 2.2, 0.2).translate(x, y + 1.1, z + d / 2 + 0.05));
    darks.push(new THREE.BoxGeometry(0.9, 0.9, 0.2).translate(x + w * 0.25, y + h * 0.65, z + d / 2 + 0.05));
  }
  // compound wall + mosque-like dome & minaret
  const cx = GULMIRA.x, cz = GULMIRA.z, cy = heightAt(cx, cz);
  geos.push(new THREE.CylinderGeometry(14, 14, 12, 24).translate(cx, cy + 6, cz));
  geos.push(new THREE.SphereGeometry(13, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2).translate(cx, cy + 12, cz));
  geos.push(new THREE.CylinderGeometry(2.4, 2.8, 34, 12).translate(cx + 22, cy + 17, cz + 4));
  addBox(cx - 12, cy, cz - 12, cx + 12, cy + 24, cz + 12, 'building');
  addBox(cx + 20, cy, cz + 2, cx + 24, cy + 34, cz + 6, 'building');
  const norm = (arr) => arr.map((g) => { g.deleteAttribute('uv1'); return g.index ? g.toNonIndexed() : g; });
  const m = new THREE.Mesh(mergeGeometries(norm(geos)), mud); m.castShadow = m.receiveShadow = true; scene.add(m);
  const d = new THREE.Mesh(mergeGeometries(norm(darks)), dark); scene.add(d);
}

// ---------------------------------------------------------------- traffic
function buildTraffic(group, rnd) {
  const N = 320;
  const geo = trafficCarGeometry();
  const mat = new THREE.MeshStandardMaterial({ roughness: 0.3, metalness: 0.6 });
  const im = new THREE.InstancedMesh(geo, mat, N);
  im.castShadow = false;
  const palette = [0xeeeeee, 0x111111, 0x8a8f96, 0x9b1b1b, 0x1d3f7a, 0xd8c9a3, 0x2f4f2f, 0xf0c419];
  const cars = [];
  const span = NB * BLOCK;
  for (let i = 0; i < N; i++) {
    const alongX = rnd() < 0.5;
    const line = Math.floor(rnd() * (NB + 1));
    const dir = rnd() < 0.5 ? 1 : -1;
    const lane = dir * (4 + (rnd() < 0.5 ? 0 : 4));
    cars.push({ alongX, base: (alongX ? GZ0 : GX0) + line * BLOCK + lane, t: rnd() * span, dir, speed: 11 + rnd() * 9 });
    im.setColorAt(i, new THREE.Color(palette[Math.floor(rnd() * palette.length)]));
  }
  const dummy = new THREE.Object3D();
  group.add(im);
  const update = (dt) => {
    for (let i = 0; i < N; i++) {
      const c = cars[i];
      c.t = (c.t + c.dir * c.speed * dt + span) % span;
      if (c.alongX) { dummy.position.set(GX0 + c.t, CITY.y + 0.1, c.base); dummy.rotation.set(0, c.dir > 0 ? 0 : Math.PI, 0); }
      else { dummy.position.set(c.base, CITY.y + 0.1, GZ0 + c.t); dummy.rotation.set(0, c.dir > 0 ? -Math.PI / 2 : Math.PI / 2, 0); }
      dummy.updateMatrix();
      im.setMatrixAt(i, dummy.matrix);
    }
    im.instanceMatrix.needsUpdate = true;
  };
  update(0);
  return { mesh: im, cars, update };
}
