import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

// Procedural cars, built facing +X, wheels on y=0.
const rb = (w, h, d, r) => new RoundedBoxGeometry(w, h, d, 4, Math.min(r, w / 2.05, h / 2.05, d / 2.05));

function paint(color, extra = {}) {
  return new THREE.MeshPhysicalMaterial({ color, metalness: 0.6, roughness: 0.25, clearcoat: 1, clearcoatRoughness: 0.05, ...extra });
}
const chrome = new THREE.MeshStandardMaterial({ color: 0xdddddd, metalness: 1, roughness: 0.08 });
const tire = new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.85 });
const darkGlass = new THREE.MeshPhysicalMaterial({ color: 0x0a0c10, metalness: 0.9, roughness: 0.05, transparent: true, opacity: 0.85 });
const trim = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.5, metalness: 0.4 });
const leather = new THREE.MeshStandardMaterial({ color: 0x3a1c12, roughness: 0.7 });
const headMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
const tailMat = new THREE.MeshBasicMaterial({ color: 0xff1a10 });

function wheel(r, w, rimMat = chrome) {
  const g = new THREE.Group();
  const t = new THREE.Mesh(new THREE.CylinderGeometry(r, r, w, 24), tire);
  t.rotation.x = Math.PI / 2;
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.66, r * 0.66, w + 0.01, 10), rimMat);
  rim.rotation.x = Math.PI / 2;
  g.add(t, rim);
  t.castShadow = true;
  return g;
}
function addMesh(parent, geo, mat, x, y, z, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z); m.rotation.set(rx, ry, rz);
  m.castShadow = true; m.receiveShadow = true;
  parent.add(m);
  return m;
}

// Mid-engine supercar (Tony's daily driver) — this one is drivable.
export function buildSupercar(color = 0xb9bcc0) {
  const car = new THREE.Group();
  const body = paint(color);
  addMesh(car, rb(4.4, 0.62, 1.94, 0.28), body, 0, 0.58, 0);
  addMesh(car, rb(1.6, 0.18, 1.86, 0.08), body, 1.35, 0.86, 0, 0, 0, -0.12); // hood slope
  const cabin = addMesh(car, rb(2.0, 0.55, 1.6, 0.25), darkGlass, -0.15, 1.08, 0);
  cabin.scale.set(1, 1, 1);
  addMesh(car, rb(1.3, 0.12, 1.5, 0.06), body, -0.35, 1.37, 0); // roof
  for (const s of [-1, 1]) {
    addMesh(car, rb(1.1, 0.42, 0.06, 0.03), trim, -0.6, 0.62, s * 0.97); // side blade
    addMesh(car, rb(0.08, 0.06, 0.38, 0.02), headMat, 2.18, 0.72, s * 0.62);
    addMesh(car, rb(0.06, 0.05, 0.5, 0.02), tailMat, -2.2, 0.78, s * 0.55);
  }
  addMesh(car, rb(0.12, 0.28, 1.2, 0.04), trim, 2.18, 0.5, 0); // grille
  addMesh(car, rb(0.5, 0.06, 1.7, 0.03), trim, -2.05, 1.0, 0); // rear spoiler
  const wheels = [];
  for (const [x, z] of [[1.4, 0.88], [1.4, -0.88], [-1.35, 0.88], [-1.35, -0.88]]) {
    const w = wheel(0.36, 0.3, trim); w.position.set(x, 0.36, z); car.add(w); wheels.push(w);
  }
  // interior seats
  addMesh(car, rb(0.5, 0.6, 0.5, 0.1), leather, -0.3, 0.85, 0.38);
  addMesh(car, rb(0.5, 0.6, 0.5, 0.1), leather, -0.3, 0.85, -0.38);
  const wheelS = addMesh(car, new THREE.TorusGeometry(0.17, 0.025, 8, 24), trim, 0.25, 1.0, 0.38, 0, Math.PI / 2, 0);
  wheelS.rotation.set(0, Math.PI / 2, 0.35);
  car.userData = { wheels, steering: wheelS, seat: new THREE.Vector3(-0.32, 0.55, 0.38), length: 4.4, width: 1.94 };
  return car;
}

// 1932 hot rod roadster (the restoration project)
export function buildHotRod() {
  const car = new THREE.Group();
  const body = paint(0x7a1a14);
  addMesh(car, rb(2.2, 0.75, 1.3, 0.12), body, -0.5, 0.95, 0); // tub
  addMesh(car, rb(1.5, 0.45, 0.75, 0.1), body, 1.0, 1.0, 0); // hood
  addMesh(car, rb(0.25, 0.7, 0.8, 0.06), chrome, 1.85, 1.0, 0); // grille
  addMesh(car, rb(0.9, 0.5, 0.6, 0.08), chrome, 1.0, 1.42, 0); // exposed engine
  for (let i = 0; i < 4; i++) for (const s of [-1, 1]) addMesh(car, new THREE.CylinderGeometry(0.035, 0.035, 0.5, 8), chrome, 0.7 + i * 0.22, 1.05, s * 0.42, 0, 0, Math.PI / 2.4);
  addMesh(car, rb(0.08, 0.5, 1.2, 0.02), darkGlass, 0.25, 1.55, 0);
  addMesh(car, rb(0.6, 0.5, 1.1, 0.1), leather, -0.7, 1.15, 0);
  for (const s of [-1, 1]) addMesh(car, new THREE.SphereGeometry(0.13, 12, 10), chrome, 1.9, 1.45, s * 0.5);
  for (const [x, z, r] of [[1.4, 0.75, 0.36], [1.4, -0.75, 0.36], [-1.2, 0.78, 0.48], [-1.2, -0.78, 0.48]]) {
    const w = wheel(r, 0.32); w.position.set(x, r, z); car.add(w);
  }
  addMesh(car, rb(3.6, 0.12, 0.9, 0.04), trim, 0.1, 0.5, 0);
  return car;
}

// Classic roadster with racing stripes
export function buildCobra() {
  const car = new THREE.Group();
  const body = paint(0xc9ccd1);
  const stripe = paint(0x153a8c);
  addMesh(car, rb(4.0, 0.7, 1.75, 0.34), body, 0, 0.7, 0);
  for (const s of [-1, 1]) addMesh(car, new THREE.SphereGeometry(0.62, 16, 12), body, 1.25, 0.72, s * 0.62).scale.set(1.4, 0.75, 0.55);
  for (const s of [-1, 1]) addMesh(car, new THREE.SphereGeometry(0.62, 16, 12), body, -1.25, 0.75, s * 0.62).scale.set(1.4, 0.8, 0.58);
  for (const s of [-1, 1]) addMesh(car, rb(4.02, 0.02, 0.2, 0.01), stripe, 0, 1.06, s * 0.18);
  addMesh(car, rb(0.06, 0.32, 1.1, 0.02), darkGlass, 0.35, 1.22, 0, 0, 0, 0.3);
  addMesh(car, rb(0.6, 0.45, 1.2, 0.1), leather, -0.4, 1.0, 0);
  addMesh(car, rb(0.2, 0.25, 0.7, 0.08), trim, 2.0, 0.6, 0);
  for (const s of [-1, 1]) addMesh(car, new THREE.SphereGeometry(0.1, 12, 8), headMat, 1.95, 0.82, s * 0.55);
  for (const [x, z] of [[1.25, 0.82], [1.25, -0.82], [-1.25, 0.84], [-1.25, -0.84]]) {
    const w = wheel(0.34, 0.28); w.position.set(x, 0.34, z); car.add(w);
  }
  return car;
}

// White mid-engine hypercar
export function buildHypercar() {
  const car = new THREE.Group();
  const body = paint(0xf2f2f2);
  addMesh(car, rb(4.6, 0.55, 2.0, 0.26), body, 0, 0.52, 0);
  addMesh(car, rb(1.6, 0.5, 1.5, 0.24), darkGlass, 0.1, 0.95, 0);
  addMesh(car, rb(1.9, 0.3, 1.8, 0.14), body, -1.2, 0.9, 0);
  for (const s of [-1, 1]) addMesh(car, rb(1.2, 0.3, 0.1, 0.04), trim, -0.8, 0.75, s * 1.0);
  addMesh(car, rb(0.3, 0.05, 2.0, 0.02), trim, -2.3, 1.15, 0);
  for (const s of [-1, 1]) {
    addMesh(car, rb(0.06, 0.06, 0.4, 0.02), headMat, 2.3, 0.62, s * 0.6);
    addMesh(car, rb(0.05, 0.08, 0.35, 0.02), tailMat, -2.32, 0.78, s * 0.6);
  }
  for (const [x, z] of [[1.5, 0.9], [1.5, -0.9], [-1.45, 0.9], [-1.45, -0.9]]) {
    const w = wheel(0.35, 0.32, trim); w.position.set(x, 0.35, z); car.add(w);
  }
  return car;
}

// simple box car for traffic (instanced) — returns geometry
export function trafficCarGeometry() {
  const g = new RoundedBoxGeometry(4.2, 1.35, 1.85, 2, 0.35);
  g.translate(0, 0.75, 0);
  return g;
}
