import * as THREE from 'three';
import { rand } from './util.js';

const VS = `
attribute float size;
attribute vec4 pcolor;
varying vec4 vColor;
uniform float uScale;
void main(){
  vColor = pcolor;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = size * uScale * projectionMatrix[1][1] / max(0.1, -mv.z);
}`;
const FS = `
varying vec4 vColor;
void main(){
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c) * 2.0;
  float a = pow(clamp(1.0 - d, 0.0, 1.0), 1.6);
  if (a <= 0.003) discard;
  gl_FragColor = vec4(vColor.rgb, vColor.a * a);
}`;

class ParticleSystem {
  constructor(scene, max, blending) {
    this.max = max; this.n = 0; this.cursor = 0;
    this.pos = new Float32Array(max * 3); this.vel = new Float32Array(max * 3);
    this.col = new Float32Array(max * 4); this.size = new Float32Array(max);
    this.life = new Float32Array(max); this.maxLife = new Float32Array(max);
    this.s0 = new Float32Array(max); this.s1 = new Float32Array(max);
    this.c0 = new Float32Array(max * 4); this.c1 = new Float32Array(max * 4);
    this.drag = new Float32Array(max); this.grav = new Float32Array(max);
    const geo = new THREE.BufferGeometry();
    this.aPos = new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage);
    this.aCol = new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage);
    this.aSize = new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('position', this.aPos); geo.setAttribute('pcolor', this.aCol); geo.setAttribute('size', this.aSize);
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e7);
    this.mat = new THREE.ShaderMaterial({
      vertexShader: VS, fragmentShader: FS, uniforms: { uScale: { value: 500 } },
      transparent: true, depthWrite: false, blending,
    });
    this.points = new THREE.Points(geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
    scene.add(this.points);
    for (let i = 0; i < max; i++) this.life[i] = 0;
  }
  spawn(p, v, life, s0, s1, c0, c1, drag = 0, grav = 0) {
    const i = this.cursor; this.cursor = (this.cursor + 1) % this.max;
    this.pos[i * 3] = p.x; this.pos[i * 3 + 1] = p.y; this.pos[i * 3 + 2] = p.z;
    this.vel[i * 3] = v.x; this.vel[i * 3 + 1] = v.y; this.vel[i * 3 + 2] = v.z;
    this.life[i] = this.maxLife[i] = life; this.s0[i] = s0; this.s1[i] = s1;
    for (let k = 0; k < 4; k++) { this.c0[i * 4 + k] = c0[k]; this.c1[i * 4 + k] = c1[k]; }
    this.drag[i] = drag; this.grav[i] = grav;
  }
  update(dt) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) { this.size[i] = 0; this.col[i * 4 + 3] = 0; continue; }
      this.life[i] -= dt;
      const t = 1 - Math.max(0, this.life[i]) / this.maxLife[i];
      const dr = Math.exp(-this.drag[i] * dt);
      this.vel[i * 3] *= dr; this.vel[i * 3 + 1] = this.vel[i * 3 + 1] * dr - this.grav[i] * dt; this.vel[i * 3 + 2] *= dr;
      this.pos[i * 3] += this.vel[i * 3] * dt; this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt; this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      this.size[i] = this.s0[i] + (this.s1[i] - this.s0[i]) * t;
      for (let k = 0; k < 4; k++) this.col[i * 4 + k] = this.c0[i * 4 + k] + (this.c1[i * 4 + k] - this.c0[i * 4 + k]) * t;
    }
    this.aPos.needsUpdate = this.aCol.needsUpdate = this.aSize.needsUpdate = true;
  }
}

const _v = new THREE.Vector3(), _p = new THREE.Vector3();
export class FX {
  constructor(scene, audio) {
    this.scene = scene; this.audio = audio;
    this.add = new ParticleSystem(scene, 7000, THREE.AdditiveBlending);
    this.smoke = new ParticleSystem(scene, 2500, THREE.NormalBlending);
    // pooled flash lights
    this.lights = [];
    for (let i = 0; i < 3; i++) { const l = new THREE.PointLight(0xffa050, 0, 120, 1.5); scene.add(l); this.lights.push({ l, t: 0, max: 0 }); }
    this.li = 0;
    this.flashes = [];
    this.flashGeo = new THREE.SphereGeometry(1, 16, 12);
    this.shockGeo = new THREE.RingGeometry(0.8, 1, 48);
  }
  setScale(s) { this.add.mat.uniforms.uScale.value = s; this.smoke.mat.uniforms.uScale.value = s; }

  thrustTrail(pos, dir, strength, boost) {
    // dir = direction the exhaust travels
    const n = boost ? 3 : 2;
    for (let i = 0; i < n; i++) {
      _v.copy(dir).multiplyScalar(rand(6, 14) * strength).add(_p.set(rand(-0.6, 0.6), rand(-0.6, 0.6), rand(-0.6, 0.6)));
      this.add.spawn(pos, _v, rand(0.08, 0.18), 0.09 * strength + 0.04, 0.02, [0.75, 0.9, 1.0, 0.9], [0.3, 0.55, 1.0, 0], 2, 0);
    }
  }
  sparks(pos, n = 12, color = [1, 0.8, 0.4], speed = 18) {
    for (let i = 0; i < n; i++) {
      _v.randomDirection().multiplyScalar(rand(0.3, 1) * speed);
      this.add.spawn(pos, _v, rand(0.2, 0.6), 0.08, 0.02, [color[0], color[1], color[2], 1], [color[0], color[1] * 0.5, color[2] * 0.3, 0], 2.5, 9.8);
    }
  }
  repulsorImpact(pos) {
    this.sparks(pos, 14, [0.7, 0.9, 1], 14);
    this.flash(pos, 1.6, 0xbfe6ff, 0.12);
    for (let i = 0; i < 6; i++) { _v.randomDirection().multiplyScalar(2); this.smoke.spawn(pos, _v, rand(0.6, 1.2), 0.6, 2.2, [0.5, 0.5, 0.5, 0.35], [0.4, 0.4, 0.4, 0], 1, -0.5); }
  }
  explosion(pos, scale = 1, playerPos = null) {
    const big = scale > 1.6;
    for (let i = 0; i < 40 * Math.min(scale, 2.5); i++) {
      _v.randomDirection().multiplyScalar(rand(4, 16) * scale);
      this.add.spawn(pos, _v, rand(0.4, 1.0), 2.2 * scale, 4.5 * scale, [1, 0.75, 0.35, 1], [0.9, 0.2, 0.05, 0], 3, -2);
    }
    for (let i = 0; i < 30 * Math.min(scale, 2.5); i++) {
      _v.randomDirection().multiplyScalar(rand(30, 60) * Math.sqrt(scale));
      this.add.spawn(pos, _v, rand(0.3, 1.2), 0.25, 0.05, [1, 0.9, 0.6, 1], [1, 0.4, 0.1, 0], 1.5, 15);
    }
    for (let i = 0; i < 26 * Math.min(scale, 2.5); i++) {
      _v.randomDirection().multiplyScalar(rand(2, 8) * scale); _v.y = Math.abs(_v.y) + 2;
      this.smoke.spawn(pos, _v, rand(2.5, 5), 3 * scale, 11 * scale, [0.25, 0.22, 0.2, 0.75], [0.35, 0.34, 0.33, 0], 1.2, -1.2);
    }
    this.flash(pos, 6 * scale, 0xffb060, 0.35);
    this.shock(pos, 14 * scale);
    const L = this.lights[this.li]; this.li = (this.li + 1) % this.lights.length;
    L.l.position.copy(pos); L.max = 1500 * scale * scale; L.t = 0.5; L.l.distance = 80 * scale;
    if (this.audio) this.audio.explosion(playerPos ? playerPos.distanceTo(pos) : 0, big);
  }
  flash(pos, size, color, life) {
    const m = new THREE.Mesh(this.flashGeo, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 1, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
    m.position.copy(pos); m.scale.setScalar(size * 0.4);
    this.scene.add(m);
    this.flashes.push({ m, life, max: life, size, kind: 'flash' });
  }
  shock(pos, size) {
    const m = new THREE.Mesh(this.shockGeo, new THREE.MeshBasicMaterial({ color: 0xffd9a0, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    m.position.copy(pos); m.rotation.x = -Math.PI / 2;
    this.scene.add(m);
    this.flashes.push({ m, life: 0.5, max: 0.5, size, kind: 'shock' });
  }
  muzzle(pos, color = [0.7, 0.9, 1]) {
    for (let i = 0; i < 5; i++) { _v.randomDirection().multiplyScalar(3); this.add.spawn(pos, _v, 0.08, 0.25, 0.05, [color[0], color[1], color[2], 1], [color[0], color[1], color[2], 0], 0, 0); }
  }
  missileTrail(pos) {
    _v.set(rand(-0.5, 0.5), rand(-0.5, 0.5), rand(-0.5, 0.5));
    this.smoke.spawn(pos, _v, rand(1.2, 2.2), 0.4, 2.2, [0.85, 0.85, 0.85, 0.55], [0.6, 0.6, 0.6, 0], 0.5, -0.3);
    this.add.spawn(pos, _v, 0.08, 0.5, 0.1, [1, 0.8, 0.5, 1], [1, 0.4, 0.1, 0], 0, 0);
  }
  fire(pos, dir, spread = 0.25) { // flamethrower / burning
    _v.copy(dir).multiplyScalar(rand(14, 22)).add(_p.randomDirection().multiplyScalar(spread * 10));
    this.add.spawn(pos, _v, rand(0.35, 0.6), 0.3, 2.2, [1, 0.7, 0.25, 0.9], [0.8, 0.15, 0.02, 0], 2.5, -3);
  }
  smokeColumn(pos) {
    _v.set(rand(-1, 1), rand(4, 7), rand(-1, 1));
    this.smoke.spawn(pos, _v, rand(4, 7), 3, 12, [0.15, 0.14, 0.13, 0.55], [0.3, 0.3, 0.3, 0], 0.3, -0.5);
    if (Math.random() < 0.5) this.add.spawn(pos, _v.set(rand(-1, 1), rand(2, 5), rand(-1, 1)), rand(0.5, 1), 2, 0.5, [1, 0.5, 0.1, 0.8], [1, 0.2, 0.05, 0], 0.5, 0);
  }
  update(dt) {
    this.add.update(dt); this.smoke.update(dt);
    for (const L of this.lights) { if (L.t > 0) { L.t -= dt; L.l.intensity = L.max * Math.max(0, L.t / 0.5) ** 2; } else L.l.intensity = 0; }
    for (let i = this.flashes.length - 1; i >= 0; i--) {
      const f = this.flashes[i]; f.life -= dt;
      const t = 1 - f.life / f.max;
      if (f.kind === 'flash') { f.m.scale.setScalar(f.size * (0.4 + t * 0.8)); f.m.material.opacity = (1 - t) ** 2; }
      else { f.m.scale.setScalar(f.size * (0.2 + t)); f.m.material.opacity = 0.6 * (1 - t); }
      if (f.life <= 0) { this.scene.remove(f.m); f.m.material.dispose(); this.flashes.splice(i, 1); }
    }
  }
}
