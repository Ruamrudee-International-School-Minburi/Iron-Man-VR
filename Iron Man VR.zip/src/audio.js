// Procedural audio: no sound files needed. Everything is synthesized with WebAudio.
export class Audio {
  constructor() {
    this.ctx = null;
    this.voiceOn = true;
    this.volume = 0.8;
    this.lastSpeak = 0;
    this.queue = [];
    this.onSubtitle = null;
  }
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const ctx = (this.ctx = new (window.AudioContext || window.webkitAudioContext)());
    this.master = ctx.createGain(); this.master.gain.value = this.volume;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16; comp.ratio.value = 4;
    this.master.connect(comp).connect(ctx.destination);
    // noise buffers
    const len = ctx.sampleRate * 2;
    this.noise = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noise.getChannelData(0);
    let b = 0;
    for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; b = 0.98 * b + 0.02 * w; d[i] = w * 0.5 + b * 4; }
    // continuous layers: thrusters (L/R), wind, beam, hum
    this.thrust = [this._loopNoise('bandpass', 400, 0.7), this._loopNoise('bandpass', 420, 0.7)];
    this.thrustLow = this._loopNoise('lowpass', 160, 1);
    this.wind = this._loopNoise('bandpass', 700, 0.5);
    this.beam = this._beamLayer();
    this.hum = this._humLayer();
    this.engine = this._engineLayer();
  }
  _loopNoise(type, freq, q) {
    const ctx = this.ctx;
    const src = ctx.createBufferSource(); src.buffer = this.noise; src.loop = true;
    src.playbackRate.value = 0.6 + Math.random() * 0.2;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain(); g.gain.value = 0;
    src.connect(f).connect(g).connect(this.master);
    src.start();
    return { src, f, g };
  }
  _beamLayer() {
    const ctx = this.ctx;
    const o1 = ctx.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = 110;
    const o2 = ctx.createOscillator(); o2.type = 'square'; o2.frequency.value = 221;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1400;
    const g = ctx.createGain(); g.gain.value = 0;
    o1.connect(f); o2.connect(f); f.connect(g).connect(this.master);
    o1.start(); o2.start();
    return { o1, o2, g };
  }
  _humLayer() {
    const ctx = this.ctx;
    const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = 58;
    const o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = 117;
    const g = ctx.createGain(); g.gain.value = 0;
    o.connect(g); o2.connect(g); g.connect(this.master);
    o.start(); o2.start();
    return { g };
  }
  _engineLayer() {
    const ctx = this.ctx;
    const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 40;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 400;
    const g = ctx.createGain(); g.gain.value = 0;
    o.connect(f).connect(g).connect(this.master); o.start();
    return { o, f, g };
  }

  // per-frame continuous sounds
  update({ thrustL = 0, thrustR = 0, boost = false, speed = 0, beam = false, suited = false, carRpm = -1 }) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime, k = 0.08;
    [thrustL, thrustR].forEach((v, i) => {
      const L = this.thrust[i];
      L.g.gain.setTargetAtTime(v * (boost ? 0.5 : 0.32), t, k);
      L.f.frequency.setTargetAtTime(300 + v * 900 + (boost ? 900 : 0), t, k);
    });
    const tot = (thrustL + thrustR) / 2;
    this.thrustLow.g.gain.setTargetAtTime(tot * (boost ? 0.9 : 0.55), t, k);
    this.wind.g.gain.setTargetAtTime(Math.min(0.45, speed / 220), t, 0.2);
    this.wind.f.frequency.setTargetAtTime(400 + speed * 8, t, 0.2);
    this.beam.g.gain.setTargetAtTime(beam ? 0.16 : 0, t, 0.04);
    if (beam) { this.beam.o1.frequency.setTargetAtTime(105 + Math.random() * 15, t, 0.02); }
    this.hum.g.gain.setTargetAtTime(suited ? 0.025 : 0, t, 0.5);
    if (carRpm >= 0) { this.engine.g.gain.setTargetAtTime(0.12, t, 0.1); this.engine.o.frequency.setTargetAtTime(35 + carRpm * 90, t, 0.05); this.engine.f.frequency.setTargetAtTime(300 + carRpm * 900, t, 0.05); }
    else this.engine.g.gain.setTargetAtTime(0, t, 0.1);
  }

  _env(node, peak, a, d, when) {
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(peak, when + a);
    g.gain.exponentialRampToValueAtTime(0.0001, when + a + d);
    node.connect(g).connect(this.master);
    return g;
  }
  _noiseBurst(type, freq, q, peak, a, d, rate = 1, when = 0) {
    const ctx = this.ctx, t = ctx.currentTime + when;
    const s = ctx.createBufferSource(); s.buffer = this.noise; s.playbackRate.value = rate;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    s.connect(f); this._env(f, peak, a, d, t);
    s.start(t, Math.random()); s.stop(t + a + d + 0.05);
    return f;
  }
  _tone(type, f0, f1, peak, a, d, when = 0) {
    const ctx = this.ctx, t = ctx.currentTime + when;
    const o = ctx.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + a + d);
    this._env(o, peak, a, d, t);
    o.start(t); o.stop(t + a + d + 0.05);
  }
  _attenuate(dist) { return Math.max(0.05, Math.min(1, 60 / (dist + 30))); }

  repulsor() {
    if (!this.ctx) return;
    this._tone('sine', 1500, 260, 0.22, 0.005, 0.22);
    this._tone('sawtooth', 700, 120, 0.06, 0.005, 0.15);
    this._noiseBurst('highpass', 1800, 0.7, 0.25, 0.003, 0.12);
  }
  repulsorCharge() { if (this.ctx) this._tone('sine', 300, 1600, 0.05, 0.25, 0.05); }
  missile() { if (!this.ctx) return; this._noiseBurst('bandpass', 900, 0.8, 0.4, 0.01, 0.6, 0.8); this._tone('square', 400, 90, 0.04, 0.01, 0.3); }
  minigun() { if (!this.ctx) return; this._noiseBurst('bandpass', 2200, 1.5, 0.2, 0.002, 0.05, 1.4); this._tone('square', 180, 90, 0.05, 0.002, 0.04); }
  flamer() { if (!this.ctx) return; this._noiseBurst('lowpass', 900, 0.5, 0.18, 0.02, 0.15, 0.7); }
  explosion(dist = 0, big = false) {
    if (!this.ctx) return;
    const v = this._attenuate(dist) * (big ? 1.3 : 1);
    this._noiseBurst('lowpass', big ? 500 : 900, 0.7, 0.9 * v, 0.005, big ? 2.2 : 1.2, 0.5);
    this._tone('sine', 90, 25, 0.8 * v, 0.005, big ? 1.4 : 0.8);
    this._noiseBurst('bandpass', 2400, 0.6, 0.25 * v, 0.003, 0.3, 1);
  }
  hit() { if (this.ctx) { this._noiseBurst('bandpass', 1300, 2, 0.35, 0.002, 0.1); this._tone('square', 220, 120, 0.08, 0.002, 0.1); } }
  enemyShot(dist = 0) { if (this.ctx) this._tone('square', 900, 300, 0.07 * this._attenuate(dist), 0.002, 0.09); }
  alarm() { if (this.ctx) { this._tone('square', 880, 880, 0.06, 0.01, 0.12); this._tone('square', 660, 660, 0.06, 0.01, 0.12, 0.16); } }
  ui(kind = 'click') {
    if (!this.ctx) return;
    if (kind === 'click') this._tone('sine', 1200, 1800, 0.12, 0.003, 0.08);
    else if (kind === 'hover') this._tone('sine', 900, 1000, 0.04, 0.002, 0.04);
    else if (kind === 'deny') this._tone('square', 220, 160, 0.1, 0.005, 0.2);
    else if (kind === 'success') { this._tone('sine', 880, 880, 0.12, 0.01, 0.15); this._tone('sine', 1320, 1320, 0.12, 0.01, 0.3, 0.12); }
    else if (kind === 'ring') { this._tone('sine', 1046, 2093, 0.15, 0.005, 0.25); }
    else if (kind === 'pickup') { this._tone('triangle', 660, 1320, 0.15, 0.005, 0.3); this._tone('triangle', 990, 1980, 0.1, 0.005, 0.3, 0.08); }
  }
  suitUp() {
    if (!this.ctx) return;
    for (let i = 0; i < 14; i++) {
      this._noiseBurst('bandpass', 600 + Math.random() * 1800, 3, 0.4, 0.002, 0.08, 1.2, i * 0.11 + Math.random() * 0.04);
      this._tone('square', 140 + Math.random() * 120, 60, 0.05, 0.002, 0.07, i * 0.11);
    }
    this._tone('sine', 120, 900, 0.12, 1.4, 0.4, 1.0);
    this._tone('sine', 240, 1800, 0.06, 1.4, 0.4, 1.0);
  }
  icing() { if (this.ctx) this._noiseBurst('highpass', 4000, 0.5, 0.15, 0.3, 1.2, 1.5); }

  // ---- J.A.R.V.I.S. voice (speech synthesis) + subtitles
  say(text, { priority = false } = {}) {
    if (this.onSubtitle) this.onSubtitle(text);
    if (!this.voiceOn || !('speechSynthesis' in window)) return;
    const synth = window.speechSynthesis;
    if (priority) synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    const voices = synth.getVoices();
    const v = voices.find((x) => /en-GB/i.test(x.lang) && /male|george|daniel|ryan|arthur/i.test(x.name))
      || voices.find((x) => /en-GB/i.test(x.lang)) || voices.find((x) => /^en/i.test(x.lang));
    if (v) u.voice = v;
    u.rate = 1.05; u.pitch = 0.92; u.volume = 0.9;
    synth.speak(u);
  }
}
